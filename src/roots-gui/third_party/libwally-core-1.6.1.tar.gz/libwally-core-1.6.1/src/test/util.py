from ctypes import *
from binascii import hexlify, unhexlify
from os.path import isfile, abspath
from os import urandom
import platform

# Allow to run from any sub dir
SO_EXT = 'dylib' if platform.system() == 'Darwin' else 'dll' if platform.system() == 'Windows' else 'so'
for depth in [0, 1, 2]:
    root_dir = '../' * depth
    if isfile(root_dir + 'src/.libs/libwallycore.' + SO_EXT):
        break

if platform.system() == 'Darwin':
    root_dir = abspath(root_dir) + '/'

libwally = CDLL(root_dir + 'src/.libs/libwallycore.' + SO_EXT)

wally_free_string = libwally.wally_free_string
wally_free_string.restype, wally_free_string.argtypes = None, [c_char_p]

WALLY_OK, WALLY_ERROR, WALLY_EINVAL, WALLY_ENOMEM = 0, -1, -2, -3

_malloc_fn_t = CFUNCTYPE(c_void_p, c_size_t)
_free_fn_t = CFUNCTYPE(None, c_void_p)
_bzero_fn_t = CFUNCTYPE(None, c_void_p, c_size_t)
_ec_nonce_fn_t = CFUNCTYPE(c_int, c_void_p, c_void_p, c_void_p, c_void_p, c_void_p, c_uint)
_secp_context_fn_t = CFUNCTYPE(c_void_p)

class wally_operations(Structure):
    _fields_ = [('struct_size', c_size_t),
                ('malloc_fn', _malloc_fn_t),
                ('free_fn', _free_fn_t),
                ('bzero_fn', _bzero_fn_t),
                ('ec_nonce_fn', _ec_nonce_fn_t),
                ('secp_context_fn', _secp_context_fn_t),
                ('reserved_1', c_void_p),
                ('reserved_2', c_void_p),
                ('reserved_3', c_void_p),
                ('reserved_4', c_void_p)]

class ext_key(Structure):
    _fields_ = [('chain_code', c_ubyte * 32),
                ('parent160', c_ubyte * 20),
                ('depth', c_ubyte),
                ('pad1', c_ubyte * 10),
                ('priv_key', c_ubyte * 33),
                ('child_num', c_uint32),
                ('hash160', c_ubyte * 20),
                ('version', c_uint32),
                ('pad2', c_ubyte * 3),
                ('pub_key', c_ubyte * 33),
                ('pub_key_tweak_sum', c_ubyte * 32)]

# Sentinel classes for returning output parameters
class c_char_p_p_class(object):
    pass
c_char_p_p = c_char_p_p_class()
class c_size_t_p_class(object):
    pass
c_size_t_p = c_size_t_p_class()
class c_uint32_p_class(object):
    pass
c_uint32_p = c_uint32_p_class()
class c_uint64_p_class(object):
    pass
c_uint64_p = c_uint64_p_class()

class wally_tx_witness_item(Structure):
    _fields_ = [('witness', c_void_p),
                ('len', c_size_t)]

class wally_tx_witness_stack(Structure):
    _fields_ = [('items', POINTER(wally_tx_witness_item)),
                ('num_items', c_size_t),
                ('items_allocation_len', c_size_t)]

class wally_tx_input(Structure):
    _fields_ = [('txhash', c_ubyte * 32),
                ('index', c_uint32),
                ('sequence', c_uint32),
                ('script', c_void_p),
                ('script_len', c_size_t),
                ('witness',  POINTER(wally_tx_witness_stack)),
                ('features', c_ubyte),
                ('blinding_nonce', c_ubyte * 32),
                ('entropy', c_ubyte * 32),
                ('issuance_amount', c_void_p),
                ('issuance_amount_len', c_size_t),
                ('inflation_keys', c_void_p),
                ('inflation_keys_len', c_size_t),
                ('issuance_amount_rangeproof', c_void_p),
                ('issuance_amount_rangeproof_len', c_size_t),
                ('inflation_keys_rangeproof', c_void_p),
                ('inflation_keys_rangeproof_len', c_size_t),
                ('pegin_witness', POINTER(wally_tx_witness_stack))]

class wally_tx_output(Structure):
    _fields_ = [('satoshi', c_uint64),
                ('script', c_void_p),
                ('script_len', c_size_t),
                ('features', c_ubyte),
                ('asset', c_void_p),
                ('asset_len', c_size_t),
                ('value', c_void_p),
                ('value_len', c_size_t),
                ('nonce', c_void_p),
                ('nonce_len', c_size_t),
                ('surjectionproof', c_void_p),
                ('surjectionproof_len', c_size_t),
                ('rangeproof', c_void_p),
                ('rangeproof_len', c_size_t)]

class wally_tx(Structure):
    _fields_ = [('version', c_uint32),
                ('locktime', c_uint32),
                ('inputs', POINTER(wally_tx_input)),
                ('num_inputs', c_size_t),
                ('inputs_allocation_len', c_size_t),
                ('outputs', POINTER(wally_tx_output)),
                ('num_outputs', c_size_t),
                ('outputs_allocation_len', c_size_t)]

class wally_map_item(Structure):
    _fields_ = [('key', c_void_p),
                ('key_len', c_size_t),
                ('value', c_void_p),
                ('value_len', c_size_t)]

class wally_map(Structure):
    _fields_ = [('items', POINTER(wally_map_item)),
                ('num_items', c_size_t),
                ('items_allocation_len', c_size_t),
                ('verify_fn', c_void_p)]

class wally_psbt_input(Structure):
    _fields_ = [('txhash', c_ubyte * 32),
                ('index', c_uint32),
                ('sequence', c_uint32),
                ('utxo', POINTER(wally_tx)),
                ('witness_utxo', POINTER(wally_tx_output)),
                ('final_witness', POINTER(wally_tx_witness_stack)),
                ('keypaths', wally_map),
                ('signatures', wally_map),
                ('unknowns', wally_map),
                ('sighash', c_uint32),
                ('required_locktime', c_uint32),
                ('required_lockheight', c_uint32),
                ('preimages', wally_map),
                ('psbt_fields', wally_map),
                ('taproot_leaf_signatures', wally_map),
                ('taproot_leaf_scripts', wally_map),
                ('taproot_leaf_hashes', wally_map),
                ('taproot_leaf_paths', wally_map),
                ('issuance_amount', c_uint64),
                ('inflation_keys', c_uint64),
                ('pegin_amount', c_uint64),
                ('pegin_tx', POINTER(wally_tx)),
                ('pegin_witness', POINTER(wally_tx_witness_stack)),
                ('pset_fields', wally_map),
                ('amount', c_uint64),
                ('has_amount', c_uint32)]

class wally_psbt_output(Structure):
    _fields_ = [('keypaths', wally_map),
                ('unknowns', wally_map),
                ('amount', c_uint64),
                ('has_amount', c_uint32),
                ('script', c_void_p),
                ('script_len', c_size_t),
                ('psbt_fields', wally_map),
                ('taproot_tree', wally_map),
                ('taproot_leaf_hashes', wally_map),
                ('taproot_leaf_paths', wally_map),
                ('blinder_index', c_uint32),
                ('has_blinder_index', c_uint32),
                ('pset_fields', wally_map)]

class wally_psbt(Structure):
    _fields_ = [('magic', c_ubyte * 5),
                ('tx', POINTER(wally_tx)),
                ('inputs', POINTER(wally_psbt_input)),
                ('num_inputs', c_size_t),
                ('inputs_allocation_len', c_size_t),
                ('outputs', POINTER(wally_psbt_output)),
                ('num_outputs', c_size_t),
                ('outputs_allocation_len', c_size_t),
                ('unknowns', wally_map),
                ('global_xpubs', wally_map),
                ('version', c_uint32),
                ('tx_version', c_uint32),
                ('fallback_locktime', c_uint32),
                ('has_fallback_locktime', c_uint32),
                ('tx_modifiable_flags', c_uint32),
                ('global_scalars', wally_map),
                ('pset_modifiable_flags', c_uint32),
                ('genesis_blockhash', c_ubyte * 32),
                ('signing_cache', POINTER(wally_map))]

for f in (
    # Internal functions
    ('mnemonic_from_bytes', c_char_p, [c_void_p, c_void_p, c_size_t]),
    ('mnemonic_to_bytes', c_int, [c_void_p, c_char_p, c_void_p, c_size_t, c_size_t_p]),
    ('wordlist_free', None, [c_void_p]),
    ('wordlist_init', c_void_p, [c_char_p]),
    ('wordlist_lookup_index', c_char_p, [c_void_p, c_size_t]),
    ('wordlist_lookup_word', c_size_t, [c_void_p, c_char_p]),
    # Exported functions
    ('wally_get_secp_context', c_void_p, []),
    ('wally_get_new_secp_context', c_void_p, []),
    ('wally_secp_context_free', None, [c_void_p]),
    # BEGIN AUTOGENERATED
    ('bip32_key_free', c_int, [POINTER(ext_key)]),
    ('bip32_key_from_base58', c_int, [c_char_p, POINTER(ext_key)]),
    ('bip32_key_from_base58_alloc', c_int, [c_char_p, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_base58_n', c_int, [c_char_p, c_size_t, POINTER(ext_key)]),
    ('bip32_key_from_base58_n_alloc', c_int, [c_char_p, c_size_t, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_parent', c_int, [POINTER(ext_key), c_uint32, c_uint32, POINTER(ext_key)]),
    ('bip32_key_from_parent_alloc', c_int, [POINTER(ext_key), c_uint32, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_parent_path', c_int, [POINTER(ext_key), POINTER(c_uint32), c_size_t, c_uint32, POINTER(ext_key)]),
    ('bip32_key_from_parent_path_alloc', c_int, [POINTER(ext_key), POINTER(c_uint32), c_size_t, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_parent_path_str', c_int, [POINTER(ext_key), c_char_p, c_uint32, c_uint32, POINTER(ext_key)]),
    ('bip32_key_from_parent_path_str_alloc', c_int, [POINTER(ext_key), c_char_p, c_uint32, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_parent_path_str_n', c_int, [POINTER(ext_key), c_char_p, c_size_t, c_uint32, c_uint32, POINTER(ext_key)]),
    ('bip32_key_from_parent_path_str_n_alloc', c_int, [POINTER(ext_key), c_char_p, c_size_t, c_uint32, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_seed', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, POINTER(ext_key)]),
    ('bip32_key_from_seed_alloc', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_key_from_seed_custom', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_uint32, POINTER(ext_key)]),
    ('bip32_key_from_seed_custom_alloc', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_key_get_fingerprint', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_init', c_int, [c_uint32, c_uint32, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(ext_key)]),
    ('bip32_key_init_alloc', c_int, [c_uint32, c_uint32, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(POINTER(ext_key))]),
    ('bip32_key_serialize', c_int, [POINTER(ext_key), c_uint32, c_void_p, c_size_t]),
    ('bip32_key_strip_private_key', c_int, [POINTER(ext_key)]),
    ('bip32_key_to_base58', c_int, [POINTER(ext_key), c_uint32, c_char_p_p]),
    ('bip32_key_unserialize', c_int, [c_void_p, c_size_t, POINTER(ext_key)]),
    ('bip32_key_unserialize_alloc', c_int, [c_void_p, c_size_t, POINTER(POINTER(ext_key))]),
    ('bip32_key_with_tweak_from_parent_path', c_int, [POINTER(ext_key), POINTER(c_uint32), c_size_t, c_uint32, POINTER(ext_key)]),
    ('bip32_key_with_tweak_from_parent_path_alloc', c_int, [POINTER(ext_key), POINTER(c_uint32), c_size_t, c_uint32, POINTER(POINTER(ext_key))]),
    ('bip32_path_from_str', c_int, [c_char_p, c_uint32, c_uint32, c_uint32, POINTER(c_uint32), c_size_t, c_size_t_p]),
    ('bip32_path_from_str_len', c_int, [c_char_p, c_uint32, c_uint32, c_uint32, c_size_t_p]),
    ('bip32_path_from_str_n', c_int, [c_char_p, c_size_t, c_uint32, c_uint32, c_uint32, POINTER(c_uint32), c_size_t, c_size_t_p]),
    ('bip32_path_from_str_n_len', c_int, [c_char_p, c_size_t, c_uint32, c_uint32, c_uint32, c_size_t_p]),
    ('bip32_path_str_get_features', c_int, [c_char_p, c_uint32_p]),
    ('bip32_path_str_n_get_features', c_int, [c_char_p, c_size_t, c_uint32_p]),
    ('bip38_from_private_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_char_p_p]),
    ('bip38_get_flags', c_int, [c_char_p, c_size_t_p]),
    ('bip38_raw_from_private_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('bip38_raw_get_flags', c_int, [c_void_p, c_size_t, c_size_t_p]),
    ('bip38_raw_to_private_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('bip38_to_private_key', c_int, [c_char_p, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('bip39_get_languages', c_int, [c_char_p_p]),
    ('bip39_get_word', c_int, [c_void_p, c_size_t, c_char_p_p]),
    ('bip39_get_wordlist', c_int, [c_char_p, POINTER(c_void_p)]),
    ('bip39_mnemonic_from_bytes', c_int, [c_void_p, c_void_p, c_size_t, c_char_p_p]),
    ('bip39_mnemonic_to_bytes', c_int, [c_void_p, c_char_p, c_void_p, c_size_t, c_size_t_p]),
    ('bip39_mnemonic_to_seed', c_int, [c_char_p, c_char_p, c_void_p, c_size_t, c_size_t_p]),
    ('bip39_mnemonic_to_seed512', c_int, [c_char_p, c_char_p, c_void_p, c_size_t]),
    ('bip39_mnemonic_validate', c_int, [c_void_p, c_char_p]),
    ('bip85_get_bip39_entropy', c_int, [POINTER(ext_key), c_char_p, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('bip85_get_languages', c_int, [c_char_p_p]),
    ('bip85_get_rsa_entropy', c_int, [POINTER(ext_key), c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_addr_segwit_from_bytes', c_int, [c_void_p, c_size_t, c_char_p, c_uint32, c_char_p_p]),
    ('wally_addr_segwit_get_version', c_int, [c_char_p, c_char_p, c_uint32, c_size_t_p]),
    ('wally_addr_segwit_n_get_version', c_int, [c_char_p, c_size_t, c_char_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_addr_segwit_n_to_bytes', c_int, [c_char_p, c_size_t, c_char_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_addr_segwit_to_bytes', c_int, [c_char_p, c_char_p, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_address_to_scriptpubkey', c_int, [c_char_p, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_ae_host_commit_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ae_sig_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ae_signer_commit_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ae_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_aes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_aes_cbc', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_aes_cbc_get_maximum_length', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_aes_cbc_with_ecdh_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_aes_cbc_with_ecdh_key_get_maximum_length', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_aes_len', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_asset_blinding_key_from_seed', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_asset_blinding_key_to_abf', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_asset_blinding_key_to_abf_vbf', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_asset_blinding_key_to_ec_private_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_asset_blinding_key_to_ec_public_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_asset_blinding_key_to_vbf', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_asset_final_vbf', c_int, [POINTER(c_uint64), c_size_t, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_asset_generator_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_asset_pak_whitelistproof', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_asset_pak_whitelistproof_len', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_asset_pak_whitelistproof_size', c_int, [c_size_t, c_size_t_p]),
    ('wally_asset_rangeproof', c_int, [c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint64, c_int, c_int, c_void_p, c_size_t, c_size_t_p]),
    ('wally_asset_rangeproof_get_maximum_len', c_int, [c_uint64, c_int, c_size_t_p]),
    ('wally_asset_rangeproof_with_nonce', c_int, [c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint64, c_int, c_int, c_void_p, c_size_t, c_size_t_p]),
    ('wally_asset_scalar_offset', c_int, [c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_asset_surjectionproof', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_asset_surjectionproof_len', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_asset_surjectionproof_size', c_int, [c_size_t, c_size_t_p]),
    ('wally_asset_unblind', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint64_p]),
    ('wally_asset_unblind_with_nonce', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint64_p]),
    ('wally_asset_value_commitment', c_int, [c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_base58_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_char_p_p]),
    ('wally_base58_get_length', c_int, [c_char_p, c_size_t_p]),
    ('wally_base58_n_get_length', c_int, [c_char_p, c_size_t, c_size_t_p]),
    ('wally_base58_n_to_bytes', c_int, [c_char_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_base58_to_bytes', c_int, [c_char_p, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_base64_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_char_p_p]),
    ('wally_base64_get_maximum_length', c_int, [c_char_p, c_uint32, c_size_t_p]),
    ('wally_base64_n_get_maximum_length', c_int, [c_char_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_base64_n_to_bytes', c_int, [c_char_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_base64_to_bytes', c_int, [c_char_p, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_bip32_key_to_addr_segwit', c_int, [POINTER(ext_key), c_char_p, c_uint32, c_char_p_p]),
    ('wally_bip32_key_to_address', c_int, [POINTER(ext_key), c_uint32, c_uint32, c_char_p_p]),
    ('wally_bip340_tagged_hash', c_int, [c_void_p, c_size_t, c_char_p, c_void_p, c_size_t]),
    ('wally_bip341_control_block_verify', c_int, [c_void_p, c_size_t]),
    ('wally_bzero', c_int, [c_void_p, c_size_t]),
    ('wally_cleanup', c_int, [c_uint32]),
    ('wally_coinselect_assets', c_int, [POINTER(c_uint64), c_size_t, c_uint64, c_uint64, c_uint32, POINTER(c_uint32), c_size_t, c_size_t_p]),
    ('wally_confidential_addr_from_addr', c_int, [c_char_p, c_uint32, c_void_p, c_size_t, c_char_p_p]),
    ('wally_confidential_addr_from_addr_segwit', c_int, [c_char_p, c_char_p, c_char_p, c_void_p, c_size_t, c_char_p_p]),
    ('wally_confidential_addr_segwit_to_ec_public_key', c_int, [c_char_p, c_char_p, c_void_p, c_size_t]),
    ('wally_confidential_addr_to_addr', c_int, [c_char_p, c_uint32, c_char_p_p]),
    ('wally_confidential_addr_to_addr_segwit', c_int, [c_char_p, c_char_p, c_char_p, c_char_p_p]),
    ('wally_confidential_addr_to_ec_public_key', c_int, [c_char_p, c_uint32, c_void_p, c_size_t]),
    ('wally_descriptor_canonicalize', c_int, [c_void_p, c_uint32, c_char_p_p]),
    ('wally_descriptor_derive_bip32_key', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_uint32, c_uint32, POINTER(ext_key)]),
    ('wally_descriptor_derive_bip32_key_alloc', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_uint32, c_uint32, POINTER(POINTER(ext_key))]),
    ('wally_descriptor_free', c_int, [c_void_p]),
    ('wally_descriptor_get_checksum', c_int, [c_void_p, c_uint32, c_char_p_p]),
    ('wally_descriptor_get_depth', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_get_features', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_get_key', c_int, [c_void_p, c_size_t, c_char_p_p]),
    ('wally_descriptor_get_key_child_path_str', c_int, [c_void_p, c_size_t, c_char_p_p]),
    ('wally_descriptor_get_key_child_path_str_len', c_int, [c_void_p, c_size_t, c_size_t_p]),
    ('wally_descriptor_get_key_features', c_int, [c_void_p, c_size_t, c_uint32_p]),
    ('wally_descriptor_get_key_origin_fingerprint', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_descriptor_get_key_origin_path_str', c_int, [c_void_p, c_size_t, c_char_p_p]),
    ('wally_descriptor_get_key_origin_path_str_len', c_int, [c_void_p, c_size_t, c_size_t_p]),
    ('wally_descriptor_get_network', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_get_num_keys', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_get_num_paths', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_get_num_variants', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_get_taproot_control_block', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_descriptor_get_taproot_control_block_len', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_size_t_p]),
    ('wally_descriptor_get_taproot_leaf_hash', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_descriptor_get_taproot_leaf_key_index', c_int, [c_void_p, c_uint32, c_uint32, c_uint32_p]),
    ('wally_descriptor_get_taproot_leaf_num_keys', c_int, [c_void_p, c_uint32, c_uint32_p]),
    ('wally_descriptor_get_taproot_leaf_script', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_descriptor_get_taproot_leaf_script_len', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_size_t_p]),
    ('wally_descriptor_get_taproot_merkle_root', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_descriptor_get_taproot_num_leaves', c_int, [c_void_p, c_uint32_p]),
    ('wally_descriptor_parse', c_int, [c_char_p, POINTER(wally_map), c_uint32, c_uint32, POINTER(c_void_p)]),
    ('wally_descriptor_set_network', c_int, [c_void_p, c_uint32]),
    ('wally_descriptor_to_address', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_char_p_p]),
    ('wally_descriptor_to_addresses', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, POINTER(c_char_p), c_size_t]),
    ('wally_descriptor_to_script', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_descriptor_to_script_get_maximum_length', c_int, [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32, c_size_t_p]),
    ('wally_ec_private_key_bip341_tweak', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ec_private_key_verify', c_int, [c_void_p, c_size_t]),
    ('wally_ec_public_key_bip341_tweak', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ec_public_key_compress', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_public_key_decompress', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_public_key_from_private_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_public_key_negate', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_public_key_strict_verify', c_int, [c_void_p, c_size_t]),
    ('wally_ec_public_key_tweak', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_public_key_verify', c_int, [c_void_p, c_size_t]),
    ('wally_ec_scalar_add', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_scalar_add_to', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_scalar_multiply', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_scalar_multiply_by', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_scalar_subtract', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_scalar_subtract_from', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_scalar_verify', c_int, [c_void_p, c_size_t]),
    ('wally_ec_sig_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ec_sig_from_bytes_aux', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ec_sig_from_bytes_aux_len', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_ec_sig_from_bytes_len', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_ec_sig_from_der', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_sig_normalize', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_sig_to_der', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_ec_sig_to_public_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ec_sig_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_ec_xonly_public_key_verify', c_int, [c_void_p, c_size_t]),
    ('wally_ecdh', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_ecdh_nonce_hash', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_elements_pegin_contract_script_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_elements_pegout_script_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_elements_pegout_script_size', c_int, [c_size_t, c_size_t, c_size_t, c_size_t, c_size_t_p]),
    ('wally_elip150_private_key_to_ec_private_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_elip150_private_key_to_ec_public_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_elip150_public_key_to_ec_public_key', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_explicit_rangeproof', c_int, [c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_explicit_rangeproof_verify', c_int, [c_void_p, c_size_t, c_uint64, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_explicit_surjectionproof', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_explicit_surjectionproof_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_format_bitcoin_message', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_free_string', c_int, [c_char_p]),
    ('wally_get_build_version', c_int, [c_uint32_p]),
    ('wally_get_hash_prevouts', c_int, [c_void_p, c_size_t, POINTER(c_uint32), c_size_t, c_void_p, c_size_t]),
    ('wally_get_operations', c_int, [POINTER(wally_operations)]),
    ('wally_hash160', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_hex_from_bytes', c_int, [c_void_p, c_size_t, c_char_p_p]),
    ('wally_hex_n_to_bytes', c_int, [c_char_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_hex_n_verify', c_int, [c_char_p, c_size_t]),
    ('wally_hex_to_bytes', c_int, [c_char_p, c_void_p, c_size_t, c_size_t_p]),
    ('wally_hex_verify', c_int, [c_char_p]),
    ('wally_hmac_sha256', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_hmac_sha512', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_init', c_int, [c_uint32]),
    ('wally_is_elements_build', c_int, [c_size_t_p]),
    ('wally_keypath_bip32_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_keypath_get_fingerprint', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_keypath_get_path', c_int, [c_void_p, c_size_t, POINTER(c_uint32), c_size_t, c_size_t_p]),
    ('wally_keypath_get_path_len', c_int, [c_void_p, c_size_t, c_size_t_p]),
    ('wally_keypath_public_key_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_keypath_xonly_public_key_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_map_add', c_int, [POINTER(wally_map), c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_map_add_integer', c_int, [POINTER(wally_map), c_uint32, c_void_p, c_size_t]),
    ('wally_map_assign', c_int, [POINTER(wally_map), POINTER(wally_map)]),
    ('wally_map_clear', c_int, [POINTER(wally_map)]),
    ('wally_map_combine', c_int, [POINTER(wally_map), POINTER(wally_map)]),
    ('wally_map_find', c_int, [POINTER(wally_map), c_void_p, c_size_t, c_size_t_p]),
    ('wally_map_find_bip32_public_key_from', c_int, [POINTER(wally_map), c_size_t, POINTER(ext_key), c_size_t_p]),
    ('wally_map_find_from', c_int, [POINTER(wally_map), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_map_find_integer', c_int, [POINTER(wally_map), c_uint32, c_size_t_p]),
    ('wally_map_free', c_int, [POINTER(wally_map)]),
    ('wally_map_get_item', c_int, [POINTER(wally_map), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_map_get_item_integer_key', c_int, [POINTER(wally_map), c_size_t, c_size_t_p]),
    ('wally_map_get_item_key', c_int, [POINTER(wally_map), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_map_get_item_key_length', c_int, [POINTER(wally_map), c_size_t, c_size_t_p]),
    ('wally_map_get_item_length', c_int, [POINTER(wally_map), c_size_t, c_size_t_p]),
    ('wally_map_get_num_items', c_int, [POINTER(wally_map), c_size_t_p]),
    ('wally_map_hash_preimage_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_map_init', c_int, [c_size_t, c_void_p, POINTER(wally_map)]),
    ('wally_map_init_alloc', c_int, [c_size_t, c_void_p, POINTER(POINTER(wally_map))]),
    ('wally_map_keypath_add', c_int, [POINTER(wally_map), c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_map_keypath_bip32_init_alloc', c_int, [c_size_t, POINTER(POINTER(wally_map))]),
    ('wally_map_keypath_get_bip32_key_from', c_int, [POINTER(wally_map), c_size_t, POINTER(ext_key), POINTER(ext_key), c_size_t_p]),
    ('wally_map_keypath_get_bip32_key_from_alloc', c_int, [POINTER(wally_map), c_size_t, POINTER(ext_key), POINTER(POINTER(ext_key))]),
    ('wally_map_keypath_get_bip32_public_key_from', c_int, [POINTER(wally_map), c_size_t, POINTER(ext_key), POINTER(ext_key), c_size_t_p]),
    ('wally_map_keypath_get_item_fingerprint', c_int, [POINTER(wally_map), c_size_t, c_void_p, c_size_t]),
    ('wally_map_keypath_get_item_path', c_int, [POINTER(wally_map), c_size_t, POINTER(c_uint32), c_size_t, c_size_t_p]),
    ('wally_map_keypath_get_item_path_len', c_int, [POINTER(wally_map), c_size_t, c_size_t_p]),
    ('wally_map_keypath_public_key_init_alloc', c_int, [c_size_t, POINTER(POINTER(wally_map))]),
    ('wally_map_merkle_path_add', c_int, [POINTER(wally_map), c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_map_preimage_hash160_add', c_int, [POINTER(wally_map), c_void_p, c_size_t]),
    ('wally_map_preimage_init_alloc', c_int, [c_size_t, POINTER(POINTER(wally_map))]),
    ('wally_map_preimage_ripemd160_add', c_int, [POINTER(wally_map), c_void_p, c_size_t]),
    ('wally_map_preimage_sha256_add', c_int, [POINTER(wally_map), c_void_p, c_size_t]),
    ('wally_map_preimage_sha256d_add', c_int, [POINTER(wally_map), c_void_p, c_size_t]),
    ('wally_map_remove', c_int, [POINTER(wally_map), c_void_p, c_size_t]),
    ('wally_map_remove_integer', c_int, [POINTER(wally_map), c_uint32]),
    ('wally_map_replace', c_int, [POINTER(wally_map), c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_map_replace_integer', c_int, [POINTER(wally_map), c_uint32, c_void_p, c_size_t]),
    ('wally_map_sort', c_int, [POINTER(wally_map), c_uint32]),
    ('wally_merkle_path_xonly_public_key_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_pbkdf2_hmac_sha256', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_pbkdf2_hmac_sha512', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_psbt_add_global_scalar', c_int, [POINTER(wally_psbt), c_void_p, c_size_t]),
    ('wally_psbt_add_input_keypath', c_int, [POINTER(wally_psbt), c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_add_input_taproot_keypath', c_int, [POINTER(wally_psbt), c_uint32, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_add_output_keypath', c_int, [POINTER(wally_psbt), c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_add_output_taproot_keypath', c_int, [POINTER(wally_psbt), c_uint32, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_add_tx_input_at', c_int, [POINTER(wally_psbt), c_uint32, c_uint32, POINTER(wally_tx_input)]),
    ('wally_psbt_add_tx_output_at', c_int, [POINTER(wally_psbt), c_uint32, c_uint32, POINTER(wally_tx_output)]),
    ('wally_psbt_blind', c_int, [POINTER(wally_psbt), POINTER(wally_map), POINTER(wally_map), POINTER(wally_map), POINTER(wally_map), c_void_p, c_size_t, c_uint32, c_uint32, POINTER(wally_map)]),
    ('wally_psbt_blind_alloc', c_int, [POINTER(wally_psbt), POINTER(wally_map), POINTER(wally_map), POINTER(wally_map), POINTER(wally_map), c_void_p, c_size_t, c_uint32, c_uint32, POINTER(POINTER(wally_map))]),
    ('wally_psbt_clear_fallback_locktime', c_int, [POINTER(wally_psbt)]),
    ('wally_psbt_clone_alloc', c_int, [POINTER(wally_psbt), c_uint32, POINTER(POINTER(wally_psbt))]),
    ('wally_psbt_combine', c_int, [POINTER(wally_psbt), POINTER(wally_psbt)]),
    ('wally_psbt_combine_ex', c_int, [POINTER(wally_psbt), c_uint32, POINTER(wally_psbt)]),
    ('wally_psbt_extract', c_int, [POINTER(wally_psbt), c_uint32, POINTER(POINTER(wally_tx))]),
    ('wally_psbt_finalize', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_finalize_input', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_find_global_scalar', c_int, [POINTER(wally_psbt), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_find_input_spending_utxo', c_int, [POINTER(wally_psbt), c_void_p, c_size_t, c_uint32, c_size_t_p]),
    ('wally_psbt_free', c_int, [POINTER(wally_psbt)]),
    ('wally_psbt_from_base64', c_int, [c_char_p, c_uint32, POINTER(POINTER(wally_psbt))]),
    ('wally_psbt_from_base64_n', c_int, [c_char_p, c_size_t, c_uint32, POINTER(POINTER(wally_psbt))]),
    ('wally_psbt_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, POINTER(POINTER(wally_psbt))]),
    ('wally_psbt_from_tx', c_int, [POINTER(wally_tx), c_uint32, c_uint32, POINTER(POINTER(wally_psbt))]),
    ('wally_psbt_get_global_genesis_blockhash', c_int, [POINTER(wally_psbt), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_id', c_int, [POINTER(wally_psbt), c_uint32, c_void_p, c_size_t]),
    ('wally_psbt_get_input_bip32_key_from_alloc', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_uint32, POINTER(ext_key), POINTER(POINTER(ext_key))]),
    ('wally_psbt_get_input_scriptcode', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_scriptcode_len', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_signature_hash', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_tx), c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_psbt_get_input_signing_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_signing_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_length', c_int, [POINTER(wally_psbt), c_uint32, c_size_t_p]),
    ('wally_psbt_get_locktime', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_tx_version', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_has_global_genesis_blockhash', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_init_alloc', c_int, [c_uint32, c_size_t, c_size_t, c_size_t, c_uint32, POINTER(POINTER(wally_psbt))]),
    ('wally_psbt_input_add_signature', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_input_clear_amount_rangeproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_asset', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_asset_surjectionproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_inflation_keys_blinding_rangeproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_inflation_keys_commitment', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_inflation_keys_rangeproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_issuance_amount_blinding_rangeproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_issuance_amount_commitment', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_issuance_amount_rangeproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_issuance_asset_entropy', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_issuance_blinding_nonce', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_pegin_claim_script', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_pegin_genesis_blockhash', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_pegin_txout_proof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_required_lockheight', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_required_locktime', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_sequence', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_clear_utxo_rangeproof', c_int, [POINTER(wally_psbt_input)]),
    ('wally_psbt_input_find_keypath', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_find_signature', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_find_unknown', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_generate_explicit_proofs', c_int, [POINTER(wally_psbt_input), c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_input_get_amount_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_amount_rangeproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_asset', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_asset_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_asset_surjectionproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_asset_surjectionproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_inflation_keys_blinding_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_inflation_keys_blinding_rangeproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_inflation_keys_commitment', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_inflation_keys_commitment_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_inflation_keys_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_inflation_keys_rangeproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_issuance_amount_blinding_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_issuance_amount_blinding_rangeproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_issuance_amount_commitment', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_issuance_amount_commitment_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_issuance_amount_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_issuance_amount_rangeproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_issuance_asset_entropy', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_issuance_asset_entropy_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_issuance_blinding_nonce', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_issuance_blinding_nonce_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_pegin_claim_script', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_pegin_claim_script_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_pegin_genesis_blockhash', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_pegin_genesis_blockhash_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_pegin_txout_proof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_pegin_txout_proof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_get_utxo_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_input_get_utxo_rangeproof_len', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_is_finalized', c_int, [POINTER(wally_psbt_input), c_size_t_p]),
    ('wally_psbt_input_keypath_add', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_input_set_amount', c_int, [POINTER(wally_psbt_input), c_uint64]),
    ('wally_psbt_input_set_amount_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_asset', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_asset_surjectionproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_final_scriptsig', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_final_witness', c_int, [POINTER(wally_psbt_input), POINTER(wally_tx_witness_stack)]),
    ('wally_psbt_input_set_inflation_keys', c_int, [POINTER(wally_psbt_input), c_uint64]),
    ('wally_psbt_input_set_inflation_keys_blinding_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_inflation_keys_commitment', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_inflation_keys_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_issuance_amount', c_int, [POINTER(wally_psbt_input), c_uint64]),
    ('wally_psbt_input_set_issuance_amount_blinding_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_issuance_amount_commitment', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_issuance_amount_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_issuance_asset_entropy', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_issuance_blinding_nonce', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_keypaths', c_int, [POINTER(wally_psbt_input), POINTER(wally_map)]),
    ('wally_psbt_input_set_output_index', c_int, [POINTER(wally_psbt_input), c_uint32]),
    ('wally_psbt_input_set_pegin_amount', c_int, [POINTER(wally_psbt_input), c_uint64]),
    ('wally_psbt_input_set_pegin_claim_script', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_pegin_genesis_blockhash', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_pegin_tx', c_int, [POINTER(wally_psbt_input), POINTER(wally_tx)]),
    ('wally_psbt_input_set_pegin_txout_proof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_pegin_witness', c_int, [POINTER(wally_psbt_input), POINTER(wally_tx_witness_stack)]),
    ('wally_psbt_input_set_previous_txid', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_redeem_script', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_required_lockheight', c_int, [POINTER(wally_psbt_input), c_uint32]),
    ('wally_psbt_input_set_required_locktime', c_int, [POINTER(wally_psbt_input), c_uint32]),
    ('wally_psbt_input_set_sequence', c_int, [POINTER(wally_psbt_input), c_uint32]),
    ('wally_psbt_input_set_sighash', c_int, [POINTER(wally_psbt_input), c_uint32]),
    ('wally_psbt_input_set_signatures', c_int, [POINTER(wally_psbt_input), POINTER(wally_map)]),
    ('wally_psbt_input_set_taproot_internal_key', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_taproot_signature', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_unknowns', c_int, [POINTER(wally_psbt_input), POINTER(wally_map)]),
    ('wally_psbt_input_set_utxo', c_int, [POINTER(wally_psbt_input), POINTER(wally_tx)]),
    ('wally_psbt_input_set_utxo_rangeproof', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_witness_script', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t]),
    ('wally_psbt_input_set_witness_utxo', c_int, [POINTER(wally_psbt_input), POINTER(wally_tx_output)]),
    ('wally_psbt_input_set_witness_utxo_from_tx', c_int, [POINTER(wally_psbt_input), POINTER(wally_tx), c_uint32]),
    ('wally_psbt_input_taproot_keypath_add', c_int, [POINTER(wally_psbt_input), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_is_elements', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_is_finalized', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_is_input_finalized', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_output_clear_amount', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_asset', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_asset_blinding_surjectionproof', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_asset_commitment', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_asset_surjectionproof', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_blinder_index', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_blinding_public_key', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_ecdh_public_key', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_value_blinding_rangeproof', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_value_commitment', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_clear_value_rangeproof', c_int, [POINTER(wally_psbt_output)]),
    ('wally_psbt_output_find_keypath', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_find_unknown', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_asset', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_asset_blinding_surjectionproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_asset_blinding_surjectionproof_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_asset_commitment', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_asset_commitment_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_asset_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_asset_surjectionproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_asset_surjectionproof_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_blinding_public_key', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_blinding_public_key_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_blinding_status', c_int, [POINTER(wally_psbt_output), c_uint32, c_size_t_p]),
    ('wally_psbt_output_get_ecdh_public_key', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_ecdh_public_key_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_value_blinding_rangeproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_value_blinding_rangeproof_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_value_commitment', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_value_commitment_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_get_value_rangeproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_output_get_value_rangeproof_len', c_int, [POINTER(wally_psbt_output), c_size_t_p]),
    ('wally_psbt_output_keypath_add', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_output_set_amount', c_int, [POINTER(wally_psbt_output), c_uint64]),
    ('wally_psbt_output_set_asset', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_asset_blinding_surjectionproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_asset_commitment', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_asset_surjectionproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_blinder_index', c_int, [POINTER(wally_psbt_output), c_uint32]),
    ('wally_psbt_output_set_blinding_public_key', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_ecdh_public_key', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_keypaths', c_int, [POINTER(wally_psbt_output), POINTER(wally_map)]),
    ('wally_psbt_output_set_redeem_script', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_script', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_taproot_internal_key', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_unknowns', c_int, [POINTER(wally_psbt_output), POINTER(wally_map)]),
    ('wally_psbt_output_set_value_blinding_rangeproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_value_commitment', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_value_rangeproof', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_set_witness_script', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t]),
    ('wally_psbt_output_taproot_keypath_add', c_int, [POINTER(wally_psbt_output), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t]),
    ('wally_psbt_remove_input', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_remove_output', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_set_fallback_locktime', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_set_global_genesis_blockhash', c_int, [POINTER(wally_psbt), c_void_p, c_size_t]),
    ('wally_psbt_set_global_scalars', c_int, [POINTER(wally_psbt), POINTER(wally_map)]),
    ('wally_psbt_set_global_tx', c_int, [POINTER(wally_psbt), POINTER(wally_tx)]),
    ('wally_psbt_set_pset_modifiable_flags', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_set_tx_modifiable_flags', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_set_tx_version', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_set_version', c_int, [POINTER(wally_psbt), c_uint32, c_uint32]),
    ('wally_psbt_sign', c_int, [POINTER(wally_psbt), c_void_p, c_size_t, c_uint32]),
    ('wally_psbt_sign_bip32', c_int, [POINTER(wally_psbt), POINTER(ext_key), c_uint32]),
    ('wally_psbt_sign_input_bip32', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_void_p, c_size_t, POINTER(ext_key), c_uint32]),
    ('wally_psbt_signing_cache_disable', c_int, [POINTER(wally_psbt)]),
    ('wally_psbt_signing_cache_enable', c_int, [POINTER(wally_psbt), c_uint32]),
    ('wally_psbt_to_base64', c_int, [POINTER(wally_psbt), c_uint32, c_char_p_p]),
    ('wally_psbt_to_bytes', c_int, [POINTER(wally_psbt), c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_ripemd160', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_s2c_commitment_verify', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32]),
    ('wally_s2c_sig_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_script_push_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_csv_2of2_then_1_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_csv_2of2_then_1_from_bytes_opt', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_csv_blocks_from_csv_2of2_then_1', c_int, [c_void_p, c_size_t, c_uint32_p]),
    ('wally_scriptpubkey_get_type', c_int, [c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_multisig_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_op_return_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_p2pkh_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_p2sh_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_p2tr_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptpubkey_to_address', c_int, [c_void_p, c_size_t, c_uint32, c_char_p_p]),
    ('wally_scriptsig_multisig_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptsig_p2pkh_from_der', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scriptsig_p2pkh_from_sig', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_scrypt', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_secp_randomize', c_int, [c_void_p, c_size_t]),
    ('wally_set_operations', c_int, [POINTER(wally_operations)]),
    ('wally_sha256', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_sha256_midstate', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_sha256d', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_sha512', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_symmetric_key_from_parent', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_symmetric_key_from_seed', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_tx_add_elements_raw_input', c_int, [POINTER(wally_tx), c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_uint32]),
    ('wally_tx_add_elements_raw_input_at', c_int, [POINTER(wally_tx), c_uint32, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_uint32]),
    ('wally_tx_add_elements_raw_output', c_int, [POINTER(wally_tx), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32]),
    ('wally_tx_add_elements_raw_output_at', c_int, [POINTER(wally_tx), c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32]),
    ('wally_tx_add_input', c_int, [POINTER(wally_tx), POINTER(wally_tx_input)]),
    ('wally_tx_add_input_at', c_int, [POINTER(wally_tx), c_uint32, POINTER(wally_tx_input)]),
    ('wally_tx_add_output', c_int, [POINTER(wally_tx), POINTER(wally_tx_output)]),
    ('wally_tx_add_output_at', c_int, [POINTER(wally_tx), c_uint32, POINTER(wally_tx_output)]),
    ('wally_tx_add_raw_input', c_int, [POINTER(wally_tx), c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_uint32]),
    ('wally_tx_add_raw_input_at', c_int, [POINTER(wally_tx), c_uint32, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_uint32]),
    ('wally_tx_add_raw_output', c_int, [POINTER(wally_tx), c_uint64, c_void_p, c_size_t, c_uint32]),
    ('wally_tx_add_raw_output_at', c_int, [POINTER(wally_tx), c_uint32, c_uint64, c_void_p, c_size_t, c_uint32]),
    ('wally_tx_clone_alloc', c_int, [POINTER(wally_tx), c_uint32, POINTER(POINTER(wally_tx))]),
    ('wally_tx_confidential_value_from_satoshi', c_int, [c_uint64, c_void_p, c_size_t]),
    ('wally_tx_confidential_value_to_satoshi', c_int, [c_void_p, c_size_t, c_uint64_p]),
    ('wally_tx_elements_input_init_alloc', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), POINTER(POINTER(wally_tx_input))]),
    ('wally_tx_elements_input_is_pegin', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_elements_input_issuance_free', c_int, [POINTER(wally_tx_input)]),
    ('wally_tx_elements_input_issuance_set', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_tx_elements_issuance_calculate_asset', c_int, [c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_tx_elements_issuance_calculate_reissuance_token', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t]),
    ('wally_tx_elements_issuance_generate_entropy', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_tx_elements_output_commitment_free', c_int, [POINTER(wally_tx_output)]),
    ('wally_tx_elements_output_commitment_set', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_tx_elements_output_init', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(wally_tx_output)]),
    ('wally_tx_elements_output_init_alloc', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, POINTER(POINTER(wally_tx_output))]),
    ('wally_tx_free', c_int, [POINTER(wally_tx)]),
    ('wally_tx_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, POINTER(POINTER(wally_tx))]),
    ('wally_tx_from_hex', c_int, [c_char_p, c_uint32, POINTER(POINTER(wally_tx))]),
    ('wally_tx_get_btc_signature_hash', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_uint64, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_tx_get_btc_taproot_signature_hash', c_int, [POINTER(wally_tx), c_size_t, POINTER(wally_map), POINTER(c_uint64), c_size_t, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_tx_get_elements_signature_hash', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_tx_get_elements_weight_discount', c_int, [POINTER(wally_tx), c_uint32, c_size_t_p]),
    ('wally_tx_get_hash_prevouts', c_int, [POINTER(wally_tx), c_size_t, c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_input_signature_hash', c_int, [POINTER(wally_tx), c_size_t, POINTER(wally_map), POINTER(wally_map), POINTER(wally_map), c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_uint32, POINTER(wally_map), c_void_p, c_size_t]),
    ('wally_tx_get_length', c_int, [POINTER(wally_tx), c_uint32, c_size_t_p]),
    ('wally_tx_get_signature_hash', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, c_uint64, c_uint32, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_tx_get_total_output_satoshi', c_int, [POINTER(wally_tx), c_uint64_p]),
    ('wally_tx_get_txid', c_int, [POINTER(wally_tx), c_void_p, c_size_t]),
    ('wally_tx_get_vsize', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_get_weight', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_get_witness_count', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_init_alloc', c_int, [c_uint32, c_uint32, c_size_t, c_size_t, POINTER(POINTER(wally_tx))]),
    ('wally_tx_input_clone', c_int, [POINTER(wally_tx_input), POINTER(wally_tx_input)]),
    ('wally_tx_input_clone_alloc', c_int, [POINTER(wally_tx_input), POINTER(POINTER(wally_tx_input))]),
    ('wally_tx_input_free', c_int, [POINTER(wally_tx_input)]),
    ('wally_tx_input_init_alloc', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, POINTER(wally_tx_witness_stack), POINTER(POINTER(wally_tx_input))]),
    ('wally_tx_is_coinbase', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_is_elements', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_output_clone', c_int, [POINTER(wally_tx_output), POINTER(wally_tx_output)]),
    ('wally_tx_output_clone_alloc', c_int, [POINTER(wally_tx_output), POINTER(POINTER(wally_tx_output))]),
    ('wally_tx_output_free', c_int, [POINTER(wally_tx_output)]),
    ('wally_tx_output_init', c_int, [c_uint64, c_void_p, c_size_t, POINTER(wally_tx_output)]),
    ('wally_tx_output_init_alloc', c_int, [c_uint64, c_void_p, c_size_t, POINTER(POINTER(wally_tx_output))]),
    ('wally_tx_remove_input', c_int, [POINTER(wally_tx), c_size_t]),
    ('wally_tx_remove_output', c_int, [POINTER(wally_tx), c_size_t]),
    ('wally_tx_set_input_script', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_witness', c_int, [POINTER(wally_tx), c_size_t, POINTER(wally_tx_witness_stack)]),
    ('wally_tx_to_bytes', c_int, [POINTER(wally_tx), c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_to_hex', c_int, [POINTER(wally_tx), c_uint32, c_char_p_p]),
    ('wally_tx_vsize_from_weight', c_int, [c_size_t, c_size_t_p]),
    ('wally_tx_witness_stack_add', c_int, [POINTER(wally_tx_witness_stack), c_void_p, c_size_t]),
    ('wally_tx_witness_stack_add_dummy', c_int, [POINTER(wally_tx_witness_stack), c_uint32]),
    ('wally_tx_witness_stack_clone_alloc', c_int, [POINTER(wally_tx_witness_stack), POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_tx_witness_stack_free', c_int, [POINTER(wally_tx_witness_stack)]),
    ('wally_tx_witness_stack_from_bytes', c_int, [c_void_p, c_size_t, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_tx_witness_stack_get_length', c_int, [POINTER(wally_tx_witness_stack), c_size_t_p]),
    ('wally_tx_witness_stack_get_num_items', c_int, [POINTER(wally_tx_witness_stack), c_size_t_p]),
    ('wally_tx_witness_stack_init_alloc', c_int, [c_size_t, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_tx_witness_stack_set', c_int, [POINTER(wally_tx_witness_stack), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_witness_stack_set_dummy', c_int, [POINTER(wally_tx_witness_stack), c_size_t, c_uint32]),
    ('wally_tx_witness_stack_to_bytes', c_int, [POINTER(wally_tx_witness_stack), c_void_p, c_size_t, c_size_t_p]),
    ('wally_varbuff_get_length', c_int, [c_void_p, c_size_t, c_size_t_p]),
    ('wally_varbuff_to_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_varint_get_length', c_int, [c_uint64, c_size_t_p]),
    ('wally_varint_to_bytes', c_int, [c_uint64, c_void_p, c_size_t, c_size_t_p]),
    ('wally_wif_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_char_p_p]),
    ('wally_wif_is_uncompressed', c_int, [c_char_p, c_size_t_p]),
    ('wally_wif_to_address', c_int, [c_char_p, c_uint32, c_uint32, c_char_p_p]),
    ('wally_wif_to_bytes', c_int, [c_char_p, c_uint32, c_uint32, c_void_p, c_size_t]),
    ('wally_wif_to_public_key', c_int, [c_char_p, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_witness_multisig_from_bytes', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, POINTER(c_uint32), c_size_t, c_uint32, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_witness_p2tr_from_sig', c_int, [c_void_p, c_size_t, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_witness_p2wpkh_from_der', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_witness_p2wpkh_from_sig', c_int, [c_void_p, c_size_t, c_void_p, c_size_t, c_uint32, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_witness_program_from_bytes', c_int, [c_void_p, c_size_t, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    ('wally_witness_program_from_bytes_and_version', c_int, [c_void_p, c_size_t, c_uint32, c_uint32, c_void_p, c_size_t, c_size_t_p]),
    # END AUTOGENERATED
    # Internal functions, only available if built with SWIG support
    # BEGIN INTERNAL AUTOGENERATED
    ('bip32_key_get_chain_code', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_get_child_num', c_int, [POINTER(ext_key), c_size_t_p]),
    ('bip32_key_get_depth', c_int, [POINTER(ext_key), c_size_t_p]),
    ('bip32_key_get_hash160', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_get_parent160', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_get_priv_key', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_get_pub_key', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_get_pub_key_tweak_sum', c_int, [POINTER(ext_key), c_void_p, c_size_t]),
    ('bip32_key_get_version', c_int, [POINTER(ext_key), c_size_t_p]),
    ('wally_psbt_add_input_signature', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_clear_input_amount', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_amount_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_asset', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_asset_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_inflation_keys_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_inflation_keys_commitment', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_inflation_keys_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_issuance_amount_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_issuance_amount_commitment', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_issuance_amount_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_issuance_asset_entropy', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_issuance_blinding_nonce', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_pegin_claim_script', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_pegin_genesis_blockhash', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_pegin_txout_proof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_required_lockheight', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_required_locktime', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_sequence', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_input_utxo_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_amount', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_asset', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_asset_blinding_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_asset_commitment', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_asset_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_blinder_index', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_blinding_public_key', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_ecdh_public_key', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_value_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_value_commitment', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_clear_output_value_rangeproof', c_int, [POINTER(wally_psbt), c_size_t]),
    ('wally_psbt_find_input_keypath', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_find_input_signature', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_find_input_unknown', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_find_output_keypath', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_find_output_unknown', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_generate_input_explicit_proofs', c_int, [POINTER(wally_psbt), c_size_t, c_uint64, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_get_fallback_locktime', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_global_scalar', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_get_global_scalars_size', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_global_tx_alloc', c_int, [POINTER(wally_psbt), POINTER(POINTER(wally_tx))]),
    ('wally_psbt_get_input_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64_p]),
    ('wally_psbt_get_input_amount_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_amount_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_asset', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_asset_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_asset_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_asset_surjectionproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_best_utxo', c_int, [POINTER(wally_psbt), c_size_t, POINTER(POINTER(wally_tx_output))]),
    ('wally_psbt_get_input_best_utxo_alloc', c_int, [POINTER(wally_psbt), c_size_t, POINTER(POINTER(wally_tx_output))]),
    ('wally_psbt_get_input_final_scriptsig', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_final_scriptsig_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_final_witness_alloc', c_int, [POINTER(wally_psbt), c_size_t, POINTER(POINTER(wally_tx_witness_stack))]),
    ('wally_psbt_get_input_inflation_keys', c_int, [POINTER(wally_psbt), c_size_t, c_uint64_p]),
    ('wally_psbt_get_input_inflation_keys_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_inflation_keys_blinding_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_inflation_keys_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_inflation_keys_commitment_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_inflation_keys_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_inflation_keys_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64_p]),
    ('wally_psbt_get_input_issuance_amount_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_amount_blinding_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_amount_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_amount_commitment_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_amount_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_amount_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_asset_entropy', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_asset_entropy_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_blinding_nonce', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_issuance_blinding_nonce_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_keypath', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_keypath_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_keypaths_size', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_output_index', c_int, [POINTER(wally_psbt), c_size_t, c_uint32_p]),
    ('wally_psbt_get_input_pegin_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64_p]),
    ('wally_psbt_get_input_pegin_claim_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_pegin_claim_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_pegin_genesis_blockhash', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_pegin_genesis_blockhash_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_pegin_txout_proof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_pegin_txout_proof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_previous_txid', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_get_input_redeem_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_redeem_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_required_lockheight', c_int, [POINTER(wally_psbt), c_size_t, c_uint32_p]),
    ('wally_psbt_get_input_required_locktime', c_int, [POINTER(wally_psbt), c_size_t, c_uint32_p]),
    ('wally_psbt_get_input_sequence', c_int, [POINTER(wally_psbt), c_size_t, c_uint32_p]),
    ('wally_psbt_get_input_sighash', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_signature', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_signature_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_signature_type', c_int, [POINTER(wally_psbt), c_size_t, c_uint32_p]),
    ('wally_psbt_get_input_signatures_size', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_taproot_internal_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_taproot_internal_key_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_taproot_signature', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_taproot_signature_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_unknown', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_unknown_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_unknowns_size', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_utxo_alloc', c_int, [POINTER(wally_psbt), c_size_t, POINTER(POINTER(wally_tx))]),
    ('wally_psbt_get_input_utxo_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_utxo_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_witness_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_witness_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_input_witness_utxo_alloc', c_int, [POINTER(wally_psbt), c_size_t, POINTER(POINTER(wally_tx_output))]),
    ('wally_psbt_get_num_inputs', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_num_outputs', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_output_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64_p]),
    ('wally_psbt_get_output_asset', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_blinding_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_blinding_surjectionproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_commitment_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_asset_surjectionproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_blinder_index', c_int, [POINTER(wally_psbt), c_size_t, c_uint32_p]),
    ('wally_psbt_get_output_blinding_public_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_blinding_public_key_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_blinding_status', c_int, [POINTER(wally_psbt), c_size_t, c_uint32, c_size_t_p]),
    ('wally_psbt_get_output_ecdh_public_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_ecdh_public_key_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_keypath', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_keypath_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_keypaths_size', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_redeem_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_redeem_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_taproot_internal_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_taproot_internal_key_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_unknown', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_unknown_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_unknowns_size', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_value_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_value_blinding_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_value_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_value_commitment_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_value_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_value_rangeproof_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_witness_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_psbt_get_output_witness_script_len', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_get_pset_modifiable_flags', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_tx_modifiable_flags', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_get_version', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_has_fallback_locktime', c_int, [POINTER(wally_psbt), c_size_t_p]),
    ('wally_psbt_has_input_amount', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_has_input_required_lockheight', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_has_input_required_locktime', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_has_output_amount', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_has_output_blinder_index', c_int, [POINTER(wally_psbt), c_size_t, c_size_t_p]),
    ('wally_psbt_set_input_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64]),
    ('wally_psbt_set_input_amount_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_asset', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_asset_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_final_scriptsig', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_final_witness', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_tx_witness_stack)]),
    ('wally_psbt_set_input_inflation_keys', c_int, [POINTER(wally_psbt), c_size_t, c_uint64]),
    ('wally_psbt_set_input_inflation_keys_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_inflation_keys_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_inflation_keys_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_issuance_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64]),
    ('wally_psbt_set_input_issuance_amount_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_issuance_amount_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_issuance_amount_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_issuance_asset_entropy', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_issuance_blinding_nonce', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_keypaths', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_map)]),
    ('wally_psbt_set_input_output_index', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_set_input_pegin_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64]),
    ('wally_psbt_set_input_pegin_claim_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_pegin_genesis_blockhash', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_pegin_txout_proof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_previous_txid', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_redeem_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_required_lockheight', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_set_input_required_locktime', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_set_input_sequence', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_set_input_sighash', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_set_input_signatures', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_map)]),
    ('wally_psbt_set_input_taproot_internal_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_taproot_signature', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_unknowns', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_map)]),
    ('wally_psbt_set_input_utxo', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_tx)]),
    ('wally_psbt_set_input_utxo_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_witness_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_input_witness_utxo', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_tx_output)]),
    ('wally_psbt_set_input_witness_utxo_from_tx', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_tx), c_uint32]),
    ('wally_psbt_set_output_amount', c_int, [POINTER(wally_psbt), c_size_t, c_uint64]),
    ('wally_psbt_set_output_asset', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_asset_blinding_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_asset_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_asset_surjectionproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_blinder_index', c_int, [POINTER(wally_psbt), c_size_t, c_uint32]),
    ('wally_psbt_set_output_blinding_public_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_ecdh_public_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_keypaths', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_map)]),
    ('wally_psbt_set_output_redeem_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_taproot_internal_key', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_unknowns', c_int, [POINTER(wally_psbt), c_size_t, POINTER(wally_map)]),
    ('wally_psbt_set_output_value_blinding_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_value_commitment', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_value_rangeproof', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_psbt_set_output_witness_script', c_int, [POINTER(wally_psbt), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_input_blinding_nonce', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_input_entropy', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_input_index', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_inflation_keys', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_inflation_keys_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_inflation_keys_rangeproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_inflation_keys_rangeproof_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_issuance_amount', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_issuance_amount_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_issuance_amount_rangeproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_issuance_amount_rangeproof_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_script', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_script_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_sequence', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_input_txhash', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_input_witness', c_int, [POINTER(wally_tx), c_size_t, c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_witness_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t, c_size_t_p]),
    ('wally_tx_get_input_witness_num_items', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_locktime', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_get_num_inputs', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_get_num_outputs', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_get_output_asset', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_output_nonce', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_get_output_rangeproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_output_rangeproof_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_output_satoshi', c_int, [POINTER(wally_tx), c_size_t, c_uint64_p]),
    ('wally_tx_get_output_script', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_output_script_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_output_surjectionproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_output_surjectionproof_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_output_value', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_get_output_value_len', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_get_version', c_int, [POINTER(wally_tx), c_size_t_p]),
    ('wally_tx_input_get_blinding_nonce', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_get_entropy', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_get_index', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_inflation_keys', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_input_get_inflation_keys_len', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_inflation_keys_rangeproof', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_input_get_inflation_keys_rangeproof_len', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_issuance_amount', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_input_get_issuance_amount_len', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_issuance_amount_rangeproof', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_input_get_issuance_amount_rangeproof_len', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_script', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_input_get_script_len', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_sequence', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_get_txhash', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_get_witness', c_int, [POINTER(wally_tx_input), c_size_t, c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_input_get_witness_len', c_int, [POINTER(wally_tx_input), c_size_t, c_size_t_p]),
    ('wally_tx_input_get_witness_num_items', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_is_issuance', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_is_pegin', c_int, [POINTER(wally_tx_input), c_size_t_p]),
    ('wally_tx_input_set_blinding_nonce', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_entropy', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_index', c_int, [POINTER(wally_tx_input), c_uint32]),
    ('wally_tx_input_set_inflation_keys', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_inflation_keys_rangeproof', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_issuance_amount', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_issuance_amount_rangeproof', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_script', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_sequence', c_int, [POINTER(wally_tx_input), c_uint32]),
    ('wally_tx_input_set_txhash', c_int, [POINTER(wally_tx_input), c_void_p, c_size_t]),
    ('wally_tx_input_set_witness', c_int, [POINTER(wally_tx_input), POINTER(wally_tx_witness_stack)]),
    ('wally_tx_is_input_issuance', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_is_input_pegin', c_int, [POINTER(wally_tx), c_size_t, c_size_t_p]),
    ('wally_tx_output_get_asset', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_get_asset_len', c_int, [POINTER(wally_tx_output), c_size_t_p]),
    ('wally_tx_output_get_nonce', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_get_nonce_len', c_int, [POINTER(wally_tx_output), c_size_t_p]),
    ('wally_tx_output_get_rangeproof', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_output_get_rangeproof_len', c_int, [POINTER(wally_tx_output), c_size_t_p]),
    ('wally_tx_output_get_satoshi', c_int, [POINTER(wally_tx_output), c_uint64_p]),
    ('wally_tx_output_get_script', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_output_get_script_len', c_int, [POINTER(wally_tx_output), c_size_t_p]),
    ('wally_tx_output_get_surjectionproof', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_output_get_surjectionproof_len', c_int, [POINTER(wally_tx_output), c_size_t_p]),
    ('wally_tx_output_get_value', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t, c_size_t_p]),
    ('wally_tx_output_get_value_len', c_int, [POINTER(wally_tx_output), c_size_t_p]),
    ('wally_tx_output_set_asset', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_set_nonce', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_set_rangeproof', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_set_satoshi', c_int, [POINTER(wally_tx_output), c_uint64]),
    ('wally_tx_output_set_script', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_set_surjectionproof', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_output_set_value', c_int, [POINTER(wally_tx_output), c_void_p, c_size_t]),
    ('wally_tx_set_input_blinding_nonce', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_entropy', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_index', c_int, [POINTER(wally_tx), c_size_t, c_uint32]),
    ('wally_tx_set_input_inflation_keys', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_inflation_keys_rangeproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_issuance_amount', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_issuance_amount_rangeproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_input_sequence', c_int, [POINTER(wally_tx), c_size_t, c_uint32]),
    ('wally_tx_set_input_txhash', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_output_asset', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_output_nonce', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_output_rangeproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_output_satoshi', c_int, [POINTER(wally_tx), c_size_t, c_uint64]),
    ('wally_tx_set_output_script', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_output_surjectionproof', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    ('wally_tx_set_output_value', c_int, [POINTER(wally_tx), c_size_t, c_void_p, c_size_t]),
    # END INTERNAL AUTOGENERATED
    ):

    def bind_fn(name, res, args):
        try:
            fn = getattr(libwally, name)
            fn.restype, fn.argtypes = res, args
            return fn
        except AttributeError:
            # Internal function and 'configure --enable-export-all' not used,
            # or an Elements function and Elements support not enabled.
            return None

    def in_string_fn_wrapper(fn, pos, *args):
        if isinstance(args[pos], str):
            new_args = [a for a in args]
            new_args[pos] = utf8(new_args[pos])
            return fn(*new_args)
        return fn(*args)

    def string_fn_wrapper(fn, *args):
        # Return output string parameters directly without leaking
        p = c_char_p()
        new_args = [a for a in args] + [byref(p)]
        ret = fn(*new_args)
        ret_str = None if p.value is None else p.value.decode('utf-8')
        wally_free_string(p)
        return [ret_str, (ret, ret_str)][fn.restype is not None]

    def size_t_fn_wrapper(fn, *args):
        p = c_size_t()
        new_args = [a for a in args] + [byref(p)]
        ret = fn(*new_args)
        return [p.value, (ret, p.value)][fn.restype is not None]

    def int32_fn_wrapper(fn, *args):
        p = c_uint32()
        new_args = [a for a in args] + [byref(p)]
        ret = fn(*new_args)
        return [p.value, (ret, p.value)][fn.restype is not None]

    def int64_fn_wrapper(fn, *args):
        p = c_uint64()
        new_args = [a for a in args] + [byref(p)]
        ret = fn(*new_args)
        return [p.value, (ret, p.value)][fn.restype is not None]

    name, restype, argtypes = f
    is_str_fn = len(argtypes) and type(argtypes[-1]) is c_char_p_p_class
    is_size_t_fn = len(argtypes) and type(argtypes[-1]) is c_size_t_p_class
    is_int32_fn = len(argtypes) and type(argtypes[-1]) is c_uint32_p_class
    is_int64_fn = len(argtypes) and type(argtypes[-1]) is c_uint64_p_class
    in_str_pos = [i for (i, t) in enumerate(argtypes) if t == c_char_p]
    if is_str_fn:
        argtypes[-1] = POINTER(c_char_p)
    elif is_size_t_fn:
        argtypes[-1] = POINTER(c_size_t)
    elif is_int32_fn:
        argtypes[-1] = POINTER(c_uint32)
    elif is_int64_fn:
        argtypes[-1] = POINTER(c_uint64)
    fn = bind_fn(name, restype, argtypes)
    def mkstr(f): return lambda *args: string_fn_wrapper(f, *args)
    def mksize_t(f): return lambda *args: size_t_fn_wrapper(f, *args)
    def mkint32(f): return lambda *args: int32_fn_wrapper(f, *args)
    def mkint64(f): return lambda *args: int64_fn_wrapper(f, *args)
    def mkinstr(f, pos): return lambda *args: in_string_fn_wrapper(f, pos, *args)
    if is_str_fn:
        fn = mkstr(fn)
    elif is_size_t_fn:
        fn = mksize_t(fn)
    elif is_int32_fn:
        fn = mkint32(fn)
    elif is_int64_fn:
        fn = mkint64(fn)
    if len(in_str_pos) > 0 and fn:
        for pos in in_str_pos:
            fn = mkinstr(fn, pos)
    globals()[name] = fn

def load_words(lang):
    kwargs = {
        'file': root_dir + 'src/data/wordlists/%s.txt' % lang,
        'mode': 'r',
        'encoding': 'utf-8'
    }
    with open(**kwargs) as f:
        words_list = [l.strip() for l in f.readlines()]
        return words_list, ' '.join(words_list)

def h(s):
    return hexlify(s)

def make_cbuffer(hex_in):
    if hex_in is None:
        return None, 0
    hex_len = len(hex_in) // 2
    return unhexlify(hex_in), hex_len

utf8 = lambda s: s.encode('utf-8')

assert wally_secp_randomize(urandom(32), 32) == WALLY_OK, 'Random init failed'

_original_ops = wally_operations()
_new_ops = wally_operations()
for ops in (_original_ops, _new_ops):
    ops.struct_size = sizeof(wally_operations)
    assert wally_get_operations(byref(ops)) == WALLY_OK

# Disable internal tests if not available
def internal_only():
    def decorator(test_func):
        def wrapped(*args):
            if wordlist_init is None:
                print (test_func.__name__ + ' disabled, use --enable-export-all to enable ')
            else:
                return test_func(*args)
        return wrapped
    return decorator

# Support for malloc testing
_fail_malloc_at = 0
_fail_malloc_counter = 0

def _failable_malloc(size):
    global _fail_malloc_counter
    _fail_malloc_counter += 1
    if _fail_malloc_counter == _fail_malloc_at:
        return None
    return _original_ops.malloc_fn(size)

_new_ops.malloc_fn = _malloc_fn_t(_failable_malloc)

def malloc_fail(failures):
    """Decorator to repeatedly call a function failing every nth allocation in 'failures'"""
    def decorator(test_func):
        def wrapped(*args):
            counter = 0
            global _fail_malloc_at, _fail_malloc_counter
            for fail_at in failures:
                _fail_malloc_at, _fail_malloc_counter = fail_at, 0
                test_func(*args)
                counter = max(counter, _fail_malloc_counter)
                _fail_malloc_at, _fail_malloc_counter = 0, 0
            return counter
        return wrapped
    return decorator

def malloc_fail_loop(fn, allowed_rets=None):
    """Repeatedly call a wally function failing every allocation in turn until it succeeds"""
    allowed_rets = allowed_rets or [WALLY_ENOMEM]
    global _fail_malloc_at, _fail_malloc_counter
    fail_at = 0
    while True:
        # Fail each allocation made while parsing in turn
        fail_at += 1
        _fail_malloc_at, _fail_malloc_counter = fail_at, 0
        try:
            ret = fn()
            did_fail = _fail_malloc_counter >= fail_at
        finally:
            _fail_malloc_at, _fail_malloc_counter = 0, 0
        if not did_fail:
            return ret
        assert ret in allowed_rets, f'unexpected return {ret}'

class no_malloc_failures:
    """Context manager to temporarily disable malloc failures"""
    def __enter__(self):
        global _fail_malloc_at, _fail_malloc_counter
        self._fail_malloc_at = _fail_malloc_at
        self._fail_malloc_counter = _fail_malloc_counter
        _fail_malloc_at, _fail_malloc_counter = 0, 0
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        global _fail_malloc_at, _fail_malloc_counter
        _fail_malloc_at = self._fail_malloc_at
        _fail_malloc_counter = self._fail_malloc_counter
        return False

# Support for signing testing
_fake_ec_nonce = None

def set_fake_ec_nonce(nonce):
    global _fake_ec_nonce
    _fake_ec_nonce = nonce

def _fake_ec_nonce_fn(nonce32, msg32, key32, algo16, data, attempt):
    global _fake_ec_nonce
    if _fake_ec_nonce is not None:
        memmove(nonce32, _fake_ec_nonce, 32)
        return 1
    return _original_ops.ec_nonce_fn(nonce32, msg32, key32, algo16, data, attempt)

_new_ops.ec_nonce_fn = _ec_nonce_fn_t(_fake_ec_nonce_fn)

assert wally_set_operations(byref(_new_ops)) == WALLY_OK
