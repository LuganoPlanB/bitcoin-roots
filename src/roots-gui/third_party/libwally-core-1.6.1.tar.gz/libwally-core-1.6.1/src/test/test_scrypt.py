import os
import unittest
from util import *

# Test cases from
# https://tools.ietf.org/html/draft-josefsson-scrypt-kdf-04
cases = [
    ["", "",
     16, 1, 1, 64,
     '77 d6 57 62 38 65 7b 20 3b 19 ca 42 c1 8a 04 97'
     'f1 6b 48 44 e3 07 4a e8 df df fa 3f ed e2 14 42'
     'fc d0 06 9d ed 09 48 f8 32 6a 75 3a 0f c8 1f 17'
     'e8 d3 e0 fb 2e 0d 36 28 cf 35 e2 0c 38 d1 89 06'],

    ['password', 'NaCl',
     1024, 8, 16, 64,
     'fd ba be 1c 9d 34 72 00 78 56 e7 19 0d 01 e9 fe'
     '7c 6a d7 cb c8 23 78 30 e7 73 76 63 4b 37 31 62'
     '2e af 30 d9 2e 22 a3 88 6f f1 09 27 9d 98 30 da'
     'c7 27 af b9 4a 83 ee 6d 83 60 cb df a2 cc 06 40'],

    ['pleaseletmein', 'SodiumChloride',
     16384, 8, 1, 64,
     '70 23 bd cb 3a fd 73 48 46 1c 06 cd 81 fd 38 eb'
     'fd a8 fb ba 90 4f 8e 3e a9 b5 43 f6 54 5d a1 f2'
     'd5 43 29 55 61 3f 0f cf 62 d4 97 05 24 2a 9a f9'
     'e6 1e 85 dc 0d 65 1e 40 df cf 01 7b 45 57 58 87'],

    ['pleaseletmein', 'SodiumChloride',
     1048576, 8, 1, 64,
     '21 01 cb 9b 6a 51 1a ae ad db be 09 cf 70 f8 81'
     'ec 56 8d 57 4a 2f fd 4d ab e5 ee 98 20 ad aa 47'
     '8e 56 fd 8f 4b a5 d0 9f fa 1c 6d 92 7c 40 f4 c3'
     '37 30 40 49 e8 a9 52 fb cb f4 5c 6f a7 7a 41 a4']
]

class ScryptTests(unittest.TestCase):

    def test_scrypt(self):

        # Invalid arguments
        pwd, salt, cost, block, p, l, _ = cases[0]
        pwd, salt = utf8(pwd), utf8(salt)
        out_buf, out_len = make_cbuffer('0' * l)
        invalid = [
            [None, 1,        salt, len(salt), cost, block, p, out_buf, out_len], # NULL password
            [pwd,  len(pwd), None, 1,         cost, block, p, out_buf, out_len], # NULL salt
            [pwd,  len(pwd), salt, len(salt), cost, block, p, None,    out_len], # Null output
            [pwd,  len(pwd), salt, len(salt), cost, block, p, out_buf, 0],       # Empty output
            [pwd,  len(pwd), salt, len(salt), cost, block, p, out_buf, 33],      # Len not % 32
            [pwd,  len(pwd), salt, len(salt), cost, 0,     p, out_buf, out_len], # Zero block size
            [pwd,  len(pwd), salt, len(salt), cost, block, 0, out_buf, out_len], # Zero parallelism
        ]
        for c in invalid:
            ret = wally_scrypt(*c)
            self.assertEqual(ret, WALLY_EINVAL)

        # Test vectors
        for c in cases:
            pwd, salt, cost, block, parallel, length, expected = c
            pwd = utf8(pwd)
            salt = utf8(salt)
            expected = expected.replace(' ', '')
            assert len(expected) == length * 2
            out_buf, out_len = make_cbuffer('0' * len(expected))

            ret = wally_scrypt(pwd, len(pwd), salt, len(salt),
                               cost, block, parallel, out_buf, out_len)
            self.assertEqual(ret, WALLY_OK)
            self.assertEqual(h(out_buf), utf8(expected))

            if os.getenv('WALLY_SKIP_EXPENSIVE_TESTS', None):
                # Skip the remainder of the test cases
                self.skipTest('Skipping expensive scrypt tests')


    def test_scrypt_malloc(self):
        # Allocation failures in either internal PBKDF2 call must be reported
        pwd, salt, cost, block, p, l, _ = cases[0]
        pwd, salt = utf8(pwd), utf8(salt)
        out_buf, out_len = make_cbuffer('00' * l)

        @malloc_fail([1, 2])
        def do_wally_scrypt():
            ret = wally_scrypt(pwd, len(pwd), salt, len(salt),
                               cost, block, p, out_buf, out_len)
            self.assertEqual(ret, WALLY_ENOMEM)

        do_wally_scrypt()

    def test_scrypt_clear(self):
        # The B, XY and V working buffers must be wiped before being freed
        cleared = []
        def _bzero(p, n):
            cleared.append(n)
            memset(p, 0, n)

        saved, ops = wally_operations(), wally_operations()
        for o in (saved, ops):
            o.struct_size = sizeof(wally_operations)
            self.assertEqual(wally_get_operations(byref(o)), WALLY_OK)
        ops.bzero_fn = type(ops.bzero_fn)(_bzero)
        self.assertEqual(wally_set_operations(byref(ops)), WALLY_OK)

        pwd, salt, cost, block, p = utf8('password'), utf8('NaCl'), 32, 2, 3
        out_buf, out_len = make_cbuffer('00' * 64)
        try:
            ret = wally_scrypt(pwd, len(pwd), salt, len(salt),
                               cost, block, p, out_buf, out_len)
        finally:
            wally_set_operations(byref(saved))
        self.assertEqual(ret, WALLY_OK)
        for n in (128 * block * p, 256 * block + 64, 128 * block * cost):
            self.assertIn(n, cleared)


if __name__ == '__main__':
    unittest.main()
