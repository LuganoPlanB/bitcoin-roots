/* MIT (BSD) license - see LICENSE file for details */
/* SHA256 core code translated from the Bitcoin project's C++:
 *
 * src/crypto/sha256.cpp commit 417532c8acb93c36c2b6fd052b7c11b6a2906aa2
 * Copyright (c) 2014 The Bitcoin Core developers
 * Distributed under the MIT software license, see the accompanying
 * file COPYING or http://www.opensource.org/licenses/mit-license.php.
 */
#include <ccan/crypto/sha256/sha256.h>
#include <ccan/endian/endian.h>
#include <ccan/compiler/compiler.h>
#include <stdbool.h>
#if 0
#include <assert.h>
#endif
#include <string.h>

#ifdef CCAN_CRYPTO_SHA256_USE_OPENSSL
static void invalidate_sha256(struct sha256_ctx *ctx)
{
	ctx->c.md_len = 0;
}

static void check_sha256(struct sha256_ctx *ctx UNUSED)
{
#if 0
	assert(ctx->c.md_len != 0);
#endif
}

void sha256_init(struct sha256_ctx *ctx)
{
	SHA256_Init(&ctx->c);
}

void sha256_update(struct sha256_ctx *ctx, const void *p, size_t size)
{
	check_sha256(ctx);
	SHA256_Update(&ctx->c, p, size);
}

bool sha256_done(struct sha256_ctx *ctx, struct sha256 *res)
{
	bool ret = SHA256_Final(res->u.u8, &ctx->c) == 1;
	invalidate_sha256(ctx);
	return ret;
}
#else
/* The portable SHA-256 compression function. Used by the builtin backend,
 * and by the mbedtls and PSA backends to compute midstates. */
static uint32_t Ch(uint32_t x, uint32_t y, uint32_t z)
{
	return z ^ (x & (y ^ z));
}
static uint32_t Maj(uint32_t x, uint32_t y, uint32_t z)
{
	return (x & y) | (z & (x | y));
}
static uint32_t Sigma0(uint32_t x)
{
	return (x >> 2 | x << 30) ^ (x >> 13 | x << 19) ^ (x >> 22 | x << 10);
}
static uint32_t Sigma1(uint32_t x)
{
	return (x >> 6 | x << 26) ^ (x >> 11 | x << 21) ^ (x >> 25 | x << 7);
}
static uint32_t sigma0(uint32_t x)
{
	return (x >> 7 | x << 25) ^ (x >> 18 | x << 14) ^ (x >> 3);
}
static uint32_t sigma1(uint32_t x)
{
	return (x >> 17 | x << 15) ^ (x >> 19 | x << 13) ^ (x >> 10);
}

/** One round of SHA-256. */
static void Round(uint32_t a, uint32_t b, uint32_t c, uint32_t *d, uint32_t e, uint32_t f, uint32_t g, uint32_t *h, uint32_t k, uint32_t w)
{
	uint32_t t1 = *h + Sigma1(e) + Ch(e, f, g) + k + w;
	uint32_t t2 = Sigma0(a) + Maj(a, b, c);
	*d += t1;
	*h = t1 + t2;
}

/** Perform a number of SHA-256 transformations, processing 64-byte chunks. */
static void TransformDefault(uint32_t *s, const uint32_t *chunk, size_t blocks)
{
	while (blocks--) {
		uint32_t a = s[0], b = s[1], c = s[2], d = s[3], e = s[4], f = s[5], g = s[6], h = s[7];
		uint32_t w0, w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15;

		Round(a, b, c, &d, e, f, g, &h, 0x428a2f98, w0 = be32_to_cpu(chunk[0]));
		Round(h, a, b, &c, d, e, f, &g, 0x71374491, w1 = be32_to_cpu(chunk[1]));
		Round(g, h, a, &b, c, d, e, &f, 0xb5c0fbcf, w2 = be32_to_cpu(chunk[2]));
		Round(f, g, h, &a, b, c, d, &e, 0xe9b5dba5, w3 = be32_to_cpu(chunk[3]));
		Round(e, f, g, &h, a, b, c, &d, 0x3956c25b, w4 = be32_to_cpu(chunk[4]));
		Round(d, e, f, &g, h, a, b, &c, 0x59f111f1, w5 = be32_to_cpu(chunk[5]));
		Round(c, d, e, &f, g, h, a, &b, 0x923f82a4, w6 = be32_to_cpu(chunk[6]));
		Round(b, c, d, &e, f, g, h, &a, 0xab1c5ed5, w7 = be32_to_cpu(chunk[7]));
		Round(a, b, c, &d, e, f, g, &h, 0xd807aa98, w8 = be32_to_cpu(chunk[8]));
		Round(h, a, b, &c, d, e, f, &g, 0x12835b01, w9 = be32_to_cpu(chunk[9]));
		Round(g, h, a, &b, c, d, e, &f, 0x243185be, w10 = be32_to_cpu(chunk[10]));
		Round(f, g, h, &a, b, c, d, &e, 0x550c7dc3, w11 = be32_to_cpu(chunk[11]));
		Round(e, f, g, &h, a, b, c, &d, 0x72be5d74, w12 = be32_to_cpu(chunk[12]));
		Round(d, e, f, &g, h, a, b, &c, 0x80deb1fe, w13 = be32_to_cpu(chunk[13]));
		Round(c, d, e, &f, g, h, a, &b, 0x9bdc06a7, w14 = be32_to_cpu(chunk[14]));
		Round(b, c, d, &e, f, g, h, &a, 0xc19bf174, w15 = be32_to_cpu(chunk[15]));

		Round(a, b, c, &d, e, f, g, &h, 0xe49b69c1, w0 += sigma1(w14) + w9 + sigma0(w1));
		Round(h, a, b, &c, d, e, f, &g, 0xefbe4786, w1 += sigma1(w15) + w10 + sigma0(w2));
		Round(g, h, a, &b, c, d, e, &f, 0x0fc19dc6, w2 += sigma1(w0) + w11 + sigma0(w3));
		Round(f, g, h, &a, b, c, d, &e, 0x240ca1cc, w3 += sigma1(w1) + w12 + sigma0(w4));
		Round(e, f, g, &h, a, b, c, &d, 0x2de92c6f, w4 += sigma1(w2) + w13 + sigma0(w5));
		Round(d, e, f, &g, h, a, b, &c, 0x4a7484aa, w5 += sigma1(w3) + w14 + sigma0(w6));
		Round(c, d, e, &f, g, h, a, &b, 0x5cb0a9dc, w6 += sigma1(w4) + w15 + sigma0(w7));
		Round(b, c, d, &e, f, g, h, &a, 0x76f988da, w7 += sigma1(w5) + w0 + sigma0(w8));
		Round(a, b, c, &d, e, f, g, &h, 0x983e5152, w8 += sigma1(w6) + w1 + sigma0(w9));
		Round(h, a, b, &c, d, e, f, &g, 0xa831c66d, w9 += sigma1(w7) + w2 + sigma0(w10));
		Round(g, h, a, &b, c, d, e, &f, 0xb00327c8, w10 += sigma1(w8) + w3 + sigma0(w11));
		Round(f, g, h, &a, b, c, d, &e, 0xbf597fc7, w11 += sigma1(w9) + w4 + sigma0(w12));
		Round(e, f, g, &h, a, b, c, &d, 0xc6e00bf3, w12 += sigma1(w10) + w5 + sigma0(w13));
		Round(d, e, f, &g, h, a, b, &c, 0xd5a79147, w13 += sigma1(w11) + w6 + sigma0(w14));
		Round(c, d, e, &f, g, h, a, &b, 0x06ca6351, w14 += sigma1(w12) + w7 + sigma0(w15));
		Round(b, c, d, &e, f, g, h, &a, 0x14292967, w15 += sigma1(w13) + w8 + sigma0(w0));

		Round(a, b, c, &d, e, f, g, &h, 0x27b70a85, w0 += sigma1(w14) + w9 + sigma0(w1));
		Round(h, a, b, &c, d, e, f, &g, 0x2e1b2138, w1 += sigma1(w15) + w10 + sigma0(w2));
		Round(g, h, a, &b, c, d, e, &f, 0x4d2c6dfc, w2 += sigma1(w0) + w11 + sigma0(w3));
		Round(f, g, h, &a, b, c, d, &e, 0x53380d13, w3 += sigma1(w1) + w12 + sigma0(w4));
		Round(e, f, g, &h, a, b, c, &d, 0x650a7354, w4 += sigma1(w2) + w13 + sigma0(w5));
		Round(d, e, f, &g, h, a, b, &c, 0x766a0abb, w5 += sigma1(w3) + w14 + sigma0(w6));
		Round(c, d, e, &f, g, h, a, &b, 0x81c2c92e, w6 += sigma1(w4) + w15 + sigma0(w7));
		Round(b, c, d, &e, f, g, h, &a, 0x92722c85, w7 += sigma1(w5) + w0 + sigma0(w8));
		Round(a, b, c, &d, e, f, g, &h, 0xa2bfe8a1, w8 += sigma1(w6) + w1 + sigma0(w9));
		Round(h, a, b, &c, d, e, f, &g, 0xa81a664b, w9 += sigma1(w7) + w2 + sigma0(w10));
		Round(g, h, a, &b, c, d, e, &f, 0xc24b8b70, w10 += sigma1(w8) + w3 + sigma0(w11));
		Round(f, g, h, &a, b, c, d, &e, 0xc76c51a3, w11 += sigma1(w9) + w4 + sigma0(w12));
		Round(e, f, g, &h, a, b, c, &d, 0xd192e819, w12 += sigma1(w10) + w5 + sigma0(w13));
		Round(d, e, f, &g, h, a, b, &c, 0xd6990624, w13 += sigma1(w11) + w6 + sigma0(w14));
		Round(c, d, e, &f, g, h, a, &b, 0xf40e3585, w14 += sigma1(w12) + w7 + sigma0(w15));
		Round(b, c, d, &e, f, g, h, &a, 0x106aa070, w15 += sigma1(w13) + w8 + sigma0(w0));

		Round(a, b, c, &d, e, f, g, &h, 0x19a4c116, w0 += sigma1(w14) + w9 + sigma0(w1));
		Round(h, a, b, &c, d, e, f, &g, 0x1e376c08, w1 += sigma1(w15) + w10 + sigma0(w2));
		Round(g, h, a, &b, c, d, e, &f, 0x2748774c, w2 += sigma1(w0) + w11 + sigma0(w3));
		Round(f, g, h, &a, b, c, d, &e, 0x34b0bcb5, w3 += sigma1(w1) + w12 + sigma0(w4));
		Round(e, f, g, &h, a, b, c, &d, 0x391c0cb3, w4 += sigma1(w2) + w13 + sigma0(w5));
		Round(d, e, f, &g, h, a, b, &c, 0x4ed8aa4a, w5 += sigma1(w3) + w14 + sigma0(w6));
		Round(c, d, e, &f, g, h, a, &b, 0x5b9cca4f, w6 += sigma1(w4) + w15 + sigma0(w7));
		Round(b, c, d, &e, f, g, h, &a, 0x682e6ff3, w7 += sigma1(w5) + w0 + sigma0(w8));
		Round(a, b, c, &d, e, f, g, &h, 0x748f82ee, w8 += sigma1(w6) + w1 + sigma0(w9));
		Round(h, a, b, &c, d, e, f, &g, 0x78a5636f, w9 += sigma1(w7) + w2 + sigma0(w10));
		Round(g, h, a, &b, c, d, e, &f, 0x84c87814, w10 += sigma1(w8) + w3 + sigma0(w11));
		Round(f, g, h, &a, b, c, d, &e, 0x8cc70208, w11 += sigma1(w9) + w4 + sigma0(w12));
		Round(e, f, g, &h, a, b, c, &d, 0x90befffa, w12 += sigma1(w10) + w5 + sigma0(w13));
		Round(d, e, f, &g, h, a, b, &c, 0xa4506ceb, w13 += sigma1(w11) + w6 + sigma0(w14));
		Round(c, d, e, &f, g, h, a, &b, 0xbef9a3f7, w14 + sigma1(w12) + w7 + sigma0(w15));
		Round(b, c, d, &e, f, g, h, &a, 0xc67178f2, w15 + sigma1(w13) + w8 + sigma0(w0));

		s[0] += a;
		s[1] += b;
		s[2] += c;
		s[3] += d;
		s[4] += e;
		s[5] += f;
		s[6] += g;
		s[7] += h;
		chunk += 64 / sizeof(uint32_t);
	}
}

#if defined(CCAN_CRYPTO_SHA256_USE_MBEDTLS) || defined(CCAN_CRYPTO_SHA256_USE_PSA)
void sha256_sw_transform(uint32_t *s, const uint32_t *chunk, size_t blocks)
{
	TransformDefault(s, chunk, blocks);
}

#ifdef CCAN_CRYPTO_SHA256_USE_MBEDTLS
#if MBEDTLS_VERSION_NUMBER < 0x03000000
/* Mbed TLS 2.x only reports errors from the _ret variants */
#define SHA256_STARTS mbedtls_sha256_starts_ret
#define SHA256_UPDATE mbedtls_sha256_update_ret
#define SHA256_FINISH mbedtls_sha256_finish_ret
#else
#define SHA256_STARTS mbedtls_sha256_starts
#define SHA256_UPDATE mbedtls_sha256_update
#define SHA256_FINISH mbedtls_sha256_finish
#endif

/* sha256_init() and sha256_update() cannot report errors, so a failure is
 * remembered in the context and reported by sha256_done() */
inline void sha256_init(struct sha256_ctx *ctx)
{
	mbedtls_sha256_init(&ctx->c);
	ctx->failed = SHA256_STARTS(&ctx->c, 0) != 0;
}

inline void sha256_update(struct sha256_ctx *ctx, const void *p, size_t size)
{
	if (!ctx->failed)
		ctx->failed = SHA256_UPDATE(&ctx->c, p, size) != 0;
}

inline bool sha256_done(struct sha256_ctx *ctx, struct sha256* res)
{
	bool ok = !ctx->failed && SHA256_FINISH(&ctx->c, res->u.u8) == 0;
	mbedtls_sha256_free(&ctx->c);
	if (!ok)
		memset(res, 0, sizeof(*res));
	return ok;
}
#else
/* sha256_init() and sha256_update() cannot report errors, so on failure
 * they abort the PSA operation, leaving it inactive: later calls then
 * fail too, and sha256_done() reports the failure.
 */
void sha256_init(struct sha256_ctx *ctx)
{
	/* ctx must not be an active operation: PSA drivers may hold
	 * state that only sha256_done() releases. Zero-filling is one of
	 * the initializations the PSA API permits, and unlike
	 * psa_hash_operation_init() it needs no on-stack temporary. */
	memset(&ctx->op, 0, sizeof(ctx->op));
	if (psa_hash_setup(&ctx->op, PSA_ALG_SHA_256) != PSA_SUCCESS)
		psa_hash_abort(&ctx->op);
}

void sha256_update(struct sha256_ctx *ctx, const void *p, size_t size)
{
	if (psa_hash_update(&ctx->op, p, size) != PSA_SUCCESS)
		psa_hash_abort(&ctx->op);
}

bool sha256_done(struct sha256_ctx *ctx, struct sha256 *res)
{
	size_t len = 0;

	if (psa_hash_finish(&ctx->op, res->u.u8, sizeof(res->u.u8), &len) != PSA_SUCCESS ||
	    len != sizeof(res->u.u8)) {
		psa_hash_abort(&ctx->op);
		memset(res, 0, sizeof(*res));
		return false;
	}
	return true;
}
#endif /* CCAN_CRYPTO_SHA256_USE_MBEDTLS */

void sha256_optimize(void)
{
}
#else /* Builtin implementation */
static void invalidate_sha256(struct sha256_ctx *ctx)
{
	ctx->bytes = (size_t)-1;
}

static void check_sha256(struct sha256_ctx *ctx UNUSED)
{
#if 0
	assert(ctx->bytes != (size_t)-1);
#endif
}

#if defined(HAVE_INLINE_ASM) && (defined(__x86_64__) || defined(__amd64__))
#include <cpuid.h>

#include "sha256_sse4.c"

static int use_optimized_transform = 0;
#endif

static inline void Transform(uint32_t *s, const uint32_t *chunk, size_t blocks)
{
#if defined(HAVE_INLINE_ASM) && (defined(__x86_64__) || defined(__amd64__))
	if (use_optimized_transform) {
		TransformSSE4(s, chunk, blocks);
		return;
	}
#endif
	TransformDefault(s, chunk, blocks);
}

static void add(struct sha256_ctx *ctx, const void *p, size_t len)
{
	const unsigned char *data = p;
	size_t bufsize = ctx->bytes % 64;

	if (bufsize + len >= 64) {
		/* Fill the buffer, and process it. */
		memcpy(ctx->buf.u8 + bufsize, data, 64 - bufsize);
		ctx->bytes += 64 - bufsize;
		data += 64 - bufsize;
		len -= 64 - bufsize;
		Transform(ctx->s, ctx->buf.u32, 1);
		bufsize = 0;
	}

	while (len >= 64) {
		/* Process full chunks directly from the source. */
		if (alignment_ok(data, sizeof(uint32_t))) {
			const size_t blocks = len / 64;
			Transform(ctx->s, (const uint32_t *)((void*)data), blocks);
			ctx->bytes += 64 * blocks;
			data += 64 * blocks;
			len -= 64 * blocks;
		} else {
			memcpy(ctx->buf.u8, data, sizeof(ctx->buf));
			Transform(ctx->s, ctx->buf.u32, 1);
			ctx->bytes += 64;
			data += 64;
			len -= 64;
		}
	}
	    
	if (len) {
		/* Fill the buffer with what remains. */
		memcpy(ctx->buf.u8 + bufsize, data, len);
		ctx->bytes += len;
	}
}

void sha256_optimize(void)
{
#if defined(HAVE_INLINE_ASM)
#if defined(__x86_64__) || defined(__amd64__)
	uint32_t leaf = 1, subleaf = 0;
	uint32_t eax = 0, ebx = 0, ecx = 0, edx = 0;
#ifdef __GNUC__
	__cpuid_count(leaf, subleaf, eax, ebx, ecx, edx);
#else
	__asm__ ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx) : "0"(leaf), "2"(subleaf));
#endif
	if ((ecx >> 19) & 1) {
		use_optimized_transform = 1; /* SSE4 is available */
	}
#endif
#endif /* defined(HAVE_INLINE_ASM) */
}

void sha256_init(struct sha256_ctx *ctx)
{
	struct sha256_ctx init = SHA256_INIT;
	*ctx = init;
}

void sha256_update(struct sha256_ctx *ctx, const void *p, size_t size)
{
	check_sha256(ctx);
	add(ctx, p, size);
}

bool sha256_done(struct sha256_ctx *ctx, struct sha256 *res)
{
	static const unsigned char pad[64] = {0x80};
	uint64_t sizedesc;
	size_t i;

	sizedesc = cpu_to_be64((uint64_t)ctx->bytes << 3);
	/* Add '1' bit to terminate, then all 0 bits, up to next block - 8. */
	add(ctx, pad, 1 + ((128 - 8 - (ctx->bytes % 64) - 1) % 64));
	/* Add number of bits of data (big endian) */
	add(ctx, &sizedesc, 8);
	for (i = 0; i < sizeof(ctx->s) / sizeof(ctx->s[0]); i++)
		res->u.u32[i] = cpu_to_be32(ctx->s[i]);
	invalidate_sha256(ctx);
	return true;
}
#endif /* CCAN_CRYPTO_SHA256_USE_MBEDTLS || CCAN_CRYPTO_SHA256_USE_PSA */
#endif

#ifdef CCAN_CRYPTO_SHA256_USE_PSA
bool sha256(struct sha256 *sha, const void *p, size_t size)
{
	size_t len = 0;

	if (!size)
		p = ""; /* psa_hash_compute() may reject a NULL input */
	if (psa_hash_compute(PSA_ALG_SHA_256, p, size, sha->u.u8, sizeof(sha->u.u8),
	                     &len) != PSA_SUCCESS ||
	    len != sizeof(sha->u.u8)) {
		memset(sha, 0, sizeof(*sha));
		return false;
	}
	return true;
}
#else
bool sha256(struct sha256 *sha, const void *p, size_t size)
{
	struct sha256_ctx ctx;
	bool ret;

	sha256_init(&ctx);
	sha256_update(&ctx, p, size);
	ret = sha256_done(&ctx, sha);
	CCAN_CLEAR_MEMORY(&ctx, sizeof(ctx));
	return ret;
}
#endif /* CCAN_CRYPTO_SHA256_USE_PSA */
	
void sha256_u8(struct sha256_ctx *ctx, uint8_t v)
{
	sha256_update(ctx, &v, sizeof(v));
}

void sha256_u16(struct sha256_ctx *ctx, uint16_t v)
{
	sha256_update(ctx, &v, sizeof(v));
}

void sha256_u32(struct sha256_ctx *ctx, uint32_t v)
{
	sha256_update(ctx, &v, sizeof(v));
}

void sha256_u64(struct sha256_ctx *ctx, uint64_t v)
{
	sha256_update(ctx, &v, sizeof(v));
}

/* Add as little-endian */
void sha256_le16(struct sha256_ctx *ctx, uint16_t v)
{
	leint16_t lev = cpu_to_le16(v);
	sha256_update(ctx, &lev, sizeof(lev));
}
	
void sha256_le32(struct sha256_ctx *ctx, uint32_t v)
{
	leint32_t lev = cpu_to_le32(v);
	sha256_update(ctx, &lev, sizeof(lev));
}
	
void sha256_le64(struct sha256_ctx *ctx, uint64_t v)
{
	leint64_t lev = cpu_to_le64(v);
	sha256_update(ctx, &lev, sizeof(lev));
}

/* Add as big-endian */
void sha256_be16(struct sha256_ctx *ctx, uint16_t v)
{
	beint16_t bev = cpu_to_be16(v);
	sha256_update(ctx, &bev, sizeof(bev));
}
	
void sha256_be32(struct sha256_ctx *ctx, uint32_t v)
{
	beint32_t bev = cpu_to_be32(v);
	sha256_update(ctx, &bev, sizeof(bev));
}
	
void sha256_be64(struct sha256_ctx *ctx, uint64_t v)
{
	beint64_t bev = cpu_to_be64(v);
	sha256_update(ctx, &bev, sizeof(bev));
}
