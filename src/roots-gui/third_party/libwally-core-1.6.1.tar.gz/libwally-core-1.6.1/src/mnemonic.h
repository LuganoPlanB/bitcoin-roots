#ifndef LIBWALLY_MNEMONIC_H
#define LIBWALLY_MNEMONIC_H

#include "internal.h"

struct words;

/**
 * Return a mnemonic representation of a block of bytes.
 *
 * @w: List of words.
 * @bytes: Bytes to convert to a mnemonic sentence.
 * @len: The length of @bytes in bytes.
 *
 * @bytes must be an even multiple of the number of bits in the wordlist used.
 */
WALLY_INTERNAL_API char * mnemonic_from_bytes(
    const struct words *w,
    const unsigned char *bytes,
    size_t len);

/**
 * Convert a mnemonic representation into bytes.
 *
 * @w: List of words.
 * @mnemonic: Mnemonic sentence to store.
 * @bytes_out: Destination for the resulting bytes.
 * @len: The length of @bytes_out in bytes.
 * @written: Destination for the number of bytes written to ``bytes_out``.
 */
WALLY_INTERNAL_API int mnemonic_to_bytes(
    const struct words *w,
    const char *mnemonic,
    unsigned char *bytes_out,
    size_t len,
    size_t *written);

#endif /* LIBWALLY_MNEMONIC_H */
