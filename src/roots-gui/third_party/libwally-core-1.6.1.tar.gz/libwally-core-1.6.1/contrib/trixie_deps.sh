#! /usr/bin/env bash
# Install required dependencies for building wally
# Options:
# -e : Don't install emsdk (used for JS builds)
# -j : Don't install Java SDK (used for Java builds)
# -m : Don't install mbedtls libraries (used for testing)
# -n : Don't install Android NDK (used for Android builds)
# -w : Don't install MinGW (used for Windows cross compiles)
set -e

skip_emsdk=
skip_java=
skip_mbedtls=
skip_ndk=
skip_windows=
while getopts ejmnw name
do
    case $name in
    e)   skip_emsdk=1;;
    j)   skip_java=1;;
    m)   skip_mbedtls=1;;
    n)   skip_ndk=1;;
    w)   skip_windows=1;;
    *)   echo "Invalid flag"; exit 1;;
    esac
done
shift $(($OPTIND - 1))

apt update -qq
apt upgrade -yqq

java_packages=
if [ -z "$skip_java" ]; then
    jdk_package="openjdk-21-jdk"
    jdk_install_dir="java-21-openjdk-$TARGETARCH"
    jre_package="openjdk-21-jre"
fi
windows_packages=
if [ -z "$skip_windows" ]; then
    windows_packages="g++-mingw-w64-x86-64"
fi
mbedtls_packages=
if [ -z "$skip_mbedtls" ]; then
    mbedtls_packages="libmbedtls21 libmbedtls-dev"
fi
apt install --no-install-recommends unzip autoconf automake autotools-dev pkg-config build-essential libtool python3{,-dev,-pip,-virtualenv} python{,-dev}-is-python3 clang{,-format,-tidy} git swig curl cmake libssl-dev libtool-bin $jdk_package $jre_package $windows_packages valgrind jq $mbedtls_packages -yqq

# Note --break-system-packages to allow installing our requirements system-wide
pip install valgrind-codequality gcovr -r contrib/requirements.txt --break-system-packages

pushd /opt

if [ -z "$skip_ndk" ]; then
    curl -L -o ndk.zip https://dl.google.com/android/repository/android-ndk-r26b-linux.zip
    echo "ad73c0370f0b0a87d1671ed2fd5a9ac9acfd1eb5c43a7fbfbd330f85d19dd632  ndk.zip" | shasum -a 256 -c
    unzip ndk.zip
    rm ndk.zip
fi

if [ -z "$skip_emsdk" ]; then
    # Install node 24
    curl -fsSL https://deb.nodesource.com/setup_24.x | bash -
    apt install nodejs -yqq
    # Install emsdk
    git clone https://github.com/emscripten-core/emsdk
    cd emsdk
    git checkout 35659964bc2762fffec0d257997fb61475f765b7 # tag: 6.0.13
    EMSDK_VERSION=3.1.57
    ./emsdk install ${EMSDK_VERSION}
    ./emsdk activate ${EMSDK_VERSION}
    # Force emsdk to use the installed node version instead of its own
    sed -i "s/^NODE_JS = .*$/NODE_JS = 'node'/g" /opt/emsdk/.emscripten
    # Remove the emsdk installed version which is likely old/insecure
    rm -rf /opt/emsdk/node
    # Make emsdk commands available
    source ./emsdk_env.sh
fi

if [ -f /.dockerenv ]; then
    # Installing dependencies into a docker image.
    # Purge uneeded files to keep the image as small as possible.
    apt remove --purge curl unzip -yqq
    apt -yqq autoremove
    apt -yqq clean
    rm -rf /var/lib/apt/lists/* /var/cache/* /tmp/* /usr/share/locale/* /usr/share/man /usr/share/doc /lib/xtables/libip6* /root/.cache
fi

popd
