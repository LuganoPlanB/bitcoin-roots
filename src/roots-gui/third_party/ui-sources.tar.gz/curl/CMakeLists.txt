#***************************************************************************
#                                  _   _ ____  _
#  Project                     ___| | | |  _ \| |
#                             / __| | | | |_) | |
#                            | (__| |_| |  _ <| |___
#                             \___|\___/|_| \_\_____|
#
# Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
#
# This software is licensed as described in the file COPYING, which
# you should have received as part of this distribution. The terms
# are also available at https://curl.se/docs/copyright.html.
#
# You may opt to use, copy, modify, merge, publish, distribute and/or sell
# copies of the Software, and permit persons to whom the Software is
# furnished to do so, under the terms of the COPYING file.
#
# This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
# KIND, either express or implied.
#
# SPDX-License-Identifier: curl
#
###########################################################################

cmake_minimum_required(VERSION 3.18 FATAL_ERROR)
message(STATUS "Using CMake version ${CMAKE_VERSION}")

# Collect command-line arguments for buildinfo.txt.
# Must reside at the top of the script to work as expected.
set(_cmake_args "")
if(NOT "$ENV{CURL_BUILDINFO}$ENV{CURL_CI}$ENV{CI}" STREQUAL "")
  get_cmake_property(_cache_vars CACHE_VARIABLES)
  foreach(_cache_var IN ITEMS ${_cache_vars})
    get_property(_cache_var_helpstring CACHE ${_cache_var} PROPERTY HELPSTRING)
    if(_cache_var_helpstring STREQUAL "No help, variable specified on the command line.")
      get_property(_cache_var_type CACHE ${_cache_var} PROPERTY TYPE)
      get_property(_cache_var_value CACHE ${_cache_var} PROPERTY VALUE)
      if(_cache_var_type STREQUAL "UNINITIALIZED")
        set(_cache_var_type "")
      else()
        set(_cache_var_type ":${_cache_var_type}")
      endif()
      string(APPEND _cmake_args " -D${_cache_var}${_cache_var_type}=\"${_cache_var_value}\"")
    endif()
  endforeach()
endif()

list(PREPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/CMake")
include(Utilities)
include(Macros)
include(CMakeDependentOption)
include(CheckCCompilerFlag)

file(STRINGS "${CMAKE_CURRENT_SOURCE_DIR}/include/curl/curlver.h" _curl_version_h_contents REGEX "#define LIBCURL_VERSION( |_NUM )")
string(REGEX MATCH "#define LIBCURL_VERSION \"[^\"]*" _curl_version ${_curl_version_h_contents})
string(REGEX REPLACE "[^\"]+\"" "" _curl_version ${_curl_version})
string(REGEX MATCH "#define LIBCURL_VERSION_NUM 0x[0-9a-fA-F]+" _curl_version_num ${_curl_version_h_contents})
string(REGEX REPLACE "[^0]+0x" "" _curl_version_num ${_curl_version_num})
unset(_curl_version_h_contents)

message(STATUS "curl version=[${_curl_version}]")

string(REGEX REPLACE "([0-9]+\.[0-9]+\.[0-9]+).+" "\\1" _curl_version_sem "${_curl_version}")
# Initializes PROJECT_BINARY_DIR, PROJECT_SOURCE_DIR
project(CURL
  VERSION "${_curl_version_sem}"
  LANGUAGES C)

# CMake does not recognize some targets accurately. Touch up configuration manually as a workaround.
if(WINDOWS_STORE AND MINGW)  # MinGW UWP build
  # CMake (as of 3.31.2) gets confused and applies the MSVC rc.exe command-line
  # template to windres. Reset it to the windres template as in 'Modules/Platform/Windows-windres.cmake':
  set(CMAKE_RC_COMPILE_OBJECT "<CMAKE_RC_COMPILER> -O coff <DEFINES> <INCLUDES> <FLAGS> <SOURCE> <OBJECT>")
elseif(DOS AND CMAKE_C_COMPILER_ID STREQUAL "GNU")  # DJGPP
  set(CMAKE_STATIC_LIBRARY_PREFIX "lib")
  set(CMAKE_STATIC_LIBRARY_SUFFIX ".a")
  set(CMAKE_FIND_LIBRARY_PREFIXES "lib")
  set(CMAKE_FIND_LIBRARY_SUFFIXES ".a")
endif()

# Fill platform level variable when using CMake's built-in Android configuration
if(ANDROID AND NOT DEFINED ANDROID_PLATFORM_LEVEL AND NOT CMAKE_SYSTEM_VERSION EQUAL 1)
  set(ANDROID_PLATFORM_LEVEL "${CMAKE_SYSTEM_VERSION}")
endif()

set(_target_flags "")
if(APPLE)
  string(APPEND _target_flags " APPLE")
endif()
if(UNIX)
  string(APPEND _target_flags " UNIX")
endif()
if(BSD OR CMAKE_SYSTEM_NAME MATCHES "BSD")
  string(APPEND _target_flags " BSD")
endif()
if(ANDROID)
  string(APPEND _target_flags " ANDROID-${ANDROID_PLATFORM_LEVEL}")
endif()
if(WIN32)
  string(APPEND _target_flags " WIN32")
endif()
if(WINDOWS_STORE)
  string(APPEND _target_flags " UWP")
endif()
if(CYGWIN)
  string(APPEND _target_flags " CYGWIN")
endif()
if(DOS)
  string(APPEND _target_flags " DOS")
endif()
if(AMIGA)
  string(APPEND _target_flags " AMIGA")
endif()
if(CMAKE_C_COMPILER_ID STREQUAL "GNU")
  string(APPEND _target_flags " GCC")
endif()
if(CMAKE_C_COMPILER_ID STREQUAL "AppleClang")
  string(APPEND _target_flags " APPLE-CLANG")
elseif(CMAKE_C_COMPILER_ID STREQUAL "Clang" AND MSVC)
  string(APPEND _target_flags " CLANG-CL")
elseif(CMAKE_C_COMPILER_ID MATCHES "Clang")
  string(APPEND _target_flags " LLVM-CLANG")
endif()
if(MINGW)
  string(APPEND _target_flags " MINGW")
endif()
if(MSVC)
  string(APPEND _target_flags " MSVC-${MSVC_VERSION}")
endif()
if(VCPKG_TOOLCHAIN)
  string(APPEND _target_flags " VCPKG")
endif()
if(CMAKE_CROSSCOMPILING)
  string(APPEND _target_flags " CROSS")
endif()
if(CMAKE_C_STANDARD)
  string(APPEND _target_flags " C${CMAKE_C_STANDARD}")
endif()
message(STATUS "CMake platform flags:${_target_flags}")

if(CMAKE_CROSSCOMPILING)
  message(STATUS "Cross-compiling: "
    "${CMAKE_HOST_SYSTEM_NAME}/${CMAKE_HOST_SYSTEM_PROCESSOR} -> "
    "${CMAKE_SYSTEM_NAME}/${CMAKE_SYSTEM_PROCESSOR}")
endif()

if(CMAKE_C_COMPILER_TARGET)
  set(CURL_OS "\"${CMAKE_C_COMPILER_TARGET}\"")
else()
  set(CURL_OS "\"${CMAKE_SYSTEM_NAME}\"")
endif()

if(CURL_PATCHSTAMP)
  set(CURL_PATCHSTAMP "\"${CURL_PATCHSTAMP}\"")
endif()

set(LIB_NAME "libcurl")
set(EXE_NAME "curl")

set_property(DIRECTORY APPEND PROPERTY INCLUDE_DIRECTORIES "${PROJECT_SOURCE_DIR}/include")

if(NOT DEFINED CMAKE_UNITY_BUILD_BATCH_SIZE)
  set(CMAKE_UNITY_BUILD_BATCH_SIZE 0)
endif()

# Having CMAKE_TRY_COMPILE_TARGET_TYPE set to STATIC_LIBRARY breaks certain
# 'check_function_exists()' detections (possibly more), by detecting
# non-existing features. This happens by default when using 'ios.toolchain.cmake'.
# Work it around by setting this value to `EXECUTABLE`.
if(CMAKE_TRY_COMPILE_TARGET_TYPE STREQUAL "STATIC_LIBRARY")
  message(STATUS "CMAKE_TRY_COMPILE_TARGET_TYPE was found set to STATIC_LIBRARY. "
    "Overriding with EXECUTABLE for feature detections to work.")
  set(_cmake_try_compile_target_type_save ${CMAKE_TRY_COMPILE_TARGET_TYPE})
  set(CMAKE_TRY_COMPILE_TARGET_TYPE "EXECUTABLE")
endif()

option(CURL_WERROR "Turn compiler warnings into errors" OFF)
option(PICKY_COMPILER "Enable picky compiler options" ON)
option(BUILD_CURL_EXE "Build curl executable" ON)
get_property(_has_shared GLOBAL PROPERTY TARGET_SUPPORTS_SHARED_LIBS)
option(BUILD_SHARED_LIBS "Build shared libraries" ${_has_shared})
option(BUILD_STATIC_LIBS "Build static libraries" OFF)
option(BUILD_STATIC_CURL "Build curl executable with static libcurl" OFF)
option(ENABLE_ARES "Enable c-ares support" OFF)
option(CURL_DISABLE_INSTALL "Disable installation targets" OFF)
option(CURL_BUILD_EVERYTHING "Build optional build targets (examples, tests) by default" OFF)

if(WIN32)
  option(ENABLE_UNICODE "Use the Unicode version of the Windows API functions" OFF)
  if(WINDOWS_STORE)
    set(ENABLE_UNICODE ON)
  endif()
  if(ENABLE_UNICODE)
    set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "UNICODE" "_UNICODE")
    if(MINGW)
      set_property(DIRECTORY APPEND PROPERTY COMPILE_OPTIONS "-municode")
    endif()
  endif()

  # Apply to all feature checks
  list(APPEND CMAKE_REQUIRED_DEFINITIONS "-DWIN32_LEAN_AND_MEAN")

  set(CURL_TARGET_WINDOWS_VERSION "" CACHE STRING "Minimum target Windows version as hex string")
  if(CURL_TARGET_WINDOWS_VERSION)
    if(CURL_TARGET_WINDOWS_VERSION MATCHES "^0x[0-9a-fA-F]+$")
      set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "_WIN32_WINNT=${CURL_TARGET_WINDOWS_VERSION}")
      list(APPEND CMAKE_REQUIRED_DEFINITIONS "-D_WIN32_WINNT=${CURL_TARGET_WINDOWS_VERSION}")  # Apply to all feature checks
    else()
      message(WARNING "CURL_TARGET_WINDOWS_VERSION value '${CURL_TARGET_WINDOWS_VERSION}' is not a valid hex string.")
    endif()
  endif()

  # Detect actual value of _WIN32_WINNT and store as HAVE_WIN32_WINNT
  curl_internal_test(HAVE_WIN32_WINNT)
  if(HAVE_WIN32_WINNT)
    string(REGEX MATCH "_WIN32_WINNT=0x[0-9a-fA-F]+" CURL_TEST_OUTPUT "${CURL_TEST_OUTPUT}")
    string(REGEX REPLACE "_WIN32_WINNT=" "" CURL_TEST_OUTPUT "${CURL_TEST_OUTPUT}")
    string(REGEX REPLACE "0x([0-9a-fA-F][0-9a-fA-F][0-9a-fA-F])$" "0x0\\1" CURL_TEST_OUTPUT "${CURL_TEST_OUTPUT}") # pad to 4 digits
    string(TOLOWER "${CURL_TEST_OUTPUT}" HAVE_WIN32_WINNT)
    message(STATUS "Found _WIN32_WINNT=${HAVE_WIN32_WINNT}")
  endif()
  unset(HAVE_WIN32_WINNT CACHE)  # Avoid storing in CMake cache

  if(MINGW)
    # Detect __MINGW64_VERSION_MAJOR, __MINGW64_VERSION_MINOR and store as MINGW64_VERSION
    curl_internal_test(MINGW64_VERSION)
    if(MINGW64_VERSION)
      string(REGEX MATCH "MINGW64_VERSION=[0-9]+\.[0-9]+" CURL_TEST_OUTPUT "${CURL_TEST_OUTPUT}")
      string(REGEX REPLACE "MINGW64_VERSION=" "" MINGW64_VERSION "${CURL_TEST_OUTPUT}")
      if(MINGW64_VERSION)
        message(STATUS "Found MINGW64_VERSION=${MINGW64_VERSION}")
        if(MINGW64_VERSION VERSION_LESS 3.0)
          message(FATAL_ERROR "mingw-w64 3.0 or greater required")
        endif()
      endif()
    endif()
    unset(MINGW64_VERSION CACHE)  # Avoid storing in CMake cache
  endif()
elseif(DOS)
  set(BUILD_SHARED_LIBS OFF)
  set(BUILD_STATIC_LIBS ON)
endif()
option(CURL_LTO "Enable compiler Link Time Optimizations" OFF)

if(NOT DOS AND NOT AMIGA)
  # if c-ares is used, default the threaded resolver to OFF
  if(ENABLE_ARES)
    set(_enable_threaded_resolver_default OFF)
  else()
    set(_enable_threaded_resolver_default ON)
  endif()
  option(ENABLE_THREADED_RESOLVER "Enable threaded DNS lookup" ${_enable_threaded_resolver_default})
endif()

if(CYGWIN OR CMAKE_SYSTEM_NAME STREQUAL "Linux" OR CMAKE_SYSTEM_NAME STREQUAL "GNU")
  set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "_GNU_SOURCE")  # Required for accept4(), pipe2(), sendmmsg()
  list(APPEND CMAKE_REQUIRED_DEFINITIONS "-D_GNU_SOURCE")  # Apply to all feature checks
endif()

option(ENABLE_DEBUG "Enable curl debug features (for developing curl)" OFF)
if(ENABLE_DEBUG)
  if(CMAKE_BUILD_TYPE AND NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
    message(FATAL_ERROR "Debug-enabled (aka development mode) curl requires the Debug configuration")
  endif()
  message(WARNING "This curl build is Debug-enabled and insecure, do not use in production.")
endif()

set(CURL_DEBUG_MACROS "")
if(ENABLE_DEBUG)
  list(APPEND CURL_DEBUG_MACROS "DEBUGBUILD")
endif()

option(CURL_CLANG_TIDY "Run the build through clang-tidy" OFF)
if(CURL_CLANG_TIDY)
  find_program(CLANG_TIDY NAMES "clang-tidy" REQUIRED)
  if(NOT CMAKE_C_COMPILER_ID MATCHES "Clang")
    set(PICKY_COMPILER OFF)  # Do a best effort and skip passing non-clang warning options to clang-tidy.
    # This lets through warning options enabled via CURL_WERROR=ON, affecting lib and src.
  endif()
  set(CURL_DISABLE_TYPECHECK ON)  # to improve performance (1.4x), avoid potential interference and bugprone-macro-parentheses.
  set(CMAKE_C_CLANG_TIDY "${CLANG_TIDY}")
  list(APPEND CMAKE_C_CLANG_TIDY "--config-file=${PROJECT_SOURCE_DIR}/.clang-tidy.yml")
  if(CURL_WERROR)
    list(APPEND CMAKE_C_CLANG_TIDY "--warnings-as-errors=*")
  endif()
  if(CURL_CLANG_TIDYFLAGS)
    string(REPLACE " " ";" _tidy_flags_list "${CURL_CLANG_TIDYFLAGS}")
    list(APPEND CMAKE_C_CLANG_TIDY ${_tidy_flags_list})
  endif()
endif()

option(CURL_GCC_ANALYZER "Enable GCC --analyzer option" OFF)
if(CURL_GCC_ANALYZER AND CMAKE_C_COMPILER_ID STREQUAL "GNU" AND CMAKE_C_COMPILER_VERSION VERSION_GREATER_EQUAL 11.0)
  set(CURL_DISABLE_TYPECHECK ON)  # to improve performance (1.1x).
  # https://gcc.gnu.org/onlinedocs/gcc/Static-Analyzer-Options.html
  set(CURL_ANALYZER_CFLAGS "-fanalyzer")
  # disable checks causing false positives only
  list(APPEND CURL_ANALYZER_CFLAGS "-Wno-analyzer-fd-leak" "-Wno-analyzer-fd-use-without-check" "-Wno-analyzer-file-leak")
  list(APPEND CURL_ANALYZER_CFLAGS "-Wno-analyzer-infinite-loop")
  list(APPEND CURL_ANALYZER_CFLAGS "-Wno-analyzer-malloc-leak")
  list(APPEND CURL_ANALYZER_CFLAGS "-Wno-analyzer-out-of-bounds")
endif()

option(CURL_CODE_COVERAGE "Enable code coverage build options" OFF)
if(CURL_CODE_COVERAGE)
  if(CMAKE_C_COMPILER_ID STREQUAL "GNU")
    set(CURL_COVERAGE_MACROS "NDEBUG")
    set(CURL_COVERAGE_CFLAGS "-O0" "-g" "-fprofile-arcs")
    if(CMAKE_C_COMPILER_VERSION VERSION_GREATER_EQUAL 4.1)
      list(APPEND CURL_COVERAGE_CFLAGS "--coverage")
    else()
      list(APPEND CURL_COVERAGE_CFLAGS "-ftest-coverage")
    endif()
    set(CURL_COVERAGE_LIBS "gcov")
  elseif(CMAKE_C_COMPILER_ID MATCHES "Clang")
    set(CURL_COVERAGE_MACROS "NDEBUG")
    set(CURL_COVERAGE_CFLAGS "-O0" "-g" "-fprofile-instr-generate" "-fcoverage-mapping")
    set(CURL_COVERAGE_LDFLAGS "-fprofile-instr-generate" "-fcoverage-mapping")
  else()
    set(CURL_CODE_COVERAGE OFF)
  endif()
endif()

include(PickyWarnings)

set(CURL_CFLAGS "")  # C flags set for libcurl and curl tool (aka public binaries) only

option(CURL_DROP_UNUSED "Drop unused code and data from built binaries" OFF)
if(CURL_DROP_UNUSED)
  if(APPLE)
    set_property(DIRECTORY APPEND PROPERTY LINK_OPTIONS "-Wl,-dead_strip")
  elseif(MSVC)  # Options below are toolchain defaults in Release configurations.
    # This option does not seem to have an effect with VS2010:
    set_property(DIRECTORY APPEND PROPERTY LINK_OPTIONS "-OPT:REF")
    # Optional, but reduces binary size further, with the cost of larger objects/static libraries:
    list(APPEND CURL_CFLAGS "-Gy")
  elseif(CMAKE_C_COMPILER_ID STREQUAL "GNU" OR CMAKE_C_COMPILER_ID MATCHES "Clang")
    if(WIN32)
      # To make -Wl,--gc-sections work on Windows: https://sourceware.org/bugzilla/show_bug.cgi?id=11539
      set_property(DIRECTORY APPEND PROPERTY COMPILE_OPTIONS "-fno-asynchronous-unwind-tables")
    endif()
    set_property(DIRECTORY APPEND PROPERTY LINK_OPTIONS "-Wl,--gc-sections")
    # Optional, but reduces binary size further, with the cost of larger objects/static libraries:
    list(APPEND CURL_CFLAGS "-ffunction-sections" "-fdata-sections")
  endif()
endif()

# For debug libs and exes, add "-d" postfix
if(NOT DEFINED CMAKE_DEBUG_POSTFIX)
  set(CMAKE_DEBUG_POSTFIX "-d")
endif()

set(LIB_STATIC "libcurl_static")
set(LIB_SHARED "libcurl_shared")

if(NOT BUILD_SHARED_LIBS AND NOT BUILD_STATIC_LIBS)
  set(BUILD_STATIC_LIBS ON)
endif()
if(NOT BUILD_STATIC_CURL AND NOT BUILD_SHARED_LIBS)
  set(BUILD_STATIC_CURL ON)
elseif(BUILD_STATIC_CURL AND NOT BUILD_STATIC_LIBS)
  set(BUILD_STATIC_CURL OFF)
endif()

# Lib flavor selected for curl tool
if(BUILD_STATIC_CURL)
  set(LIB_SELECTED_FOR_EXE ${LIB_STATIC})
else()
  set(LIB_SELECTED_FOR_EXE ${LIB_SHARED})
endif()

# Lib flavor selected for example and test programs.
if(BUILD_SHARED_LIBS)
  set(LIB_SELECTED ${LIB_SHARED})
else()
  set(LIB_SELECTED ${LIB_STATIC})
endif()

if(WIN32)
  option(CURL_STATIC_CRT "Build libcurl with static CRT with MSVC (/MT)" OFF)
  if(CURL_STATIC_CRT AND MSVC)
    if(MSVC_VERSION GREATER_EQUAL 1900 OR BUILD_STATIC_CURL OR NOT BUILD_CURL_EXE)
      set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
      set_property(DIRECTORY APPEND PROPERTY COMPILE_OPTIONS "$<$<CONFIG:Release>:-MT>")
      set_property(DIRECTORY APPEND PROPERTY COMPILE_OPTIONS "$<$<CONFIG:Debug>:-MTd>")
    else()
      message(WARNING "Static CRT requires UCRT, static libcurl or no curl executable.")
    endif()
  endif()
endif()

# Override to force-disable or force-enable the use of CMake Configs.
if(MSVC AND NOT VCPKG_TOOLCHAIN AND NOT CMAKE_CROSSCOMPILING)
  set(_curl_use_cmakeconfig_default ON)
else()
  set(_curl_use_cmakeconfig_default OFF)
endif()
option(CURL_USE_CMAKECONFIG "Enable detecting dependencies via CMake Config" ${_curl_use_cmakeconfig_default})

# Override to force-disable or force-enable the use of pkg-config.
if((UNIX AND NOT ANDROID AND (NOT APPLE OR CMAKE_SYSTEM_NAME STREQUAL "Darwin")) OR
   VCPKG_TOOLCHAIN OR
   (MINGW AND NOT CMAKE_CROSSCOMPILING))
  set(_curl_use_pkgconfig_default ON)
else()
  set(_curl_use_pkgconfig_default OFF)
endif()
option(CURL_USE_PKGCONFIG "Enable pkg-config to detect dependencies" ${_curl_use_pkgconfig_default})

# Initialize variables collecting system and dependency libs.
set(CURL_NETWORK_AND_TIME_LIBS "")
set(CURL_LIBS "")

if(ENABLE_ARES)
  set(USE_ARES 1)
  find_package(Cares MODULE REQUIRED)
  list(APPEND CURL_LIBS CURL::cares)
endif()

include(CurlSymbolHiding)

option(CURL_ENABLE_EXPORT_TARGET "Enable CMake export target" ON)
mark_as_advanced(CURL_ENABLE_EXPORT_TARGET)

option(CURL_DISABLE_ALTSVC "Disable alt-svc support" OFF)
mark_as_advanced(CURL_DISABLE_ALTSVC)
option(CURL_DISABLE_COOKIES "Disable cookies support" OFF)
mark_as_advanced(CURL_DISABLE_COOKIES)
option(CURL_DISABLE_BASIC_AUTH "Disable Basic authentication" OFF)
mark_as_advanced(CURL_DISABLE_BASIC_AUTH)
option(CURL_DISABLE_BEARER_AUTH "Disable Bearer authentication" OFF)
mark_as_advanced(CURL_DISABLE_BEARER_AUTH)
option(CURL_DISABLE_DIGEST_AUTH "Disable Digest authentication" OFF)
mark_as_advanced(CURL_DISABLE_DIGEST_AUTH)
option(CURL_DISABLE_KERBEROS_AUTH "Disable Kerberos authentication" OFF)
mark_as_advanced(CURL_DISABLE_KERBEROS_AUTH)
option(CURL_DISABLE_NEGOTIATE_AUTH "Disable negotiate authentication" OFF)
mark_as_advanced(CURL_DISABLE_NEGOTIATE_AUTH)
option(CURL_DISABLE_AWS "Disable aws-sigv4" OFF)
mark_as_advanced(CURL_DISABLE_AWS)
option(CURL_DISABLE_DICT "Disable DICT" OFF)
mark_as_advanced(CURL_DISABLE_DICT)
option(CURL_DISABLE_DOH "Disable DNS-over-HTTPS" OFF)
mark_as_advanced(CURL_DISABLE_DOH)
option(CURL_DISABLE_FILE "Disable FILE" OFF)
mark_as_advanced(CURL_DISABLE_FILE)
option(CURL_DISABLE_FTP "Disable FTP" OFF)
mark_as_advanced(CURL_DISABLE_FTP)
option(CURL_DISABLE_GETOPTIONS "Disable curl_easy_options API for existing options to curl_easy_setopt" OFF)
mark_as_advanced(CURL_DISABLE_GETOPTIONS)
option(CURL_DISABLE_GOPHER "Disable Gopher" OFF)
mark_as_advanced(CURL_DISABLE_GOPHER)
option(CURL_DISABLE_HEADERS_API "Disable headers-api support" OFF)
mark_as_advanced(CURL_DISABLE_HEADERS_API)
option(CURL_DISABLE_HSTS "Disable HSTS support" OFF)
mark_as_advanced(CURL_DISABLE_HSTS)
option(CURL_DISABLE_HTTP "Disable HTTP" OFF)
mark_as_advanced(CURL_DISABLE_HTTP)
option(CURL_DISABLE_HTTP_AUTH "Disable all HTTP authentication methods" OFF)
mark_as_advanced(CURL_DISABLE_HTTP_AUTH)
option(CURL_DISABLE_HTTPSIG "Disable HTTP Message Signatures (RFC 9421) (experimental)" ON)
mark_as_advanced(CURL_DISABLE_HTTPSIG)
option(CURL_DISABLE_IMAP "Disable IMAP" OFF)
mark_as_advanced(CURL_DISABLE_IMAP)
option(CURL_DISABLE_LDAP "Disable LDAP" OFF)
mark_as_advanced(CURL_DISABLE_LDAP)
option(CURL_DISABLE_LDAPS "Disable LDAPS" ${CURL_DISABLE_LDAP})
mark_as_advanced(CURL_DISABLE_LDAPS)
option(CURL_DISABLE_LIBCURL_OPTION "Disable --libcurl option from the curl tool" OFF)
mark_as_advanced(CURL_DISABLE_LIBCURL_OPTION)
option(CURL_DISABLE_MIME "Disable MIME support" OFF)
mark_as_advanced(CURL_DISABLE_MIME)
cmake_dependent_option(CURL_DISABLE_FORM_API "Disable form-api"
  OFF "NOT CURL_DISABLE_MIME"
  ON)
mark_as_advanced(CURL_DISABLE_FORM_API)
option(CURL_DISABLE_MQTT "Disable MQTT" OFF)
mark_as_advanced(CURL_DISABLE_MQTT)
option(CURL_DISABLE_BINDLOCAL "Disable local binding support" OFF)
mark_as_advanced(CURL_DISABLE_BINDLOCAL)
option(CURL_DISABLE_NETRC "Disable netrc parser" OFF)
mark_as_advanced(CURL_DISABLE_NETRC)
option(CURL_ENABLE_NTLM "Enable NTLM support" OFF)
mark_as_advanced(CURL_ENABLE_NTLM)
option(CURL_DISABLE_PARSEDATE "Disable date parsing" OFF)
mark_as_advanced(CURL_DISABLE_PARSEDATE)
option(CURL_DISABLE_POP3 "Disable POP3" OFF)
mark_as_advanced(CURL_DISABLE_POP3)
option(CURL_DISABLE_PROGRESS_METER "Disable built-in progress meter" OFF)
mark_as_advanced(CURL_DISABLE_PROGRESS_METER)
option(CURL_DISABLE_PROXY "Disable proxy support" OFF)
mark_as_advanced(CURL_DISABLE_PROXY)
option(CURL_DISABLE_IPFS "Disable IPFS" OFF)
mark_as_advanced(CURL_DISABLE_IPFS)
option(CURL_DISABLE_RTSP "Disable RTSP" OFF)
mark_as_advanced(CURL_DISABLE_RTSP)
option(CURL_DISABLE_SHA512_256 "Disable SHA-512/256 hash algorithm" OFF)
mark_as_advanced(CURL_DISABLE_SHA512_256)
option(CURL_DISABLE_SHUFFLE_DNS "Disable shuffle DNS feature" OFF)
mark_as_advanced(CURL_DISABLE_SHUFFLE_DNS)
option(CURL_DISABLE_SMTP "Disable SMTP" OFF)
mark_as_advanced(CURL_DISABLE_SMTP)
option(CURL_DISABLE_SOCKETPAIR "Disable use of socketpair for curl_multi_poll()" OFF)
mark_as_advanced(CURL_DISABLE_SOCKETPAIR)
option(CURL_DISABLE_WEBSOCKETS "Disable WebSocket" OFF)
mark_as_advanced(CURL_DISABLE_WEBSOCKETS)
option(CURL_DISABLE_TELNET "Disable Telnet" OFF)
mark_as_advanced(CURL_DISABLE_TELNET)
option(CURL_DISABLE_TFTP "Disable TFTP" OFF)
mark_as_advanced(CURL_DISABLE_TFTP)
option(CURL_DISABLE_TYPECHECK "Disable curl_easy_setopt()/curl_easy_getinfo() type checking" OFF)
mark_as_advanced(CURL_DISABLE_TYPECHECK)
option(CURL_DISABLE_VERBOSE_STRINGS "Disable verbose strings" OFF)
mark_as_advanced(CURL_DISABLE_VERBOSE_STRINGS)
option(CURL_DEBUG_GLOBAL_MEM "Debug curl_global_init_mem" OFF)
mark_as_advanced(CURL_DEBUG_GLOBAL_MEM)

if(CURL_DEBUG_GLOBAL_MEM)
  # Set it via the command-line to make it apply to the entire directory.
  set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "CURL_DEBUG_GLOBAL_MEM")
endif()
if(CURL_DISABLE_TYPECHECK)
  # Set it via the command-line to make it apply to examples also.
  set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "CURL_DISABLE_TYPECHECK")
endif()

if(CURL_DISABLE_HTTP)
  set(CURL_DISABLE_ALTSVC ON)
  set(CURL_DISABLE_HSTS ON)
  set(CURL_DISABLE_IPFS ON)
  set(CURL_DISABLE_RTSP ON)
  set(CURL_DISABLE_WEBSOCKETS ON)
endif()

if(WINDOWS_STORE)
  set(CURL_DISABLE_TELNET ON)  # telnet code needs fixing to compile for UWP.
endif()

option(CURL_LINT "Run lint checks while building" OFF)

find_package(Perl)

if(PERL_EXECUTABLE)
  add_custom_target(curl-ca-bundle
    COMMENT "Generating a fresh ca-bundle.crt" VERBATIM USES_TERMINAL
    COMMAND "${PERL_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/scripts/mk-ca-bundle.pl" -b -l -u "lib/ca-bundle.crt"
    DEPENDS "${PROJECT_SOURCE_DIR}/scripts/mk-ca-bundle.pl"
  )
  add_custom_target(curl-ca-firefox
    COMMENT "Generating a fresh ca-bundle.crt" VERBATIM USES_TERMINAL
    COMMAND "${PERL_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/scripts/firefox-db2pem.sh" "lib/ca-bundle.crt"
    DEPENDS "${PROJECT_SOURCE_DIR}/scripts/firefox-db2pem.sh"
  )
  add_custom_target(curl-lint
    COMMENT "Running lint checks" VERBATIM USES_TERMINAL
    WORKING_DIRECTORY ${PROJECT_SOURCE_DIR}
    COMMAND "${PERL_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/scripts/badwords-all"
    COMMAND "${PERL_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/scripts/checksrc-all.pl"
    COMMAND "${PERL_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/scripts/spacecheck.pl"
    DEPENDS
      "${PROJECT_SOURCE_DIR}/scripts/badwords-all" "${PROJECT_SOURCE_DIR}/scripts/badwords"
      "${PROJECT_SOURCE_DIR}/scripts/checksrc-all.pl" "${PROJECT_SOURCE_DIR}/scripts/checksrc.pl"
      "${PROJECT_SOURCE_DIR}/scripts/spacecheck.pl"
  )
  if(CURL_LINT)
    set_target_properties(curl-lint PROPERTIES EXCLUDE_FROM_ALL FALSE)
  endif()
endif()

option(BUILD_LIBCURL_DOCS "Build libcurl man pages" ON)
option(BUILD_MISC_DOCS "Build misc man pages (e.g. curl-config and mk-ca-bundle)" ON)
option(ENABLE_CURL_MANUAL "Build the man page for curl and enable its -M/--manual option" ON)

if((ENABLE_CURL_MANUAL OR BUILD_LIBCURL_DOCS) AND NOT Perl_FOUND)
  message(WARNING "Perl not found. Cannot build manuals.")
endif()

# If we are on AIX, do the _ALL_SOURCE magic
if(AIX OR CMAKE_SYSTEM_NAME STREQUAL "AIX")
  set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "_ALL_SOURCE")
endif()

# If we are on Haiku, make sure that the network library is brought in.
if(CMAKE_SYSTEM_NAME STREQUAL "Haiku")
  list(APPEND CURL_NETWORK_AND_TIME_LIBS "network")
elseif(AMIGA)
  list(APPEND CURL_NETWORK_AND_TIME_LIBS "net" "m" "atomic")
  list(APPEND CMAKE_REQUIRED_LIBRARIES "net" "m" "atomic")
endif()

# Include all the necessary files for macros
include(CMakePushCheckState)
include(CheckFunctionExists)
include(CheckIncludeFile)
include(CheckIncludeFiles)
include(CheckLibraryExists)
include(CheckSymbolExists)
include(CheckTypeSize)
include(CheckCSourceCompiles)

option(_CURL_PREFILL "Pre-fill known feature detection results (Windows, some Apple)" "${WIN32}")
mark_as_advanced(_CURL_PREFILL)
if(_CURL_PREFILL)
  if(WIN32)
    include("${PROJECT_SOURCE_DIR}/CMake/win32-cache.cmake")
  elseif(UNIX)
    include("${PROJECT_SOURCE_DIR}/CMake/unix-cache.cmake")
    message(STATUS "Pre-filling feature detection results for UNIX")
  endif()
elseif(WIN32)
  message(STATUS "Pre-filling feature detection results disabled.")
elseif(APPLE)
  set(HAVE_EVENTFD 0)
  set(HAVE_GETPASS_R 0)
  set(HAVE_WRITABLE_ARGV 1)
  set(HAVE_SENDMMSG 0)
endif()
if(DOS OR AMIGA)
  set(HAVE_TIME_T_UNSIGNED 1)  # Pre-fill
endif()

if(AMIGA)
  set(HAVE_GETADDRINFO 0)  # Breaks the build when detected and used.
endif()

if(NOT WIN32)
  find_package(Threads)
  if(CMAKE_USE_PTHREADS_INIT)
    set(HAVE_THREADS_POSIX 1)
    list(APPEND CURL_NETWORK_AND_TIME_LIBS Threads::Threads)
  endif()
endif()

if(ENABLE_THREADED_RESOLVER)
  if(NOT WIN32 AND NOT HAVE_THREADS_POSIX)
    message(FATAL_ERROR "Threaded resolver requires POSIX Threads.")
  endif()
  set(USE_RESOLV_THREADED ON)
elseif(USE_ARES)
  set(USE_RESOLV_ARES ON)
endif()

# Check for all needed libraries
if(DOS)
  if(WATT_ROOT)
    set(USE_WATT32 ON)
    # FIXME upstream: must specify the full path to avoid CMake converting "watt" to "watt.lib"
    list(APPEND CURL_NETWORK_AND_TIME_LIBS "${WATT_ROOT}/lib/libwatt.a")
    include_directories(SYSTEM "${WATT_ROOT}/inc")
    list(APPEND CMAKE_REQUIRED_INCLUDES "${WATT_ROOT}/inc")
  else()
    message(FATAL_ERROR "Set WATT_ROOT variable to the absolute path to the root installation of Watt-32.")
  endif()
elseif(AMIGA)
  if(AMISSL_INCLUDE_DIR AND AMISSL_STUBS_LIBRARY AND AMISSL_AUTO_LIBRARY)
    set(USE_AMISSL ON)
    list(APPEND CMAKE_REQUIRED_INCLUDES "${AMISSL_INCLUDE_DIR}")
    list(APPEND CMAKE_REQUIRED_LIBRARIES "${AMISSL_STUBS_LIBRARY}" "${AMISSL_AUTO_LIBRARY}")
    set(OPENSSL_INCLUDE_DIR "${AMISSL_INCLUDE_DIR}")
    set(OPENSSL_SSL_LIBRARY "${AMISSL_STUBS_LIBRARY}")
    set(OPENSSL_CRYPTO_LIBRARY "${AMISSL_AUTO_LIBRARY}")
    set(CURL_USE_OPENSSL ON)
    set(CURL_CA_FALLBACK ON CACHE BOOL "")
    list(PREPEND CURL_NETWORK_AND_TIME_LIBS "${AMISSL_STUBS_LIBRARY}" "${AMISSL_AUTO_LIBRARY}")
  endif()
elseif(NOT WIN32 AND NOT APPLE)
  check_library_exists("socket" "connect" "" HAVE_LIBSOCKET)
  if(HAVE_LIBSOCKET)
    list(PREPEND CURL_NETWORK_AND_TIME_LIBS "socket")
  endif()
endif()

option(ENABLE_IPV6 "Enable IPv6 support" ON)
mark_as_advanced(ENABLE_IPV6)
if(ENABLE_IPV6)
  include(CheckStructHasMember)
  if(WIN32)
    check_struct_has_member("struct sockaddr_in6" "sin6_scope_id" "winsock2.h;ws2tcpip.h" HAVE_SOCKADDR_IN6_SIN6_SCOPE_ID)
  else()
    check_struct_has_member("struct sockaddr_in6" "sin6_scope_id" "netinet/in.h" HAVE_SOCKADDR_IN6_SIN6_SCOPE_ID)
    check_struct_has_member("struct sockaddr_in6" "sin6_addr" "netinet/in.h" HAVE_SOCKADDR_IN6_SIN6_ADDR)
    if(NOT HAVE_SOCKADDR_IN6_SIN6_ADDR)
      if(NOT DOS AND NOT AMIGA)
        message(WARNING "struct sockaddr_in6 not available, disabling IPv6 support")
      endif()
      set(ENABLE_IPV6 OFF CACHE BOOL "Enable IPv6 support" FORCE)  # Force the feature off as we use this name as guard macro
    endif()

    if(CMAKE_SYSTEM_NAME STREQUAL "Darwin" AND NOT ENABLE_ARES)
      set(_use_core_foundation_and_core_services ON)

      find_library(SYSTEMCONFIGURATION_FRAMEWORK NAMES "SystemConfiguration")
      mark_as_advanced(SYSTEMCONFIGURATION_FRAMEWORK)
      if(NOT SYSTEMCONFIGURATION_FRAMEWORK)
        message(FATAL_ERROR "SystemConfiguration framework not found")
      endif()
      list(APPEND CURL_LIBS "-framework SystemConfiguration")
    endif()
  endif()
endif()
if(ENABLE_IPV6)
  set(USE_IPV6 ON)
endif()

# Check SSL libraries
option(CURL_ENABLE_SSL "Enable SSL support" ON)

if(CURL_DEFAULT_SSL_BACKEND)
  set(_valid_default_ssl_backend FALSE)
endif()

if(WIN32)
  cmake_dependent_option(CURL_USE_SCHANNEL "Enable Windows native SSL/TLS (Schannel)" OFF CURL_ENABLE_SSL OFF)
  option(CURL_WINDOWS_SSPI "Enable SSPI on Windows" ${CURL_USE_SCHANNEL})
else()
  set(CURL_USE_SCHANNEL OFF)
  set(CURL_WINDOWS_SSPI OFF)
endif()
cmake_dependent_option(CURL_USE_MBEDTLS "Enable mbedTLS for SSL/TLS" OFF CURL_ENABLE_SSL OFF)
cmake_dependent_option(CURL_USE_WOLFSSL "Enable wolfSSL for SSL/TLS" OFF CURL_ENABLE_SSL OFF)
cmake_dependent_option(CURL_USE_GNUTLS "Enable GnuTLS for SSL/TLS" OFF CURL_ENABLE_SSL OFF)
cmake_dependent_option(CURL_USE_RUSTLS "Enable Rustls for SSL/TLS (experimental)" OFF CURL_ENABLE_SSL OFF)

if(WIN32 OR
   CURL_USE_SCHANNEL OR
   CURL_USE_MBEDTLS OR
   CURL_USE_WOLFSSL OR
   CURL_USE_GNUTLS OR
   CURL_USE_RUSTLS)
  set(_openssl_default OFF)
else()
  set(_openssl_default ON)
endif()
cmake_dependent_option(CURL_USE_OPENSSL "Enable OpenSSL for SSL/TLS" ${_openssl_default} CURL_ENABLE_SSL OFF)
option(CURL_DISABLE_OPENSSL_AUTO_LOAD_CONFIG "Disable automatic loading of OpenSSL configuration" OFF)

curl_count_true(_enabled_ssl_options_count
  CURL_USE_SCHANNEL
  CURL_USE_OPENSSL
  CURL_USE_MBEDTLS
  CURL_USE_WOLFSSL
  CURL_USE_GNUTLS
  CURL_USE_RUSTLS
)
if(_enabled_ssl_options_count GREATER 1)
  set(CURL_WITH_MULTI_SSL ON)
elseif(_enabled_ssl_options_count EQUAL 0)
  set(CURL_DISABLE_HSTS ON)
endif()

if(CURL_USE_SCHANNEL)
  if(WINDOWS_STORE)
    message(FATAL_ERROR "UWP does not support Schannel.")
  endif()
  set(_ssl_enabled ON)
  set(USE_SCHANNEL ON)  # Windows native SSL/TLS support
  set(USE_WINDOWS_SSPI ON)  # CURL_USE_SCHANNEL requires CURL_WINDOWS_SSPI

  if(CURL_DEFAULT_SSL_BACKEND AND CURL_DEFAULT_SSL_BACKEND STREQUAL "schannel")
    set(_valid_default_ssl_backend TRUE)
  endif()
endif()
if(CURL_WINDOWS_SSPI AND NOT WINDOWS_STORE)
  set(USE_WINDOWS_SSPI ON)
endif()

if(APPLE)
  option(USE_APPLE_SECTRUST "Use Apple OS-native certificate verification" OFF)
  if(USE_APPLE_SECTRUST)
    if(NOT CURL_USE_OPENSSL AND NOT CURL_USE_GNUTLS)
      message(FATAL_ERROR "Apple SecTrust is only supported with Openssl/GnuTLS")
    endif()
    find_library(SECURITY_FRAMEWORK NAMES "Security")
    mark_as_advanced(SECURITY_FRAMEWORK)
    if(NOT SECURITY_FRAMEWORK)
      message(FATAL_ERROR "Security framework not found")
    endif()
    list(APPEND CURL_LIBS "-framework Security")

    set(_use_core_foundation_and_core_services ON)
    message(STATUS "Apple OS-native certificate verification enabled")
  endif()
else()
  set(USE_APPLE_SECTRUST OFF)
endif()

set(USE_APPLE_FAST_UDP 0)
if(APPLE)
  option(CURL_ENABLE_APPLE_FAST_UDP "Use Apple fast UDP (experimental)" OFF)
  if(CURL_ENABLE_APPLE_FAST_UDP)
    set(USE_APPLE_FAST_UDP 1)
  endif()
endif()

if(_use_core_foundation_and_core_services)
  find_library(COREFOUNDATION_FRAMEWORK NAMES "CoreFoundation")
  mark_as_advanced(COREFOUNDATION_FRAMEWORK)
  if(NOT COREFOUNDATION_FRAMEWORK)
    message(FATAL_ERROR "CoreFoundation framework not found")
  endif()
  list(APPEND CURL_LIBS "-framework CoreFoundation")

  find_library(CORESERVICES_FRAMEWORK NAMES "CoreServices")
  mark_as_advanced(CORESERVICES_FRAMEWORK)
  if(NOT CORESERVICES_FRAMEWORK)
    message(FATAL_ERROR "CoreServices framework not found")
  endif()
  list(APPEND CURL_LIBS "-framework CoreServices")
endif()

if(NOT DEFINED _curl_stdlib_cxx)
  set(_curl_stdlib_cxx "stdc++")
endif()

if(CURL_USE_OPENSSL)
  find_package(OpenSSL REQUIRED)
  set(_ssl_enabled ON)
  set(USE_OPENSSL ON)

  # Depend on OpenSSL via imported targets. This allows our dependents to
  # get our dependencies transitively.
  list(APPEND CURL_LIBS OpenSSL::SSL OpenSSL::Crypto)

  if(CURL_DEFAULT_SSL_BACKEND AND CURL_DEFAULT_SSL_BACKEND STREQUAL "openssl")
    set(_valid_default_ssl_backend TRUE)
  endif()
  set(_curl_ca_bundle_supported TRUE)

  cmake_push_check_state()
  list(APPEND CMAKE_REQUIRED_LIBRARIES OpenSSL::SSL OpenSSL::Crypto)
  if(NOT DEFINED HAVE_AWSLC)
    check_symbol_exists("OPENSSL_IS_AWSLC" "openssl/base.h" HAVE_AWSLC)
  endif()
  if(NOT DEFINED HAVE_BORINGSSL AND NOT HAVE_AWSLC)
    check_symbol_exists("OPENSSL_IS_BORINGSSL" "openssl/base.h" HAVE_BORINGSSL)
  endif()
  if(NOT DEFINED HAVE_LIBRESSL AND NOT HAVE_AWSLC AND NOT HAVE_BORINGSSL)
    check_symbol_exists("LIBRESSL_VERSION_NUMBER" "openssl/opensslv.h" HAVE_LIBRESSL)
  endif()
  cmake_pop_check_state()

  if(HAVE_AWSLC OR HAVE_BORINGSSL)
    if(NOT MSVC AND NOT ANDROID)  # AWS-LC/BoringSSL MSVC builds use native Windows threads
      find_package(Threads)
      if(CMAKE_USE_PTHREADS_INIT)
        set(HAVE_THREADS_POSIX_BORINGSSL 1)
        list(APPEND CURL_NETWORK_AND_TIME_LIBS Threads::Threads)
        list(APPEND CMAKE_REQUIRED_LIBRARIES Threads::Threads)
      elseif(OPENSSL_USE_STATIC_LIBS)
        message(WARNING "AWS-LC/BoringSSL requires POSIX Threads.")
      endif()
    endif()
    if(OPENSSL_USE_STATIC_LIBS AND
       (CMAKE_C_COMPILER_ID STREQUAL "GNU" OR CMAKE_C_COMPILER_ID MATCHES "Clang"))
      list(APPEND CURL_LIBS "${_curl_stdlib_cxx}")
    endif()
  endif()

  if(USE_AMISSL)
    set(_openssl "AmiSSL")
  elseif(HAVE_AWSLC)
    set(_openssl "AWS-LC")
  elseif(HAVE_BORINGSSL)
    if(BORINGSSL_VERSION)
      set(CURL_BORINGSSL_VERSION "\"${BORINGSSL_VERSION}\"")
    endif()
    set(_openssl "BoringSSL")
  elseif(HAVE_LIBRESSL)
    set(_openssl "LibreSSL")
  else()
    set(_openssl "OpenSSL")
  endif()
endif()

if(CURL_USE_MBEDTLS)
  find_package(MbedTLS MODULE REQUIRED)
  if(MBEDTLS_VERSION VERSION_LESS 3.2.0)
    message(FATAL_ERROR "mbedTLS 3.2.0 or greater required")
  endif()
  set(_ssl_enabled ON)
  set(USE_MBEDTLS ON)
  list(APPEND CURL_LIBS CURL::mbedtls)

  if(CURL_DEFAULT_SSL_BACKEND AND CURL_DEFAULT_SSL_BACKEND STREQUAL "mbedtls")
    set(_valid_default_ssl_backend TRUE)
  endif()
  set(_curl_ca_bundle_supported TRUE)

  if(MBEDTLS_VERSION VERSION_GREATER_EQUAL 4.0.0)
    set(HAVE_MBEDTLS_DES_CRYPT_ECB 0)  # pre-fill detection result
  endif()
  if(NOT DEFINED HAVE_MBEDTLS_DES_CRYPT_ECB)
    cmake_push_check_state()
    list(APPEND CMAKE_REQUIRED_LIBRARIES CURL::mbedtls)
    check_function_exists("mbedtls_des_crypt_ecb" HAVE_MBEDTLS_DES_CRYPT_ECB)  # in mbedTLS <4
    cmake_pop_check_state()
  endif()
endif()

if(CURL_USE_WOLFSSL)
  find_package(WolfSSL MODULE REQUIRED)
  set(_ssl_enabled ON)
  set(USE_WOLFSSL ON)
  list(APPEND CURL_LIBS CURL::wolfssl)

  if(CURL_DEFAULT_SSL_BACKEND AND CURL_DEFAULT_SSL_BACKEND STREQUAL "wolfssl")
    set(_valid_default_ssl_backend TRUE)
  endif()
  set(_curl_ca_bundle_supported TRUE)

  if(USE_OPENSSL AND WOLFSSL_VERSION VERSION_LESS 5.7.6)
    message(FATAL_ERROR "wolfSSL 5.7.6 or greater required to coexist with OpenSSL")
  endif()

  set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "WOLFSSL_OPTIONS_IGNORE_SYS")
endif()

if(CURL_USE_GNUTLS)
  find_package(GnuTLS MODULE REQUIRED)
  list(APPEND CURL_LIBS CURL::gnutls)
  find_package(Nettle MODULE REQUIRED)
  list(APPEND CURL_LIBS CURL::nettle)
  set(_ssl_enabled ON)
  set(USE_GNUTLS ON)

  if(CURL_DEFAULT_SSL_BACKEND AND CURL_DEFAULT_SSL_BACKEND STREQUAL "gnutls")
    set(_valid_default_ssl_backend TRUE)
  endif()
  set(_curl_ca_bundle_supported TRUE)
endif()

if(CURL_USE_RUSTLS)
  find_package(Rustls MODULE REQUIRED)
  set(_ssl_enabled ON)
  set(USE_RUSTLS ON)
  list(APPEND CURL_LIBS CURL::rustls)

  if(NOT DEFINED HAVE_RUSTLS_SUPPORTED_HPKE)
    if(RUSTLS_VERSION AND RUSTLS_VERSION VERSION_GREATER_EQUAL 0.15)
      set(HAVE_RUSTLS_SUPPORTED_HPKE TRUE)
    elseif(NOT RUSTLS_VERSION)
      cmake_push_check_state()
      list(APPEND CMAKE_REQUIRED_LIBRARIES CURL::rustls)
      check_symbol_exists("rustls_supported_hpke" "rustls.h" HAVE_RUSTLS_SUPPORTED_HPKE)
      cmake_pop_check_state()
    endif()
  endif()
  if(NOT HAVE_RUSTLS_SUPPORTED_HPKE)
    message(FATAL_ERROR "rustls-ffi library does not provide rustls_supported_hpke function. Required version is 0.15 or greater.")
  endif()

  if(CURL_DEFAULT_SSL_BACKEND AND CURL_DEFAULT_SSL_BACKEND STREQUAL "rustls")
    set(_valid_default_ssl_backend TRUE)
  endif()
  set(_curl_ca_bundle_supported TRUE)
endif()

if(CURL_DEFAULT_SSL_BACKEND AND NOT _valid_default_ssl_backend)
  message(FATAL_ERROR "CURL_DEFAULT_SSL_BACKEND '${CURL_DEFAULT_SSL_BACKEND}' not enabled.")
endif()

# Keep ZLIB detection after TLS detection,
# and before calling curl_openssl_check_exists().

set(HAVE_LIBZ OFF)
curl_dependency_option(CURL_ZLIB ZLIB "ZLIB")
if(ZLIB_FOUND)
  set(HAVE_LIBZ ON)
  # Depend on ZLIB via imported targets. This allows our dependents to
  # get our dependencies transitively.
  list(APPEND CURL_LIBS ZLIB::ZLIB)
endif()

set(HAVE_BROTLI OFF)
curl_dependency_option(CURL_BROTLI Brotli "brotli")
if(BROTLI_FOUND)
  set(HAVE_BROTLI ON)
  list(APPEND CURL_LIBS CURL::brotli)
endif()

set(HAVE_ZSTD OFF)
curl_dependency_option(CURL_ZSTD Zstd "zstd")
if(ZSTD_FOUND)
  if(ZSTD_VERSION VERSION_GREATER_EQUAL 1.0.0)
    set(HAVE_ZSTD ON)
    list(APPEND CURL_LIBS CURL::zstd)
  else()
    message(WARNING "zstd 1.0.0 or greater required, disabling zstd support")
  endif()
endif()

# Check function in an OpenSSL-like TLS backend.
macro(curl_openssl_check_exists)
  cmake_push_check_state()
  if(USE_OPENSSL)
    list(APPEND CMAKE_REQUIRED_LIBRARIES OpenSSL::SSL OpenSSL::Crypto)
    if(HAVE_LIBZ)
      list(APPEND CMAKE_REQUIRED_LIBRARIES ZLIB::ZLIB)
    endif()
    if(WIN32)
      list(APPEND CMAKE_REQUIRED_LIBRARIES "bcrypt")  # for OpenSSL/LibreSSL BCryptGenRandom()
    endif()
    if((HAVE_AWSLC OR HAVE_BORINGSSL) AND OPENSSL_USE_STATIC_LIBS AND
       (CMAKE_C_COMPILER_ID STREQUAL "GNU" OR CMAKE_C_COMPILER_ID MATCHES "Clang"))
      list(APPEND CMAKE_REQUIRED_LIBRARIES "${_curl_stdlib_cxx}")
    endif()
  endif()
  if(USE_WOLFSSL)
    list(APPEND CMAKE_REQUIRED_LIBRARIES CURL::wolfssl)
    list(APPEND CMAKE_REQUIRED_DEFINITIONS "-DWOLFSSL_OPTIONS_IGNORE_SYS")
    if(HAVE_LIBZ)
      list(APPEND CMAKE_REQUIRED_LIBRARIES ZLIB::ZLIB)  # Public wolfSSL headers also require zlib headers
    endif()
    list(APPEND CMAKE_REQUIRED_DEFINITIONS "-DHAVE_UINTPTR_T")  # to pull in stdint.h (as of wolfSSL 5.5.4)
  endif()
  if(WIN32)
    list(APPEND CMAKE_REQUIRED_LIBRARIES "ws2_32" "crypt32")  # for OpenSSL/wolfSSL
  endif()
  if(${ARGC} EQUAL 2)
    check_function_exists(${ARGN})
  else()
    check_symbol_exists(${ARGN})  # Uses CMAKE_REQUIRED_INCLUDES and CMAKE_REQUIRED_DEFINITIONS
  endif()
  cmake_pop_check_state()
endmacro()

# Ensure that OpenSSL (or fork) or wolfSSL actually supports QUICTLS API.
macro(curl_openssl_check_quic)
  if(USE_OPENSSL)
    if(OPENSSL_VERSION VERSION_GREATER_EQUAL 3.5.0)
      if(NOT DEFINED HAVE_SSL_SET_QUIC_TLS_CBS)
        curl_openssl_check_exists("SSL_set_quic_tls_cbs" HAVE_SSL_SET_QUIC_TLS_CBS)
      endif()
    else()
      if(NOT DEFINED HAVE_SSL_SET_QUIC_USE_LEGACY_CODEPOINT)
        curl_openssl_check_exists("SSL_set_quic_use_legacy_codepoint" HAVE_SSL_SET_QUIC_USE_LEGACY_CODEPOINT)
      endif()
    endif()
  endif()
  if(USE_WOLFSSL AND NOT DEFINED HAVE_WOLFSSL_SET_QUIC_USE_LEGACY_CODEPOINT)
    curl_openssl_check_exists("wolfSSL_set_quic_use_legacy_codepoint" HAVE_WOLFSSL_SET_QUIC_USE_LEGACY_CODEPOINT)
  endif()
  if(NOT HAVE_SSL_SET_QUIC_TLS_CBS AND
     NOT HAVE_SSL_SET_QUIC_USE_LEGACY_CODEPOINT AND
     NOT HAVE_WOLFSSL_SET_QUIC_USE_LEGACY_CODEPOINT)
    message(FATAL_ERROR "QUICTLS API support is missing from OpenSSL/fork/wolfSSL. Try setting -DOPENSSL_ROOT_DIR")
  endif()
endmacro()

if(USE_WOLFSSL)
  curl_openssl_check_exists("wolfSSL_get_peer_certificate" HAVE_WOLFSSL_GET_PEER_CERTIFICATE)
  curl_openssl_check_exists("wolfSSL_UseALPN" HAVE_WOLFSSL_USEALPN)
  curl_openssl_check_exists("wolfSSL_BIO_new" HAVE_WOLFSSL_BIO_NEW)
  curl_openssl_check_exists("wolfSSL_BIO_set_shutdown" HAVE_WOLFSSL_BIO_SET_SHUTDOWN)
  curl_openssl_check_exists("wc_Des_EcbEncrypt" HAVE_WC_DES_ECBENCRYPT)
endif()

if(USE_OPENSSL)
  if(NOT DEFINED HAVE_DES_ECB_ENCRYPT)
    curl_openssl_check_exists("DES_ecb_encrypt" "openssl/des.h" HAVE_DES_ECB_ENCRYPT)
  endif()
  if(NOT DEFINED HAVE_SSL_SET0_WBIO)
    curl_openssl_check_exists("SSL_set0_wbio" HAVE_SSL_SET0_WBIO)
  endif()
endif()

option(USE_HTTPSRR "Enable HTTPS RR support (experimental)" OFF)
option(USE_ECH "Enable ECH support (experimental)" OFF)
if(USE_ECH)
  if(USE_OPENSSL OR USE_WOLFSSL OR USE_RUSTLS)
    # Be sure that the TLS library actually supports ECH.
    if(USE_WOLFSSL)
      curl_openssl_check_exists("wolfSSL_CTX_GenerateEchConfig" HAVE_WOLFSSL_CTX_GENERATEECHCONFIG)
    endif()
    if(USE_OPENSSL)
      curl_openssl_check_exists("SSL_set1_ech_config_list" HAVE_SSL_SET1_ECH_CONFIG_LIST)
    endif()
    if(HAVE_WOLFSSL_CTX_GENERATEECHCONFIG OR
       HAVE_SSL_SET1_ECH_CONFIG_LIST OR
       USE_RUSTLS)
      set(HAVE_ECH 1)
    endif()
    if(NOT HAVE_ECH)
      message(FATAL_ERROR "ECH support missing in AWS-LC/BoringSSL/OpenSSL/Rustls/wolfSSL")
    else()
      message(STATUS "ECH enabled")
      # ECH wants HTTPSRR
      set(USE_HTTPSRR ON)
      message(STATUS "HTTPSRR enabled")
    endif()
  else()
    message(FATAL_ERROR "ECH requires ECH-enabled AWS-LC, BoringSSL, OpenSSL, Rustls or wolfSSL")
  endif()
endif()

if(NOT CURL_DISABLE_HTTPSIG AND NOT USE_GNUTLS AND NOT USE_OPENSSL AND NOT USE_WOLFSSL)
  message(WARNING "HTTPSIG requires GnuTLS, OpenSSL or wolfSSL. HTTPSIG support disabled.")
  set(CURL_DISABLE_HTTPSIG ON)
endif()

option(USE_SSLS_EXPORT "Enable SSL session import/export (experimental)" OFF)
if(USE_SSLS_EXPORT)
  if(_ssl_enabled)
    message(STATUS "SSL export enabled.")
  else()
    message(WARNING "SSL session export requires SSL enabled")
  endif()
endif()

option(USE_PROXY_HTTP3 "Enable HTTP/3 proxy support (experimental)" OFF)

option(USE_NGHTTP2 "Use nghttp2 library" ON)
if(USE_NGHTTP2)
  find_package(NGHTTP2 MODULE)
  if(NGHTTP2_FOUND)
    list(APPEND CURL_LIBS CURL::nghttp2)
  else()
    set(USE_NGHTTP2 OFF)
  endif()
endif()

option(USE_NGTCP2 "Use ngtcp2 and nghttp3 libraries for HTTP/3 support" OFF)
if(USE_NGTCP2)
  if(CURL_WITH_MULTI_SSL)
    message(FATAL_ERROR "MultiSSL cannot be enabled with HTTP/3 and vice versa.")
  elseif(USE_OPENSSL OR USE_WOLFSSL)
    if(USE_WOLFSSL)
      find_package(NGTCP2 MODULE REQUIRED COMPONENTS "wolfSSL")
    elseif(HAVE_BORINGSSL OR HAVE_AWSLC)
      find_package(NGTCP2 MODULE REQUIRED COMPONENTS "BoringSSL")
    elseif(OPENSSL_VERSION VERSION_GREATER_EQUAL 3.5.0)
      find_package(NGTCP2 MODULE REQUIRED COMPONENTS "ossl")
      if(NGTCP2_VERSION VERSION_LESS 1.12.0)
        message(FATAL_ERROR "ngtcp2 1.12.0 or greater required for OpenSSL")
      endif()
      set(OPENSSL_QUIC_API2 1)
    elseif(HAVE_LIBRESSL)
      find_package(NGTCP2 MODULE COMPONENTS "LibreSSL")
      if(NOT NGTCP2_FOUND)
        find_package(NGTCP2 MODULE REQUIRED COMPONENTS "quictls")  # for ngtcp2 <1.15.0
      endif()
    else()
      find_package(NGTCP2 MODULE REQUIRED COMPONENTS "quictls")
      set(_openssl "quictls")
    endif()
    curl_openssl_check_quic()
  elseif(USE_GNUTLS)
    find_package(NGTCP2 MODULE REQUIRED "GnuTLS")
  else()
    message(FATAL_ERROR "ngtcp2 requires a supported TLS-backend")
  endif()
  list(APPEND CURL_LIBS CURL::ngtcp2)

  find_package(NGHTTP3 MODULE REQUIRED)
  set(USE_NGHTTP3 ON)
  list(APPEND CURL_LIBS CURL::nghttp3)
endif()

option(USE_QUICHE "Use quiche library for HTTP/3 support (experimental)" OFF)
if(USE_QUICHE)
  if(USE_NGTCP2)
    message(FATAL_ERROR "Only one HTTP/3 backend can be selected")
  elseif(CURL_WITH_MULTI_SSL)
    message(FATAL_ERROR "MultiSSL cannot be enabled with HTTP/3 and vice versa.")
  endif()
  find_package(Quiche MODULE REQUIRED)
  if(NOT HAVE_BORINGSSL)
    message(FATAL_ERROR "quiche requires BoringSSL")
  endif()
  curl_openssl_check_quic()
  list(APPEND CURL_LIBS CURL::quiche)
  if(NOT DEFINED HAVE_QUICHE_CONN_SET_QLOG_FD)
    cmake_push_check_state()
    list(APPEND CMAKE_REQUIRED_LIBRARIES CURL::quiche)
    check_symbol_exists("quiche_conn_set_qlog_fd" "quiche.h" HAVE_QUICHE_CONN_SET_QLOG_FD)
    cmake_pop_check_state()
  endif()
endif()

if(USE_PROXY_HTTP3)
  if(CURL_DISABLE_PROXY)
    message(FATAL_ERROR "USE_PROXY_HTTP3 requires proxy support")
  elseif(CURL_DISABLE_HTTP)
    message(FATAL_ERROR "USE_PROXY_HTTP3 requires HTTP support")
  elseif(NOT USE_NGTCP2 OR NOT USE_NGHTTP3)
    message(FATAL_ERROR "USE_PROXY_HTTP3 requires ngtcp2 + nghttp3")
  elseif(NOT USE_OPENSSL)
    message(FATAL_ERROR "USE_PROXY_HTTP3 currently requires OpenSSL")
  else()
    message(STATUS "HTTP/3 proxy support enabled (experimental)")
  endif()
endif()

if(NOT CURL_DISABLE_LDAP)
  if(WIN32 AND NOT WINDOWS_STORE)
    option(USE_WIN32_LDAP "Use Windows LDAP implementation" ON)
    if(USE_WIN32_LDAP)
      list(APPEND CURL_LIBS "wldap32")
      if(NOT CURL_DISABLE_LDAPS)
        set(HAVE_LDAP_SSL ON)
      endif()
    endif()
  endif()

  # Now that we know, we are not using Windows LDAP...
  if(NOT USE_WIN32_LDAP)
    # Check for LDAP
    cmake_push_check_state()
    if(USE_OPENSSL)
      list(APPEND CMAKE_REQUIRED_LIBRARIES OpenSSL::SSL OpenSSL::Crypto)
    endif()
    find_package(LDAP MODULE)
    if(LDAP_FOUND)
      set(HAVE_LBER_H 1)
      list(PREPEND CURL_LIBS CURL::ldap)

      # LDAP feature checks

      list(APPEND CMAKE_REQUIRED_DEFINITIONS "-DLDAP_DEPRECATED=1")
      list(APPEND CMAKE_REQUIRED_LIBRARIES CURL::ldap)

      check_function_exists("ldap_url_parse" HAVE_LDAP_URL_PARSE)
      check_function_exists("ldap_init_fd" HAVE_LDAP_INIT_FD)

      check_include_file("ldap_ssl.h" HAVE_LDAP_SSL_H)

      if(HAVE_LDAP_INIT_FD)
        set(USE_OPENLDAP ON)
      endif()
      if(NOT CURL_DISABLE_LDAPS)
        set(HAVE_LDAP_SSL ON)
      endif()
    else()
      message(STATUS "LDAP not found. CURL_DISABLE_LDAP set ON")
      set(CURL_DISABLE_LDAP ON CACHE BOOL "" FORCE)
    endif()
    cmake_pop_check_state()
  endif()
endif()

# No ldap, no ldaps.
if(CURL_DISABLE_LDAP)
  if(NOT CURL_DISABLE_LDAPS)
    message(STATUS "LDAP needs to be enabled to support LDAPS")
    set(CURL_DISABLE_LDAPS ON CACHE BOOL "" FORCE)
  endif()
endif()

if(WIN32)
  option(USE_WIN32_IDN "Use WinIDN for IDN support" OFF)
  if(USE_WIN32_IDN)
    list(APPEND CURL_LIBS "normaliz")  # for IdnToAscii(), IdnToUnicode()
  endif()
else()
  set(USE_WIN32_IDN OFF)
endif()

if(APPLE)
  option(USE_APPLE_IDN "Use Apple built-in IDN support" OFF)
  if(USE_APPLE_IDN)
    cmake_push_check_state()
    list(APPEND CMAKE_REQUIRED_LIBRARIES "icucore")
    check_symbol_exists("uidna_openUTS46" "unicode/uidna.h" HAVE_APPLE_IDN)
    cmake_pop_check_state()
    if(HAVE_APPLE_IDN)
      list(APPEND CURL_LIBS "icucore" "iconv")
    else()
      set(USE_APPLE_IDN OFF)
    endif()
  endif()
else()
  set(USE_APPLE_IDN OFF)
endif()

# Check for libidn2
option(USE_LIBIDN2 "Use libidn2 for IDN support" ON)
set(HAVE_IDN2_H OFF)
set(HAVE_LIBIDN2 OFF)
if(USE_LIBIDN2 AND NOT USE_APPLE_IDN AND NOT USE_WIN32_IDN)
  find_package(Libidn2 MODULE)
  if(LIBIDN2_FOUND)
    list(PREPEND CURL_LIBS CURL::libidn2)
    set(HAVE_IDN2_H 1)
    set(HAVE_LIBIDN2 1)
  endif()
endif()

# libpsl
option(CURL_USE_LIBPSL "Use libpsl" ON)
mark_as_advanced(CURL_USE_LIBPSL)
set(USE_LIBPSL OFF)
if(CURL_USE_LIBPSL)
  find_package(Libpsl MODULE REQUIRED)
  list(APPEND CURL_LIBS CURL::libpsl)
  set(USE_LIBPSL ON)
endif()

# libssh2
option(CURL_USE_LIBSSH2 "Use libssh2" ON)
mark_as_advanced(CURL_USE_LIBSSH2)
set(USE_LIBSSH2 OFF)
if(CURL_USE_LIBSSH2)
  find_package(Libssh2 MODULE)
  if(LIBSSH2_FOUND)
    list(PREPEND CURL_LIBS CURL::libssh2)  # keep it before TLS-crypto, compression
    set(USE_LIBSSH2 ON)
  endif()
endif()

# libssh
option(CURL_USE_LIBSSH "Use libssh" OFF)
mark_as_advanced(CURL_USE_LIBSSH)
if(NOT USE_LIBSSH2 AND CURL_USE_LIBSSH)
  find_package(Libssh MODULE REQUIRED)
  list(PREPEND CURL_LIBS CURL::libssh)  # keep it before TLS-crypto, compression
  set(USE_LIBSSH ON)
endif()

option(CURL_USE_GSASL "Use libgsasl" OFF)
mark_as_advanced(CURL_USE_GSASL)
if(CURL_USE_GSASL)
  find_package(Libgsasl MODULE REQUIRED)
  if(LIBGSASL_VERSION VERSION_LESS 1.6.0)
    message(FATAL_ERROR "libgsasl 1.6.0 or greater required")
  endif()
  list(APPEND CURL_LIBS CURL::libgsasl)
  set(USE_GSASL ON)
endif()

option(CURL_USE_GSSAPI "Use GSSAPI implementation" OFF)
mark_as_advanced(CURL_USE_GSSAPI)

if(CURL_USE_GSSAPI)
  set(CURL_GSS_FLAVOR "" CACHE STRING "Set preferred GSSAPI implementation ('Apple'). Default: MIT, then GNU (experimental)")

  find_package(GSS MODULE COMPONENTS "${CURL_GSS_FLAVOR}")

  set(HAVE_GSSAPI ${GSS_FOUND})
  if(GSS_FOUND)
    list(APPEND CURL_LIBS CURL::gss)

    get_target_property(GSS_FLAVOR CURL::gss INTERFACE_CURL_GSS_FLAVOR)
    if(GSS_FLAVOR STREQUAL "Apple")
      set(HAVE_GSSAPPLE 1)
    elseif(GSS_FLAVOR STREQUAL "GNU")
      set(HAVE_GSSGNU 1)
    elseif(GSS_VERSION)  # MIT
      set(CURL_KRB5_VERSION "\"${GSS_VERSION}\"")
    endif()

    cmake_push_check_state()
    list(APPEND CMAKE_REQUIRED_LIBRARIES CURL::gss)
    check_function_exists("gss_set_neg_mechs" HAVE_GSS_SET_NEG_MECHS)
    cmake_pop_check_state()
  else()
    message(WARNING "GSSAPI has been requested, but no supporting libraries found. Skipping.")
  endif()
endif()

# libbacktrace
option(CURL_USE_LIBBACKTRACE "Use libbacktrace. Requires debug-enabled build and DWARF debug information." OFF)
if(CURL_USE_LIBBACKTRACE)
  if(NOT ENABLE_DEBUG)
    message(FATAL_ERROR "libbacktrace requires debug-enabled build for TrackMemory")
  endif()
  if(NOT CMAKE_BUILD_TYPE MATCHES "(Debug|RelWithDebInfo)")
    message(FATAL_ERROR "libbacktrace requires debug information")
  endif()
  find_package(Libbacktrace MODULE REQUIRED)
  list(APPEND CURL_LIBS CURL::libbacktrace)
  set(USE_BACKTRACE ON)
endif()

# libuv
option(CURL_USE_LIBUV "Use libuv for event-based tests" OFF)
if(CURL_USE_LIBUV)
  if(NOT ENABLE_DEBUG)
    message(FATAL_ERROR "Using libuv without debug support enabled is useless")
  endif()
  find_package(Libuv MODULE REQUIRED)
  list(APPEND CURL_LIBS CURL::libuv)
  set(USE_LIBUV ON)
  set(HAVE_UV_H ON)
endif()

option(ENABLE_UNIX_SOCKETS "Enable Unix domain sockets support" ON)
if(ENABLE_UNIX_SOCKETS)
  if(WIN32 OR DOS)
    set(USE_UNIX_SOCKETS 1)
  else()
    include(CheckStructHasMember)
    check_struct_has_member("struct sockaddr_un" "sun_path" "sys/un.h" USE_UNIX_SOCKETS)
  endif()
else()
  set(USE_UNIX_SOCKETS 0)
  unset(USE_UNIX_SOCKETS CACHE)
endif()

#
# CA handling
#
option(CURL_CA_NATIVE "Use native CA store" OFF)
if(CURL_CA_NATIVE)
  set(_curl_disable_ca_search_default ON)
else()
  set(_curl_disable_ca_search_default OFF)
endif()

if(_curl_ca_bundle_supported)
  set(_ca_opt_desc "Set 'none' to disable or 'auto' for auto-detection. Defaults to 'auto'.")

  set(CURL_CA_BUNDLE "auto" CACHE
    STRING "Absolute path to the CA bundle. ${_ca_opt_desc}")
  set(CURL_CA_FALLBACK OFF CACHE
    BOOL "Use built-in CA store of OpenSSL. Defaults to OFF")
  set(CURL_CA_PATH "auto" CACHE
    STRING "Absolute path to a directory containing CA certificates stored individually. ${_ca_opt_desc}")
  set(CURL_CA_EMBED "" CACHE
    STRING "Absolute path to the CA bundle to embed in the curl tool.")

  if(CURL_CA_FALLBACK AND NOT CURL_USE_OPENSSL)
    message(FATAL_ERROR "CURL_CA_FALLBACK only works with OpenSSL.")
  endif()

  if(CURL_CA_BUNDLE STREQUAL "")
    message(FATAL_ERROR "Invalid value of CURL_CA_BUNDLE. Use 'none', 'auto' or file path.")
  elseif(CURL_CA_BUNDLE STREQUAL "none")
    unset(CURL_CA_BUNDLE CACHE)
  elseif(CURL_CA_BUNDLE STREQUAL "auto")
    unset(CURL_CA_BUNDLE CACHE)
    if(NOT CMAKE_CROSSCOMPILING AND NOT WIN32 AND NOT USE_APPLE_SECTRUST AND NOT CURL_CA_NATIVE)
      set(_curl_ca_bundle_autodetect TRUE)
    endif()
  else()
    set(CURL_CA_BUNDLE_SET TRUE)
  endif()
  mark_as_advanced(CURL_CA_BUNDLE_SET)

  if(CURL_CA_PATH STREQUAL "")
    message(FATAL_ERROR "Invalid value of CURL_CA_PATH. Use 'none', 'auto' or directory path.")
  elseif(CURL_CA_PATH STREQUAL "none")
    unset(CURL_CA_PATH CACHE)
  elseif(CURL_CA_PATH STREQUAL "auto")
    unset(CURL_CA_PATH CACHE)
    if(NOT CMAKE_CROSSCOMPILING AND NOT WIN32 AND NOT USE_APPLE_SECTRUST AND NOT CURL_CA_NATIVE)
      set(_curl_ca_path_autodetect TRUE)
    endif()
  else()
    set(CURL_CA_PATH_SET TRUE)
  endif()
  mark_as_advanced(CURL_CA_PATH_SET)

  if(CURL_CA_BUNDLE_SET AND _curl_ca_path_autodetect)
    # Skip auto-detection of unset CA path because CA bundle is set explicitly
  elseif(CURL_CA_PATH_SET AND _curl_ca_bundle_autodetect)
    # Skip auto-detection of unset CA bundle because CA path is set explicitly
  elseif(_curl_ca_bundle_autodetect OR _curl_ca_path_autodetect)
    # First try auto-detecting a CA bundle, then a CA path

    if(_curl_ca_bundle_autodetect)
      foreach(_search_ca_bundle_path IN ITEMS
          "/etc/ssl/certs/ca-certificates.crt"
          "/etc/pki/tls/certs/ca-bundle.crt"
          "/usr/share/ssl/certs/ca-bundle.crt"
          "/usr/local/share/certs/ca-root-nss.crt"
          "/etc/ssl/cert.pem")
        if(EXISTS "${_search_ca_bundle_path}")
          message(STATUS "Found CA bundle: ${_search_ca_bundle_path}")
          set(CURL_CA_BUNDLE "${_search_ca_bundle_path}" CACHE
            STRING "Absolute path to the CA bundle. ${_ca_opt_desc}")
          set(CURL_CA_BUNDLE_SET TRUE CACHE BOOL "Absolute path to the CA bundle has been set")
          break()
        endif()
      endforeach()
    endif()

    if(_curl_ca_path_autodetect AND NOT CURL_CA_PATH_SET)
      set(_search_ca_path "/etc/ssl/certs")
      file(GLOB _curl_ca_files_found "${_search_ca_path}/[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f].0")
      if(_curl_ca_files_found)
        unset(_curl_ca_files_found)
        message(STATUS "Found CA path: ${_search_ca_path}")
        set(CURL_CA_PATH "${_search_ca_path}" CACHE
          STRING "Absolute path to a directory containing CA certificates stored individually. ${_ca_opt_desc}")
        set(CURL_CA_PATH_SET TRUE CACHE BOOL "Absolute path to the CA bundle has been set")
      endif()
    endif()
  endif()

  set(CURL_CA_EMBED_SET FALSE)
  if(BUILD_CURL_EXE AND NOT CURL_CA_EMBED STREQUAL "")
    if(EXISTS "${CURL_CA_EMBED}")
      set(CURL_CA_EMBED_SET TRUE)
      message(STATUS "Found CA bundle to embed: ${CURL_CA_EMBED}")
    else()
      message(FATAL_ERROR "CA bundle to embed is missing: '${CURL_CA_EMBED}'")
    endif()
  endif()
endif()

if(WIN32)
  option(CURL_DISABLE_CA_SEARCH "Disable unsafe CA bundle search in PATH on Windows" ${_curl_disable_ca_search_default})
  option(CURL_CA_SEARCH_SAFE "Enable safe CA bundle search (within the curl tool directory) on Windows" OFF)
endif()

set(CURL_INCLUDES "")

# Check for header files
if(WIN32)
  list(APPEND CURL_INCLUDES "winsock2.h")
  list(APPEND CURL_INCLUDES "ws2tcpip.h")

  if(HAVE_WIN32_WINNT AND HAVE_WIN32_WINNT LESS 0x0600)
    # Windows Vista is required for freeaddrinfo, getaddrinfo, if_nametoindex
    message(FATAL_ERROR "Building for Windows Vista or newer is required.")
  endif()
endif()

if(NOT WIN32)
  list(APPEND CURL_INCLUDES "sys/socket.h")
endif()
if(NOT WIN32 OR MINGW)
  list(APPEND CURL_INCLUDES "sys/time.h")
endif()

# Detect headers

# Use check_include_file_concat_curl() for headers required by subsequent
# check_include_file_concat_curl() or check_symbol_exists() detections.
# Order for these is significant.
check_include_file("sys/eventfd.h"    HAVE_SYS_EVENTFD_H)
check_include_file("sys/filio.h"      HAVE_SYS_FILIO_H)
check_include_file("sys/ioctl.h"      HAVE_SYS_IOCTL_H)
check_include_file("sys/param.h"      HAVE_SYS_PARAM_H)
check_include_file("sys/poll.h"       HAVE_SYS_POLL_H)
check_include_file("sys/resource.h"   HAVE_SYS_RESOURCE_H)
check_include_file_concat_curl("sys/select.h"     HAVE_SYS_SELECT_H)
check_include_file("sys/sockio.h"     HAVE_SYS_SOCKIO_H)
check_include_file_concat_curl("sys/types.h"      HAVE_SYS_TYPES_H)
check_include_file("sys/un.h"         HAVE_SYS_UN_H)
check_include_file_concat_curl("sys/utime.h"      HAVE_SYS_UTIME_H)  # sys/types.h (AmigaOS)

check_include_file_concat_curl("arpa/inet.h"      HAVE_ARPA_INET_H)
check_include_file("fcntl.h"          HAVE_FCNTL_H)
check_include_file_concat_curl("ifaddrs.h"        HAVE_IFADDRS_H)
check_include_file("io.h"             HAVE_IO_H)
check_include_file_concat_curl("libgen.h"         HAVE_LIBGEN_H)
check_include_file("linux/tcp.h"      HAVE_LINUX_TCP_H)
check_include_file("locale.h"         HAVE_LOCALE_H)
check_include_file_concat_curl("net/if.h"         HAVE_NET_IF_H)  # sys/select.h (e.g. MS-DOS/Watt-32)
check_include_file_concat_curl("netdb.h"          HAVE_NETDB_H)
check_include_file_concat_curl("netinet/in.h"     HAVE_NETINET_IN_H)
check_include_file("netinet/in6.h"    HAVE_NETINET_IN6_H)
check_include_file("netinet/ip.h"     HAVE_NETINET_IP_H)
check_include_file_concat_curl("netinet/tcp.h"    HAVE_NETINET_TCP_H)  # sys/types.h (e.g. Cygwin) netinet/in.h
check_include_file_concat_curl("netinet/udp.h"    HAVE_NETINET_UDP_H)  # sys/types.h (e.g. Cygwin)
check_include_file("poll.h"           HAVE_POLL_H)
check_include_file("pwd.h"            HAVE_PWD_H)
check_include_file("stdatomic.h"      HAVE_STDATOMIC_H)
check_include_file("stdbool.h"        HAVE_STDBOOL_H)
check_include_file("strings.h"        HAVE_STRINGS_H)
check_include_file("stropts.h"        HAVE_STROPTS_H)
check_include_file("termio.h"         HAVE_TERMIO_H)
check_include_file("termios.h"        HAVE_TERMIOS_H)
check_include_file_concat_curl("unistd.h"         HAVE_UNISTD_H)
check_include_file("utime.h"          HAVE_UTIME_H)

if(AMIGA)
  check_include_file_concat_curl("proto/bsdsocket.h" HAVE_PROTO_BSDSOCKET_H)
endif()

# Pass these detection results to curl_internal_test() for use in CurlTests.c
# Add here all feature flags referenced from CurlTests.c
foreach(_variable IN ITEMS
    HAVE_STDATOMIC_H
    HAVE_STDBOOL_H
    HAVE_STROPTS_H
    HAVE_SYS_IOCTL_H
    HAVE_SYS_TYPES_H
    HAVE_UNISTD_H
)
  if(${_variable})
    list(APPEND CURL_TEST_DEFINES "-D${_variable}")
  endif()
endforeach()

check_type_size("size_t"      SIZEOF_SIZE_T)
check_type_size("ssize_t"     SIZEOF_SSIZE_T)
check_type_size("long"        SIZEOF_LONG)
check_type_size("int"         SIZEOF_INT)
check_type_size("__int64"     SIZEOF___INT64)
check_type_size("time_t"      SIZEOF_TIME_T)
check_type_size("suseconds_t" SIZEOF_SUSECONDS_T)
if(NOT HAVE_SIZEOF_SSIZE_T)
  if(SIZEOF_LONG EQUAL SIZEOF_SIZE_T)
    set(ssize_t "long")
  endif()
  if(NOT ssize_t AND SIZEOF___INT64 EQUAL SIZEOF_SIZE_T)
    set(ssize_t "__int64")
  endif()
endif()
# off_t is sized later, after the HAVE_FILE_OFFSET_BITS test

if(SIZEOF_SUSECONDS_T)
  set(HAVE_SUSECONDS_T 1)
endif()

# Check for some functions that are used

# Apply to all feature checks
if(WIN32)
  list(APPEND CMAKE_REQUIRED_LIBRARIES "ws2_32")
  if(NOT WINDOWS_STORE)
    list(APPEND CMAKE_REQUIRED_LIBRARIES "iphlpapi")
  endif()
elseif(HAVE_LIBSOCKET)
  list(APPEND CMAKE_REQUIRED_LIBRARIES "socket")
elseif(DOS)
  list(APPEND CMAKE_REQUIRED_LIBRARIES "${WATT_ROOT}/lib/libwatt.a")
endif()

check_function_exists("accept4"       HAVE_ACCEPT4)
check_function_exists("fnmatch"       HAVE_FNMATCH)
check_symbol_exists("basename"        "${CURL_INCLUDES};string.h" HAVE_BASENAME)  # libgen.h unistd.h
check_function_exists("poll"          HAVE_POLL)  # poll.h
check_symbol_exists("socket"          "${CURL_INCLUDES}" HAVE_SOCKET)  # winsock2.h sys/socket.h
check_symbol_exists("socketpair"      "${CURL_INCLUDES}" HAVE_SOCKETPAIR)  # sys/socket.h
check_symbol_exists("recv"            "${CURL_INCLUDES}" HAVE_RECV)  # proto/bsdsocket.h sys/types.h sys/socket.h
check_symbol_exists("send"            "${CURL_INCLUDES}" HAVE_SEND)  # proto/bsdsocket.h sys/types.h sys/socket.h
check_function_exists("sendmsg"       HAVE_SENDMSG)
check_function_exists("sendmmsg"      HAVE_SENDMMSG)
check_symbol_exists("memrchr"         "string.h" HAVE_MEMRCHR)
check_symbol_exists("alarm"           "unistd.h" HAVE_ALARM)
check_symbol_exists("fcntl"           "fcntl.h" HAVE_FCNTL)
check_function_exists("getppid"       HAVE_GETPPID)
check_function_exists("utimes"        HAVE_UTIMES)

check_symbol_exists("closesocket"     "${CURL_INCLUDES}" HAVE_CLOSESOCKET)  # winsock2.h
check_symbol_exists("sigsetjmp"       "setjmp.h" HAVE_SIGSETJMP)
check_function_exists("getpass_r"     HAVE_GETPASS_R)
check_function_exists("getpwuid"      HAVE_GETPWUID)
check_function_exists("getpwuid_r"    HAVE_GETPWUID_R)
check_function_exists("geteuid"       HAVE_GETEUID)
check_function_exists("utime"         HAVE_UTIME)
check_symbol_exists("gmtime_r"        "stdlib.h;time.h" HAVE_GMTIME_R)
check_symbol_exists("localtime_r"     "stdlib.h;time.h" HAVE_LOCALTIME_R)

check_symbol_exists("gethostbyname_r" "netdb.h" HAVE_GETHOSTBYNAME_R)
check_symbol_exists("gethostname"     "${CURL_INCLUDES}" HAVE_GETHOSTNAME)  # winsock2.h unistd.h proto/bsdsocket.h

check_symbol_exists("signal"          "signal.h" HAVE_SIGNAL)
check_symbol_exists("strerror_r"      "stdlib.h;string.h" HAVE_STRERROR_R)
check_symbol_exists("sigaction"       "signal.h" HAVE_SIGACTION)
check_symbol_exists("siginterrupt"    "signal.h" HAVE_SIGINTERRUPT)
check_symbol_exists("getaddrinfo"     "${CURL_INCLUDES};stdlib.h;string.h" HAVE_GETADDRINFO)  # ws2tcpip.h sys/socket.h netdb.h
check_symbol_exists("getifaddrs"      "${CURL_INCLUDES};stdlib.h" HAVE_GETIFADDRS)  # ifaddrs.h
check_symbol_exists("freeaddrinfo"    "${CURL_INCLUDES}" HAVE_FREEADDRINFO)  # ws2tcpip.h sys/socket.h netdb.h
check_function_exists("pipe"          HAVE_PIPE)
check_function_exists("eventfd"       HAVE_EVENTFD)
check_symbol_exists("getpeername"     "${CURL_INCLUDES}" HAVE_GETPEERNAME)  # winsock2.h unistd.h proto/bsdsocket.h
check_symbol_exists("getsockname"     "${CURL_INCLUDES}" HAVE_GETSOCKNAME)  # winsock2.h unistd.h proto/bsdsocket.h
check_function_exists("getrlimit"     HAVE_GETRLIMIT)
check_function_exists("setlocale"     HAVE_SETLOCALE)
check_function_exists("setrlimit"     HAVE_SETRLIMIT)

if(APPLE)
  check_function_exists("mach_absolute_time" HAVE_MACH_ABSOLUTE_TIME)
else()
  # Apple SDK <27 do not offer pipe2(), but the iPhone Simulator-specific
  # /usr/lib/system/libsystem_sim_kernel.dylib exports it. To avoid false
  # detection, omit this feature check for Apple targets.
  # For 27+, detection is done in-source.
  check_function_exists("pipe2"         HAVE_PIPE2)
endif()

if(NOT WIN32)
  check_include_file("dirent.h"         HAVE_DIRENT_H)

  check_function_exists("fchmod"          HAVE_FCHMOD)
  check_function_exists("gettimeofday"    HAVE_GETTIMEOFDAY)  # sys/time.h
  check_function_exists("if_nametoindex"  HAVE_IF_NAMETOINDEX)  # net/if.h
  check_function_exists("realpath"        HAVE_REALPATH)
  check_function_exists("sched_yield"     HAVE_SCHED_YIELD)

  check_symbol_exists("opendir"         "dirent.h" HAVE_OPENDIR)
  check_symbol_exists("strcasecmp"      "string.h" HAVE_STRCASECMP)
  check_symbol_exists("stricmp"         "string.h" HAVE_STRICMP)
  check_symbol_exists("strcmpi"         "string.h" HAVE_STRCMPI)

  check_symbol_exists("memset_s" "string.h" HAVE_MEMSET_S)
  if(NOT HAVE_MEMSET_S)
    check_function_exists("memset_explicit" HAVE_MEMSET_EXPLICIT)
  endif()
endif()

if(AMIGA)
  check_symbol_exists("CloseSocket" "${CURL_INCLUDES}" HAVE_CLOSESOCKET_CAMEL)  # sys/socket.h proto/bsdsocket.h
endif()

if(NOT _ssl_enabled)
  check_symbol_exists("arc4random" "${CURL_INCLUDES};stdlib.h" HAVE_ARC4RANDOM)
endif()

check_symbol_exists("fsetxattr" "sys/xattr.h" HAVE_FSETXATTR)
if(HAVE_FSETXATTR)
  curl_internal_test(HAVE_FSETXATTR_5)
  curl_internal_test(HAVE_FSETXATTR_6)
endif()

cmake_push_check_state()
if(NOT WIN32)
  list(APPEND CMAKE_EXTRA_INCLUDE_FILES "sys/socket.h")
  check_type_size("sa_family_t" SIZEOF_SA_FAMILY_T)
  set(HAVE_SA_FAMILY_T ${HAVE_SIZEOF_SA_FAMILY_T})
endif()
cmake_pop_check_state()

# Do curl specific tests
foreach(_curl_test IN ITEMS
    HAVE_FCNTL_O_NONBLOCK
    HAVE_IOCTLSOCKET
    HAVE_IOCTLSOCKET_CAMEL
    HAVE_IOCTLSOCKET_CAMEL_FIONBIO
    HAVE_IOCTLSOCKET_FIONBIO
    HAVE_IOCTL_FIONBIO
    HAVE_IOCTL_SIOCGIFADDR
    HAVE_SETSOCKOPT_SO_NONBLOCK
    HAVE_GETHOSTBYNAME_R_3
    HAVE_GETHOSTBYNAME_R_5
    HAVE_GETHOSTBYNAME_R_6
    HAVE_BOOL_T
    HAVE_ATOMIC
)
  curl_internal_test(${_curl_test})
endforeach()

# Check for reentrant
cmake_push_check_state()
list(APPEND CMAKE_REQUIRED_DEFINITIONS "-D_REENTRANT")
foreach(_curl_test IN ITEMS
    HAVE_GETHOSTBYNAME_R_3
    HAVE_GETHOSTBYNAME_R_5
    HAVE_GETHOSTBYNAME_R_6)
  curl_internal_test(${_curl_test}_REENTRANT)
  if(NOT ${_curl_test} AND ${_curl_test}_REENTRANT)
    set(NEED_REENTRANT 1)
  endif()
endforeach()
cmake_pop_check_state()

if(NEED_REENTRANT)
  foreach(_curl_test IN ITEMS
      HAVE_GETHOSTBYNAME_R_3
      HAVE_GETHOSTBYNAME_R_5
      HAVE_GETHOSTBYNAME_R_6)
    set(${_curl_test} 0)
    if(${_curl_test}_REENTRANT)
      set(${_curl_test} 1)
    endif()
  endforeach()
endif()

cmake_push_check_state()
list(APPEND CMAKE_REQUIRED_DEFINITIONS "-D_FILE_OFFSET_BITS=64")
curl_internal_test(HAVE_FILE_OFFSET_BITS)
cmake_pop_check_state()

cmake_push_check_state()
if(HAVE_FILE_OFFSET_BITS)
  set(_FILE_OFFSET_BITS 64)
  list(APPEND CMAKE_REQUIRED_DEFINITIONS "-D_FILE_OFFSET_BITS=64")
endif()
check_type_size("off_t" SIZEOF_OFF_T)

if(NOT WIN32)
  # fseeko may not exist with _FILE_OFFSET_BITS=64 but can exist with
  # _FILE_OFFSET_BITS unset or 32 (as in Android ARMv7 with NDK 26b and API level < 24)
  # so we need to test fseeko after testing for _FILE_OFFSET_BITS
  check_symbol_exists("fseeko" "${CURL_INCLUDES};stdio.h" HAVE_FSEEKO)

  if(HAVE_FSEEKO)
    set(HAVE_DECL_FSEEKO 1)
  endif()
endif()

# Include this header to get the type
cmake_push_check_state()
list(APPEND CMAKE_REQUIRED_INCLUDES "${PROJECT_SOURCE_DIR}/include")
list(APPEND CMAKE_EXTRA_INCLUDE_FILES "curl/system.h")
check_type_size("curl_off_t" SIZEOF_CURL_OFF_T)
list(APPEND CMAKE_EXTRA_INCLUDE_FILES "curl/curl.h")
check_type_size("curl_socket_t" SIZEOF_CURL_SOCKET_T)
cmake_pop_check_state()  # pop curl system headers
cmake_pop_check_state()  # pop -D_FILE_OFFSET_BITS=64

if(NOT WIN32 AND NOT CMAKE_CROSSCOMPILING)
  # On non-Windows and not cross-compiling, check for writable argv[]
  include(CheckCSourceRuns)
  check_c_source_runs("
    int main(int argc, char *argv[])
    {
      (void)argc;
      argv[0][0] = ' ';
      return (argv[0][0] == ' ') ? 0 : 1;
    }" HAVE_WRITABLE_ARGV)
endif()

curl_internal_test(HAVE_TIME_T_UNSIGNED)

curl_internal_test(HAVE_GLIBC_STRERROR_R)
curl_internal_test(HAVE_POSIX_STRERROR_R)

if(NOT WIN32)
  curl_internal_test(HAVE_CLOCK_GETTIME_MONOTONIC)  # Check clock_gettime(CLOCK_MONOTONIC, x) support
endif()

if(APPLE)
  curl_internal_test(HAVE_BUILTIN_AVAILABLE)  # Check compiler support of __builtin_available()
endif()

# Some other minor tests

if(_cmake_try_compile_target_type_save)
  set(CMAKE_TRY_COMPILE_TARGET_TYPE ${_cmake_try_compile_target_type_save})
  unset(_cmake_try_compile_target_type_save)
endif()

include(CMake/OtherTests.cmake)

set_property(DIRECTORY APPEND PROPERTY COMPILE_DEFINITIONS "HAVE_CONFIG_H")

if(WIN32)
  list(APPEND CURL_NETWORK_AND_TIME_LIBS "ws2_32")
  if(NOT WINDOWS_STORE)
    list(APPEND CURL_NETWORK_AND_TIME_LIBS "iphlpapi")  # for if_nametoindex()
  endif()
  list(APPEND CURL_LIBS "bcrypt")  # for BCryptGenRandom()

  # We use crypto functions that are not available for UWP apps
  if(NOT WINDOWS_STORE)
    set(USE_WIN32_CRYPTO ON)
  endif()

  # Link required libraries for USE_WIN32_CRYPTO or USE_SCHANNEL
  if(USE_WIN32_CRYPTO OR USE_SCHANNEL)
    # for CryptAcquireContext(), CryptCreateHash(), CryptDestroyHash(), CryptGetHashParam(), CryptHashData(),
    #     CryptReleaseContext() in NTLM, md4, md5, sha256, Schannel
    # for CryptDestroyKey(), CryptEncrypt(), CryptImportKey() in NTLM
    list(APPEND CURL_LIBS "advapi32")
    # for Cert*() in openssl.c Native CA, Schannel
    # for CryptDecodeObjectEx(), CryptQueryObject(), CryptStringToBinary(), PFXImportCertStore() in Schannel
    list(APPEND CURL_LIBS "crypt32")
  endif()
  if(USE_WINDOWS_SSPI)
    list(APPEND CURL_LIBS "secur32")  # for InitSecurityInterface()
  endif()
endif()

list(APPEND CURL_LIBS ${CURL_NETWORK_AND_TIME_LIBS})
if(CURL_CODE_COVERAGE)
  list(APPEND CURL_LIBS ${CURL_COVERAGE_LIBS})
endif()

# Hack to add some libraries to the end of the library list to make binutils ld
# for GCC find symbols when linking statically. Necessary for libs detected via
# CMake's built-in find modules, which CMake adds to the beginning of the lib
# list on the linker command-line for some reason. This makes them appear
# before dependencies detected via curl's custom Find modules, and breaks
# linkers sensitive to lib order. There must be a better solution to this.
# Enable the workaround for all compilers, to make it available when using GCC
# to consume libcurl, regardless of the compiler used to build libcurl itself.
if(CMAKE_C_COMPILER_ID STREQUAL "GNU")
  if(USE_OPENSSL AND TARGET OpenSSL::Crypto)
    add_library(CURL::OpenSSL_Crypto INTERFACE IMPORTED)
    set_target_properties(CURL::OpenSSL_Crypto PROPERTIES INTERFACE_LINK_LIBRARIES OpenSSL::Crypto)
    list(APPEND CURL_LIBS CURL::OpenSSL_Crypto)
  endif()
  if(HAVE_LIBZ AND TARGET ZLIB::ZLIB)
    add_library(CURL::ZLIB INTERFACE IMPORTED)
    set_target_properties(CURL::ZLIB PROPERTIES INTERFACE_LINK_LIBRARIES ZLIB::ZLIB)
    list(APPEND CURL_LIBS CURL::ZLIB)
  endif()
  if(WIN32)
    add_library(CURL::win32_winsock INTERFACE IMPORTED)
    set_target_properties(CURL::win32_winsock PROPERTIES INTERFACE_LINK_LIBRARIES "ws2_32")
    list(APPEND CURL_LIBS CURL::win32_winsock)
  endif()
endif()

if(CMAKE_C_COMPILER_ID STREQUAL "MSVC")  # MSVC but exclude clang-cl
  set_property(DIRECTORY APPEND PROPERTY COMPILE_OPTIONS "-MP")  # Parallel compilation
endif()

if(CURL_LTO)
  include(CheckIPOSupported)
  check_ipo_supported(RESULT CURL_HAS_LTO OUTPUT _lto_error LANGUAGES C)
  if(CURL_HAS_LTO)
    message(STATUS "LTO supported and enabled")
  else()
    message(FATAL_ERROR "LTO has been requested, but the compiler does not support it\n${_lto_error}")
  endif()
endif()

# Ugly (but functional) way to include "Makefile.inc" by transforming it
# (= regenerate it).
function(curl_transform_makefile_inc _input_file _output_file)
  file(READ ${_input_file} _makefile_inc_text)
  string(REPLACE "$(top_srcdir)"   "\${PROJECT_SOURCE_DIR}" _makefile_inc_text ${_makefile_inc_text})  # cmake-lint: disable=W0106
  string(REPLACE "$(top_builddir)" "\${PROJECT_BINARY_DIR}" _makefile_inc_text ${_makefile_inc_text})  # cmake-lint: disable=W0106

  string(REGEX REPLACE "\\\\\n" "!^!^!" _makefile_inc_text ${_makefile_inc_text})
  string(REGEX REPLACE "([a-zA-Z_][a-zA-Z0-9_]*)[\t ]*=[\t ]*([^\n]*)" "set(\\1 \\2)" _makefile_inc_text ${_makefile_inc_text})
  string(REPLACE "!^!^!" "\n" _makefile_inc_text ${_makefile_inc_text})

  # Replace $() with ${}
  string(REGEX REPLACE "\\$\\(([a-zA-Z_][a-zA-Z0-9_]*)\\)" "\${\\1}" _makefile_inc_text ${_makefile_inc_text})
  # Replace @@ with ${}, even if that may not be read by CMake scripts.
  string(REGEX REPLACE "@([a-zA-Z_][a-zA-Z0-9_]*)@" "\${\\1}" _makefile_inc_text ${_makefile_inc_text})

  file(WRITE ${_output_file} ${_makefile_inc_text})
  set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${_input_file}")
endfunction()

include(GNUInstallDirs)

set(_install_cmake_dir "${CMAKE_INSTALL_LIBDIR}/cmake/${PROJECT_NAME}")
set(TARGETS_EXPORT_NAME "${PROJECT_NAME}Targets")
set(_project_config "${PROJECT_BINARY_DIR}/${PROJECT_NAME}Config.cmake")
set(_version_config "${PROJECT_BINARY_DIR}/${PROJECT_NAME}ConfigVersion.cmake")

option(BUILD_TESTING "Build tests" ON)
if(BUILD_TESTING AND Perl_FOUND)
  set(CURL_BUILD_TESTING ON)
else()
  set(CURL_BUILD_TESTING OFF)
endif()

if(Perl_FOUND)
  set(CURL_MANPAGE "${PROJECT_BINARY_DIR}/docs/cmdline-opts/curl.1")
  set(CURL_ASCIIPAGE "${PROJECT_BINARY_DIR}/docs/cmdline-opts/curl.txt")
  add_subdirectory(docs)
endif()

add_subdirectory(scripts)  # for shell completions

add_subdirectory(lib)

if(BUILD_CURL_EXE)
  add_subdirectory(src)
endif()

option(BUILD_EXAMPLES "Build libcurl examples" ON)
if(BUILD_EXAMPLES)
  add_subdirectory(docs/examples)
endif()

if(CURL_BUILD_TESTING)
  add_subdirectory(tests)
endif()

# Helper to populate a list (_items) with a label when conditions
# (the remaining args) are satisfied
macro(curl_add_if _label)
  # Needs to be a macro to allow this indirection
  if(${ARGN})
    list(APPEND _items "${_label}")
  endif()
endmacro()

# NTLM support requires crypto functions from various SSL libs.
# These conditions must match those in lib/curl_setup.h.
if(CURL_ENABLE_NTLM AND
   ((USE_OPENSSL AND HAVE_DES_ECB_ENCRYPT) OR
    (USE_MBEDTLS AND HAVE_MBEDTLS_DES_CRYPT_ECB) OR
    USE_GNUTLS OR
    USE_WIN32_CRYPTO OR
    (USE_WOLFSSL AND HAVE_WC_DES_ECBENCRYPT)))
  set(_use_curl_ntlm_core ON)
endif()

# Clear list and try to detect available protocols
set(_items "")
curl_add_if("HTTP"          NOT CURL_DISABLE_HTTP)
curl_add_if("HTTPS"         NOT CURL_DISABLE_HTTP AND _ssl_enabled)
curl_add_if("FTP"           NOT CURL_DISABLE_FTP)
curl_add_if("FTPS"          NOT CURL_DISABLE_FTP AND _ssl_enabled)
curl_add_if("FILE"          NOT CURL_DISABLE_FILE)
curl_add_if("TELNET"        NOT CURL_DISABLE_TELNET)
curl_add_if("LDAP"          NOT CURL_DISABLE_LDAP)
# CURL_DISABLE_LDAP implies CURL_DISABLE_LDAPS
curl_add_if("LDAPS"         NOT CURL_DISABLE_LDAPS AND
                            ((USE_OPENLDAP AND _ssl_enabled) OR
                            (NOT USE_OPENLDAP AND HAVE_LDAP_SSL)))
curl_add_if("DICT"          NOT CURL_DISABLE_DICT)
curl_add_if("TFTP"          NOT CURL_DISABLE_TFTP)
curl_add_if("GOPHER"        NOT CURL_DISABLE_GOPHER)
curl_add_if("GOPHERS"       NOT CURL_DISABLE_GOPHER AND _ssl_enabled)
curl_add_if("POP3"          NOT CURL_DISABLE_POP3)
curl_add_if("POP3S"         NOT CURL_DISABLE_POP3 AND _ssl_enabled)
curl_add_if("IMAP"          NOT CURL_DISABLE_IMAP)
curl_add_if("IMAPS"         NOT CURL_DISABLE_IMAP AND _ssl_enabled)
curl_add_if("SMTP"          NOT CURL_DISABLE_SMTP)
curl_add_if("SMTPS"         NOT CURL_DISABLE_SMTP AND _ssl_enabled)
curl_add_if("SCP"           USE_LIBSSH2 OR USE_LIBSSH)
curl_add_if("SFTP"          USE_LIBSSH2 OR USE_LIBSSH)
curl_add_if("IPFS"          NOT CURL_DISABLE_IPFS)
curl_add_if("IPNS"          NOT CURL_DISABLE_IPFS)
curl_add_if("RTSP"          NOT CURL_DISABLE_RTSP)
curl_add_if("MQTT"          NOT CURL_DISABLE_MQTT)
curl_add_if("MQTTS"         NOT CURL_DISABLE_MQTT AND _ssl_enabled)
curl_add_if("WS"            NOT CURL_DISABLE_WEBSOCKETS)
curl_add_if("WSS"           NOT CURL_DISABLE_WEBSOCKETS AND _ssl_enabled)
if(_items)
  list(SORT _items)
endif()
set(CURL_SUPPORTED_PROTOCOLS_LIST "${_items}")
string(REPLACE ";" " " SUPPORT_PROTOCOLS "${_items}")
string(TOLOWER "${SUPPORT_PROTOCOLS}" _support_protocols_lower)
message(STATUS "Protocols: ${_support_protocols_lower}")

# Clear list and try to detect available features
set(_items "")
curl_add_if("SSL"           _ssl_enabled)
curl_add_if("IPv6"          USE_IPV6)
curl_add_if("UnixSockets"   USE_UNIX_SOCKETS)
curl_add_if("libz"          HAVE_LIBZ)
curl_add_if("brotli"        HAVE_BROTLI)
curl_add_if("gsasl"         USE_GSASL)
curl_add_if("zstd"          HAVE_ZSTD)
curl_add_if("AsynchDNS"     USE_RESOLV_ARES OR USE_RESOLV_THREADED)
curl_add_if("asyn-rr"       USE_ARES AND USE_RESOLV_THREADED AND USE_HTTPSRR)
curl_add_if("IDN"           (HAVE_LIBIDN2 AND HAVE_IDN2_H) OR
                            USE_WIN32_IDN OR
                            USE_APPLE_IDN)
curl_add_if("Largefile"     (SIZEOF_CURL_OFF_T GREATER 4) AND ((SIZEOF_OFF_T GREATER 4) OR WIN32))
curl_add_if("SSPI"          USE_WINDOWS_SSPI)
curl_add_if("GSS-API"       HAVE_GSSAPI)
curl_add_if("alt-svc"       NOT CURL_DISABLE_ALTSVC)
curl_add_if("HSTS"          NOT CURL_DISABLE_HSTS)
curl_add_if("HTTPSIG"       NOT CURL_DISABLE_HTTPSIG)
curl_add_if("SPNEGO"        NOT CURL_DISABLE_NEGOTIATE_AUTH AND
                            (HAVE_GSSAPI OR USE_WINDOWS_SSPI))
curl_add_if("Kerberos"      NOT CURL_DISABLE_KERBEROS_AUTH AND
                            (HAVE_GSSAPI OR USE_WINDOWS_SSPI))
curl_add_if("NTLM"          CURL_ENABLE_NTLM AND
                            (_use_curl_ntlm_core OR USE_WINDOWS_SSPI))
curl_add_if("HTTP2"         USE_NGHTTP2)
curl_add_if("HTTP3"         USE_NGTCP2 OR USE_QUICHE)
curl_add_if("proxy-HTTP3"   USE_PROXY_HTTP3)
curl_add_if("MultiSSL"      CURL_WITH_MULTI_SSL)
curl_add_if("HTTPS-proxy"   NOT CURL_DISABLE_PROXY AND _ssl_enabled AND (USE_OPENSSL OR USE_GNUTLS
                            OR USE_SCHANNEL OR USE_RUSTLS OR USE_MBEDTLS OR
                            (USE_WOLFSSL AND HAVE_WOLFSSL_BIO_NEW)))
curl_add_if("Unicode"       ENABLE_UNICODE)
curl_add_if("threadsafe"    HAVE_ATOMIC OR HAVE_THREADS_POSIX OR WIN32)
curl_add_if("Debug"         ENABLE_DEBUG)
curl_add_if("ECH"           _ssl_enabled AND HAVE_ECH)
curl_add_if("HTTPSRR"       _ssl_enabled AND USE_HTTPSRR)
curl_add_if("PSL"           USE_LIBPSL)
curl_add_if("CAcert"        CURL_CA_EMBED_SET)
curl_add_if("SSLS-EXPORT"   _ssl_enabled AND USE_SSLS_EXPORT)
curl_add_if("AppleSecTrust" USE_APPLE_SECTRUST AND _ssl_enabled AND (USE_OPENSSL OR USE_GNUTLS))
curl_add_if("NativeCA"      NOT USE_APPLE_SECTRUST AND _ssl_enabled AND CURL_CA_NATIVE)
if(_items)
  list(SORT _items CASE INSENSITIVE)
endif()
set(CURL_SUPPORTED_FEATURES_LIST "${_items}")
string(REPLACE ";" " " SUPPORT_FEATURES "${_items}")
message(STATUS "Features: ${SUPPORT_FEATURES}")

# Clear list and collect SSL backends
set(_items "")
curl_add_if("Schannel"      _ssl_enabled AND USE_SCHANNEL)
curl_add_if("${_openssl}"   _ssl_enabled AND USE_OPENSSL)
curl_add_if("mbedTLS"       _ssl_enabled AND USE_MBEDTLS)
curl_add_if("wolfSSL"       _ssl_enabled AND USE_WOLFSSL)
curl_add_if("GnuTLS"        _ssl_enabled AND USE_GNUTLS)
curl_add_if("Rustls"        _ssl_enabled AND USE_RUSTLS)

if(_items)
  list(SORT _items CASE INSENSITIVE)
endif()
string(REPLACE ";" " " SSL_BACKENDS "${_items}")
message(STATUS "Enabled SSL backends: ${SSL_BACKENDS}")
if(CURL_DEFAULT_SSL_BACKEND)
  message(STATUS "Default SSL backend: ${CURL_DEFAULT_SSL_BACKEND}")
endif()

if(NOT CURL_DISABLE_INSTALL)

  # curl-config needs the following options to be set.
  set(CC                      "${CMAKE_C_COMPILER}")
  set(CONFIGURE_OPTIONS       "")
  set(CURLVERSION             "${_curl_version}")
  set(VERSIONNUM              "${_curl_version_num}")
  set(prefix                  "${CMAKE_INSTALL_PREFIX}")
  set(exec_prefix             "\${prefix}")
  if(IS_ABSOLUTE ${CMAKE_INSTALL_INCLUDEDIR})
    set(includedir            "${CMAKE_INSTALL_INCLUDEDIR}")
  else()
    set(includedir            "\${prefix}/${CMAKE_INSTALL_INCLUDEDIR}")
  endif()
  if(IS_ABSOLUTE ${CMAKE_INSTALL_LIBDIR})
    set(libdir                "${CMAKE_INSTALL_LIBDIR}")
  else()
    set(libdir                "\${exec_prefix}/${CMAKE_INSTALL_LIBDIR}")
  endif()
  # "a" (Linux) or "lib" (Windows)
  string(REPLACE "." "" libext "${CMAKE_STATIC_LIBRARY_SUFFIX}")

  set(_ldflags "")
  set(LIBCURL_PC_LIBS_PRIVATE "")

  # Filter CMAKE_SHARED_LINKER_FLAGS for libs and libpaths
  string(STRIP "${CMAKE_SHARED_LINKER_FLAGS}" _custom_ldflags)
  string(REGEX REPLACE " +-([^ \\t;]*)" ";-\\1" _custom_ldflags "${_custom_ldflags}")

  set(_custom_libs "")
  set(_custom_libdirs "")
  foreach(_flag IN LISTS _custom_ldflags)
    if(_flag MATCHES "^-l")
      string(REGEX REPLACE "^-l" "" _flag "${_flag}")
      list(APPEND _custom_libs "${_flag}")
    elseif(_flag MATCHES "^-framework|^-F")
      list(APPEND _custom_libs "${_flag}")
    elseif(_flag MATCHES "^-L")
      string(REGEX REPLACE "^-L" "" _flag "${_flag}")
      list(APPEND _custom_libdirs "${_flag}")
    elseif(_flag MATCHES "^--library-path=")
      string(REGEX REPLACE "^--library-path=" "" _flag "${_flag}")
      list(APPEND _custom_libdirs "${_flag}")
    endif()
  endforeach()

  # Avoid getting unnecessary -L options for known system directories.
  set(_sys_libdirs "${CMAKE_C_IMPLICIT_LINK_DIRECTORIES}")
  foreach(_libdir IN LISTS CMAKE_SYSTEM_PREFIX_PATH)
    if(_libdir MATCHES "/$")
      string(APPEND _libdir "lib")
    else()
      string(APPEND _libdir "/lib")
    endif()
    if(IS_DIRECTORY "${_libdir}")
      list(APPEND _sys_libdirs "${_libdir}")
    endif()
    if(DEFINED CMAKE_LIBRARY_ARCHITECTURE)
      string(APPEND _libdir "/${CMAKE_LIBRARY_ARCHITECTURE}")
      if(IS_DIRECTORY "${_libdir}")
        list(APPEND _sys_libdirs "${_libdir}")
      endif()
    endif()
  endforeach()

  set(_implicit_libs "")
  if(NOT MINGW AND NOT UNIX)
    set(_implicit_libs "${CMAKE_C_IMPLICIT_LINK_LIBRARIES}")
  endif()

  set(_explicit_libdirs "")
  set(LIBCURL_PC_REQUIRES_PRIVATE "")
  set(LIBCURL_PC_LIBS_PRIVATE_LIST "")
  foreach(_lib IN LISTS CURL_LIBS _custom_libs _implicit_libs)
    if(TARGET "${_lib}")
      set(_explicit_libs "")
      get_target_property(_imported "${_lib}" IMPORTED)
      if(NOT _imported)
        # Reading the LOCATION property on non-imported target errors out.
        # Assume the user does not need this information in the .pc file.
        continue()
      endif()
      set(_libdirs "")
      set(_libs "")
      curl_collect_target_link_options("${_lib}")  # look into the target recursively
      list(APPEND _explicit_libdirs ${_libdirs})
      list(APPEND _explicit_libs ${_libs})
      if(NOT _libs AND NOT _libdirs AND NOT _lib STREQUAL Threads::Threads)
        message(WARNING "Bad lib in library list: ${_lib}")
      endif()
      if(_lib STREQUAL OpenSSL::SSL AND NOT HAVE_BORINGSSL)  # BoringSSL does not provide openssl.pc
        set(_modules "openssl")
      elseif(_lib STREQUAL ZLIB::ZLIB AND NOT ANDROID)  # Android does not provide zlib.pc
        set(_modules "zlib")
      else()
        get_target_property(_modules "${_lib}" INTERFACE_LIBCURL_PC_MODULES)
      endif()
      if(_modules)
        list(APPEND LIBCURL_PC_REQUIRES_PRIVATE "${_modules}")
      endif()

      foreach(_lib IN LISTS _explicit_libs)
        if(_lib MATCHES "/")
          # This gets a bit more complex, because we want to specify the
          # directory separately, and only once per directory
          if(CMAKE_VERSION VERSION_GREATER_EQUAL 3.20)
            cmake_path(GET _lib PARENT_PATH _libdir)
            cmake_path(GET _lib STEM _libname)
          else()
            get_filename_component(_libdir "${_lib}" DIRECTORY)
            get_filename_component(_libname "${_lib}" NAME_WE)
          endif()
          if(_libname MATCHES "^lib")
            if(CMAKE_VERSION VERSION_GREATER_EQUAL 3.20)
              cmake_path(SET _libdir NORMALIZE "${_libdir}")
            endif()
            if(NOT _libdir IN_LIST _sys_libdirs)
              list(APPEND _ldflags "-L${_libdir}")
            endif()
            string(REGEX REPLACE "^lib" "" _libname "${_libname}")
            list(APPEND LIBCURL_PC_LIBS_PRIVATE "-l${_libname}")
            list(APPEND LIBCURL_PC_LIBS_PRIVATE_LIST "${_lib}")
          else()
            list(APPEND LIBCURL_PC_LIBS_PRIVATE "${_lib}")
            list(APPEND LIBCURL_PC_LIBS_PRIVATE_LIST "${_lib}")
          endif()
        elseif(_lib MATCHES "^-")  # '-option'
          list(APPEND _ldflags "${_lib}")
          list(APPEND LIBCURL_PC_LIBS_PRIVATE_LIST "${_lib}")
        else()
          list(APPEND LIBCURL_PC_LIBS_PRIVATE "-l${_lib}")
          list(APPEND LIBCURL_PC_LIBS_PRIVATE_LIST "${_lib}")
        endif()
      endforeach()
    elseif(_lib MATCHES "^-")  # '-framework <name>'
      list(APPEND _ldflags "${_lib}")
      list(APPEND LIBCURL_PC_LIBS_PRIVATE_LIST "${_lib}")
    else()
      list(APPEND LIBCURL_PC_LIBS_PRIVATE "-l${_lib}")
      list(APPEND LIBCURL_PC_LIBS_PRIVATE_LIST "${_lib}")
    endif()
  endforeach()

  foreach(_libdir IN LISTS _custom_libdirs _explicit_libdirs)
    if(CMAKE_VERSION VERSION_GREATER_EQUAL 3.20)
      cmake_path(SET _libdir NORMALIZE "${_libdir}")
    endif()
    if(NOT _libdir IN_LIST _sys_libdirs)
      list(APPEND _ldflags "-L${_libdir}")
    endif()
  endforeach()

  list(REMOVE_DUPLICATES _ldflags)

  if(LIBCURL_PC_REQUIRES_PRIVATE)
    list(REMOVE_DUPLICATES LIBCURL_PC_REQUIRES_PRIVATE)
    string(REPLACE ";" "," LIBCURL_PC_REQUIRES_PRIVATE "${LIBCURL_PC_REQUIRES_PRIVATE}")
  endif()
  if(LIBCURL_PC_LIBS_PRIVATE)
    # Remove duplicates listed next to each other
    set(_libs "")
    set(_prev "")
    foreach(_lib IN LISTS LIBCURL_PC_LIBS_PRIVATE)
      if(NOT _prev STREQUAL _lib)
        list(APPEND _libs "${_lib}")
        set(_prev "${_lib}")
      endif()
    endforeach()
    set(LIBCURL_PC_LIBS_PRIVATE "${_libs}")

    string(REPLACE ";" " " LIBCURL_PC_LIBS_PRIVATE "${LIBCURL_PC_LIBS_PRIVATE}")
  endif()
  if(_ldflags)
    list(REMOVE_DUPLICATES _ldflags)
    string(REPLACE ";" " " _ldflags "${_ldflags}")
    set(LIBCURL_PC_LDFLAGS_PRIVATE "${_ldflags}")
    string(STRIP "${LIBCURL_PC_LDFLAGS_PRIVATE}" LIBCURL_PC_LDFLAGS_PRIVATE)
  else()
    set(LIBCURL_PC_LDFLAGS_PRIVATE "")
  endif()
  set(LIBCURL_PC_CFLAGS_PRIVATE "-DCURL_STATICLIB")

  # Merge pkg-config private fields into public ones when static-only
  if(BUILD_SHARED_LIBS)
    set(ENABLE_SHARED       "yes")
    set(LIBCURL_PC_REQUIRES "")
    set(LIBCURL_PC_LIBS     "")
    set(LIBCURL_PC_CFLAGS   "")
  else()
    set(ENABLE_SHARED       "no")
    set(LIBCURL_PC_REQUIRES "${LIBCURL_PC_REQUIRES_PRIVATE}")
    set(LIBCURL_PC_LIBS     "${LIBCURL_PC_LIBS_PRIVATE}")
    set(LIBCURL_PC_CFLAGS   "${LIBCURL_PC_CFLAGS_PRIVATE}")
    set(LIBCURL_PC_REQUIRES_PRIVATE "")
  endif()
  if(BUILD_STATIC_LIBS)
    set(ENABLE_STATIC       "yes")
  else()
    set(ENABLE_STATIC       "no")
  endif()

  # Generate a "curl-config" matching this config.
  # Consumed variables:
  #   CC
  #   CONFIGURE_OPTIONS
  #   CURLVERSION
  #   CURL_CA_BUNDLE
  #   ENABLE_SHARED
  #   ENABLE_STATIC
  #   exec_prefix
  #   includedir
  #   LIBCURL_PC_CFLAGS
  #   LIBCURL_PC_LDFLAGS_PRIVATE
  #   LIBCURL_PC_LIBS_PRIVATE
  #   libdir
  #   libext
  #   prefix
  #   SSL_BACKENDS
  #   SUPPORT_FEATURES
  #   SUPPORT_PROTOCOLS
  #   VERSIONNUM
  configure_file(
    "${PROJECT_SOURCE_DIR}/curl-config.in"
    "${PROJECT_BINARY_DIR}/curl-config" @ONLY)
  install(FILES "${PROJECT_BINARY_DIR}/curl-config"
    DESTINATION ${CMAKE_INSTALL_BINDIR}
    PERMISSIONS
      OWNER_READ OWNER_WRITE OWNER_EXECUTE
      GROUP_READ GROUP_EXECUTE
      WORLD_READ WORLD_EXECUTE)

  # Generate a pkg-config file matching this config.
  # Consumed variables:
  #   CURL_PACKAGE_MAINTAINER
  #   CURLVERSION
  #   exec_prefix
  #   includedir
  #   LIBCURL_PC_CFLAGS
  #   LIBCURL_PC_CFLAGS_PRIVATE
  #   LIBCURL_PC_LDFLAGS_PRIVATE
  #   LIBCURL_PC_LIBS
  #   LIBCURL_PC_LIBS_PRIVATE
  #   LIBCURL_PC_REQUIRES
  #   LIBCURL_PC_REQUIRES_PRIVATE
  #   libdir
  #   prefix
  #   SUPPORT_FEATURES
  #   SUPPORT_PROTOCOLS
  # Documentation:
  #   https://people.freedesktop.org/~dbn/pkg-config-guide.html
  #   https://manpages.debian.org/unstable/pkgconf/pkg-config.1.en.html
  #   https://manpages.debian.org/unstable/pkg-config/pkg-config.1.en.html
  #   https://www.msys2.org/docs/pkgconfig/
  if(NOT "$ENV{CURL_CI}" STREQUAL "")
    set(CURL_PACKAGE_MAINTAINER "https://curl.se/")
  endif()
  configure_file(
    "${PROJECT_SOURCE_DIR}/libcurl.pc.in"
    "${PROJECT_BINARY_DIR}/libcurl.pc" @ONLY)
  # Strip trailing spaces, duplicate spaces after colon, empty properties
  file(READ "${PROJECT_BINARY_DIR}/libcurl.pc" _libcurl_pc)
  string(REGEX REPLACE " +\n" "\n" _libcurl_pc "${_libcurl_pc}")
  string(REGEX REPLACE "\nLibs\.private: +" "\nLibs.private: " _libcurl_pc "${_libcurl_pc}")
  string(REGEX REPLACE "\n([A-Za-z.]+:\n)+" "\n" _libcurl_pc "${_libcurl_pc}")
  file(WRITE "${PROJECT_BINARY_DIR}/libcurl.pc" "${_libcurl_pc}")
  install(FILES "${PROJECT_BINARY_DIR}/libcurl.pc"
    DESTINATION "${CMAKE_INSTALL_LIBDIR}/pkgconfig")

  # Install headers
  install(DIRECTORY "${PROJECT_SOURCE_DIR}/include/curl"
    DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
    FILES_MATCHING PATTERN "*.h")

  include(CMakePackageConfigHelpers)
  write_basic_package_version_file("${_version_config}"
    VERSION ${_curl_version}
    COMPATIBILITY SameMajorVersion)
  file(READ "${_version_config}" _generated_version_config)
  file(WRITE "${_version_config}" "
    if(NOT PACKAGE_FIND_VERSION_RANGE AND PACKAGE_FIND_VERSION_MAJOR STREQUAL \"7\")
      # Version 8 satisfies version 7... requirements
      set(PACKAGE_FIND_VERSION_MAJOR 8)
      set(PACKAGE_FIND_VERSION_COUNT 1)
    endif()
    ${_generated_version_config}")

  # Consumed variables:
  #   CMAKE_MINIMUM_REQUIRED_VERSION
  #   CURLVERSION
  #   LIBCURL_PC_LIBS_PRIVATE_LIST
  #   LIB_NAME
  #   LIB_SELECTED
  #   LIB_STATIC
  #   TARGETS_EXPORT_NAME
  #   CURL_SUPPORTED_FEATURES_LIST
  #   CURL_SUPPORTED_PROTOCOLS_LIST
  #   CURL_USE_CMAKECONFIG
  #   CURL_USE_PKGCONFIG
  #   GSS_FLAVOR
  #   HAVE_BROTLI
  #   HAVE_GSSAPI
  #   HAVE_LIBIDN2
  #   HAVE_LIBZ ZLIB_VERSION_MAJOR
  #   HAVE_THREADS_POSIX
  #   HAVE_THREADS_POSIX_BORINGSSL
  #   HAVE_ZSTD
  #   USE_ARES
  #   USE_BACKTRACE
  #   USE_GNUTLS
  #   USE_GSASL
  #   USE_LIBPSL
  #   USE_LIBSSH
  #   USE_LIBSSH2
  #   USE_LIBUV
  #   USE_MBEDTLS
  #   USE_NGHTTP2
  #   USE_NGHTTP3
  #   USE_NGTCP2 NGTCP2_CRYPTO_BACKEND
  #   USE_OPENSSL OPENSSL_VERSION_MAJOR
  #   USE_QUICHE
  #   USE_RUSTLS
  #   USE_WIN32_LDAP CURL_DISABLE_LDAP
  #   USE_WOLFSSL
  configure_package_config_file("CMake/curl-config.in.cmake"
    "${_project_config}"
    INSTALL_DESTINATION ${_install_cmake_dir}
    PATH_VARS CMAKE_INSTALL_INCLUDEDIR)

  if(CURL_ENABLE_EXPORT_TARGET)
    install(EXPORT "${TARGETS_EXPORT_NAME}"
      NAMESPACE "${PROJECT_NAME}::"
      DESTINATION ${_install_cmake_dir})
  endif()

  install(
    FILES
      ${_version_config}
      ${_project_config}
      "${PROJECT_SOURCE_DIR}/CMake/FindBrotli.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindCares.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindGSS.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindGnuTLS.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLDAP.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibbacktrace.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibgsasl.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibidn2.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibpsl.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibssh.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibssh2.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindLibuv.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindMbedTLS.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindNGHTTP2.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindNGHTTP3.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindNGTCP2.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindNettle.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindQuiche.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindRustls.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindWolfSSL.cmake"
      "${PROJECT_SOURCE_DIR}/CMake/FindZstd.cmake"
    DESTINATION ${_install_cmake_dir})

  if(NOT TARGET curl_uninstall)
    # Consumed variable:
    #   PROJECT_BINARY_DIR
    configure_file(
      "${PROJECT_SOURCE_DIR}/CMake/cmake_uninstall.in.cmake"
      "${PROJECT_BINARY_DIR}/cmake_uninstall.cmake" @ONLY)

    add_custom_target(curl_uninstall
      COMMAND ${CMAKE_COMMAND} -P "${PROJECT_BINARY_DIR}/cmake_uninstall.cmake")
  endif()

  if(BUILD_CURL_EXE)
    install(FILES "${PROJECT_SOURCE_DIR}/scripts/wcurl"
      DESTINATION ${CMAKE_INSTALL_BINDIR}
      PERMISSIONS
        OWNER_READ OWNER_WRITE OWNER_EXECUTE
        GROUP_READ GROUP_EXECUTE
        WORLD_READ WORLD_EXECUTE)
  endif()

  # The `-DEV` part is important
  string(REGEX REPLACE "([0-9]+\.[0-9]+)\.([0-9]+.*)" "\\2" CPACK_PACKAGE_VERSION_PATCH "${_curl_version}")
  set(CPACK_GENERATOR "TGZ")
  include(CPack)
endif()

# Save build info for test runner to pick up and log
set(_cmake_sysroot "")
if(CMAKE_OSX_SYSROOT)
  set(_cmake_sysroot ${CMAKE_OSX_SYSROOT})
elseif(CMAKE_SYSROOT)
  set(_cmake_sysroot ${CMAKE_SYSROOT})
endif()
set(_buildinfo "\
buildinfo.configure.tool: cmake
buildinfo.configure.command: ${CMAKE_COMMAND}
buildinfo.configure.version: ${CMAKE_VERSION}
buildinfo.configure.args:${_cmake_args}
buildinfo.configure.generator: ${CMAKE_GENERATOR}
buildinfo.configure.make: ${CMAKE_MAKE_PROGRAM}
buildinfo.host.cpu: ${CMAKE_HOST_SYSTEM_PROCESSOR}
buildinfo.host.os: ${CMAKE_HOST_SYSTEM_NAME}
buildinfo.target.cpu: ${CMAKE_SYSTEM_PROCESSOR}
buildinfo.target.os: ${CMAKE_SYSTEM_NAME}
buildinfo.target.flags:${_target_flags}
buildinfo.compiler: ${CMAKE_C_COMPILER_ID}
buildinfo.compiler.version: ${CMAKE_C_COMPILER_VERSION}
buildinfo.sysroot: ${_cmake_sysroot}
")
file(WRITE "${PROJECT_BINARY_DIR}/buildinfo.txt" "# This is a generated file.  Do not edit.\n${_buildinfo}")
if(NOT "$ENV{CURL_BUILDINFO}$ENV{CURL_CI}$ENV{CI}" STREQUAL "")
  message(STATUS "\n${_buildinfo}")
endif()
